# SPOT Terms of Service

Draft for owner review • Prepared 11 September 2026

This document is a proposed policy for SPOT. It is not final until the operator, contact details, eligibility rules and operational commitments below have been completed and reviewed.

## 1. Who provides SPOT

SPOT is a campus community app where students showcase their talents and Spotters discover and connect with them. It is operated by Deandra Pasquin. Operator address: [OPERATOR CONTACT ADDRESS]. Contact: [PUBLIC SUPPORT EMAIL]. Effective date: [DATE OF ADOPTION].

SPOT does not claim to be an official service of a school or university unless that institution has expressly authorized the relationship.

## 2. Eligibility and your account

SPOT is intended for people aged 16 and older, including campus students and adult Spotters. If you are 16 or 17, a parent or legal guardian must review these Terms with you and provide any permission required by applicable law. A checkbox is an age declaration, not identity verification. The operator must establish an appropriate eligibility and guardian process before public launch.

Use an email address you control, complete email verification, and keep your login credentials private. You may choose a public display name; do not impersonate another person or misrepresent your affiliation. Tell us promptly if you believe your account has been accessed without permission.

## 3. Community expectations

Do not use SPOT for threats, harassment, hate, bullying, stalking, scams, unlawful activity or sharing another person's private information without authorization. Do not post sexual exploitation or abuse material, content that encourages serious harm, or content that infringes another person's rights.

Do not upload malicious code, attempt to access other accounts, bypass access restrictions, scrape personal data, manipulate engagement or disrupt the service. Only upload content you have the right to share, including any necessary permission from people shown in it.

Spotters must honestly describe their identity and opportunities. Do not pressure students into unsafe meetings, request sexual content, exploit younger users or seek unnecessary identity or financial documents. SPOT does not guarantee an offer, employment outcome or the identity of a Spotter. For users under 18, a parent or guardian should be involved before any off-platform meeting or commitment.

## 4. Your content and permission to operate the service

You keep ownership of content you create. By uploading content, you grant the operator a non-exclusive, worldwide, royalty-free permission to store, reproduce, technically adapt and display that content only as needed to operate and provide SPOT, consistent with the audience and features you use. This permission does not transfer ownership or authorize unrelated commercial licensing of your work.

The permission ends when the content is removed from the service, except for limited backup, legal preservation or copies already shared or retained by other users. Do not upload confidential material to a public profile or post. Other people may copy or capture content they can view.

## 5. Moderation and reports

The operator may review reported content and restrict content or accounts when reasonably necessary to address violations, protect people or comply with law. Where appropriate, the operator will explain the action and allow you to contact support to ask for review. Urgent safety or legal issues may require action before notice.

Send reports and review requests to [PUBLIC SUPPORT EMAIL], with enough information to identify the issue. Do not include your password. In an emergency, contact the appropriate emergency services; SPOT is not an emergency response service.

## 6. Privacy and account deletion

The Privacy Policy explains how account, profile, content and technical information are handled. Acknowledging that policy is not blanket consent for unrelated advertising or optional tracking.

To request account deletion, contact [PRIVACY/DELETION EMAIL OR REQUEST URL]. The operator must verify that the request is yours. Deleting the app from a device does not delete the account or its cloud data. Any necessary retention exceptions are described in the Privacy Policy.

## 7. Availability and responsibility

SPOT may change as it develops. The operator aims to provide a useful service but cannot guarantee uninterrupted availability or the accuracy of content provided by other users. Keep your own copies of important creative work. You are responsible for your own content and interactions.

Nothing in these Terms excludes rights or liabilities that cannot lawfully be excluded, including applicable consumer and privacy rights. These Terms do not require you to waive remedies that the law makes available to you.

## 8. Changes and contact

Material changes to these Terms will be communicated before taking effect where required, together with an updated effective date. If a change requires new agreement, the operator will request it. You may stop using SPOT and request account deletion if you do not agree to the updated terms.

Questions or complaints: [PUBLIC SUPPORT EMAIL]. Governing law and any appropriate dispute process: [CONFIRM OPERATOR JURISDICTION AND REVIEW BEFORE LAUNCH].
