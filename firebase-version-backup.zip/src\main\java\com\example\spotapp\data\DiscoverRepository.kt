package com.example.spotapp.data

import android.content.Context
import com.example.spotapp.data.cloudinary.uploadCommunityImage
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import java.util.Date
import java.util.Locale

/** Discover metadata and membership transactions. Every authorization is also enforced by rules. */
class DiscoverRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    private fun uid() = auth.currentUser?.uid ?: error("Sign in to continue.")
    private fun group(id: String) = db.collection("groups").document(id)
    private fun event(id: String) = db.collection("events").document(id)
    private suspend fun account(): DocumentSnapshot {
        val user = db.collection("users").document(uid()).get(Source.SERVER).awaitSocial()
        check(user.getBoolean("profileCompleted") == true) { "Finish setting up your profile first." }
        return user
    }
    suspend fun canCreateEvents(): Boolean = AccountType.fromStorage(account().getString("accountType")) == AccountType.TALENT_SEEKER
    private fun directory(collection: String, search: String, category: String, after: DocumentSnapshot?): Query {
        var query: Query = db.collection(collection)
        if (category.isNotBlank()) query = query.whereEqualTo("category", category)
        val term = search.trim().lowercase(Locale.ROOT)
        query = if (term.isEmpty()) query.orderBy("createdAt", Query.Direction.DESCENDING)
        else query.orderBy("nameKey").whereGreaterThanOrEqualTo("nameKey", term).whereLessThanOrEqualTo("nameKey", term + "\uf8ff")
        if (after != null) query = query.startAfter(after)
        return query.limit(30)
    }
    suspend fun groups(search: String, category: String, after: DocumentSnapshot? = null): SocialPage<CampusGroup> {
        val s = directory("groups", search, category, after).get(Source.SERVER).awaitSocial()
        return SocialPage(s.documents.mapNotNull { it.group() }, s.documents.lastOrNull(), s.size() == 30)
    }
    suspend fun events(search: String, category: String, after: DocumentSnapshot? = null): SocialPage<CampusEvent> {
        val s = directory("events", search, category, after).get(Source.SERVER).awaitSocial()
        return SocialPage(s.documents.mapNotNull { it.event() }, s.documents.lastOrNull(), s.size() == 30)
    }
    fun listenGroup(id: String, result: (CampusGroup?) -> Unit, error: (String) -> Unit) =
        group(id).addSnapshotListener { s, e -> if (e != null) error("This group couldn't load. Please retry.") else result(s?.group()) }
    fun listenEvent(id: String, result: (CampusEvent?) -> Unit, error: (String) -> Unit) =
        event(id).addSnapshotListener { s, e -> if (e != null) error("This event couldn't load. Please retry.") else result(s?.event()) }
    fun listenMembership(id: String, isEvent: Boolean, result: (Boolean) -> Unit, error: (String) -> Unit): ListenerRegistration =
        (if (isEvent) event(id) else group(id)).collection(if (isEvent) "participants" else "members").document(uid())
            .addSnapshotListener { s, e -> if (e != null) error("Your membership couldn't load. Please retry.") else result(s?.exists() == true) }
    fun listenRequest(id: String, result: (Boolean) -> Unit, error: (String) -> Unit): ListenerRegistration =
        group(id).collection("requests").document(uid()).addSnapshotListener { s, e ->
            if (e != null) error("Your join request couldn't load. Please retry.") else result(s?.exists() == true)
        }
    private fun memberData(user: DocumentSnapshot, role: String = "member") = mapOf(
        "userId" to user.id, "displayName" to user.getString("displayName").orEmpty(),
        "profileImageUrl" to user.getString("profileImageUrl").orEmpty(), "role" to role, "createdAt" to FieldValue.serverTimestamp())

    suspend fun createGroup(context: Context, draft: GroupDraft, progress: (Float) -> Unit): String {
        draft.error()?.let { error(it) }
        val user = account(); val id = uid(); val ref = group(draft.id)
        val old = ref.get(Source.SERVER).awaitSocial()
        if (old.exists()) { check(old.getString("ownerId") == id); return ref.id }
        val image = uploadCommunityImage(context, draft.imageUri, "spot/groups/$id/${draft.id}", progress)
        check(uid() == id) { "Your account changed. Please retry." }
        socialTransaction(db) { tx ->
            val existing = tx.get(ref)
            if (existing.exists()) { check(existing.getString("ownerId") == id); return@socialTransaction }
            tx.set(ref, mapOf("groupId" to ref.id, "name" to draft.name.trim(), "nameKey" to draft.name.trim().lowercase(Locale.ROOT),
                "description" to draft.description.trim(), "imageUrl" to image, "category" to draft.category, "privacy" to draft.privacy,
                "ownerId" to id, "ownerName" to user.getString("displayName").orEmpty(),
                "ownerProfileImageUrl" to user.getString("profileImageUrl").orEmpty(), "memberCount" to 1L, "createdAt" to FieldValue.serverTimestamp()))
            tx.set(ref.collection("members").document(id), memberData(user, "owner"))
        }
        progress(1f); return ref.id
    }
    suspend fun requestJoin(id: String) {
        val user = account(); val ref = group(id); val request = ref.collection("requests").document(user.id)
        socialTransaction(db) { tx ->
            val g = tx.get(ref); val m = tx.get(ref.collection("members").document(user.id)); val r = tx.get(request)
            check(g.getString("privacy") == "private") { "This group uses direct joining." }
            if (m.exists() || r.exists()) return@socialTransaction
            tx.set(request, memberData(user))
        }
    }
    suspend fun cancelRequest(id: String) { group(id).collection("requests").document(uid()).delete().awaitSocial() }
    suspend fun setGroupJoined(id: String, joined: Boolean) {
        val user = account(); val ref = group(id); val membership = ref.collection("members").document(user.id)
        socialTransaction(db) { tx ->
            val g = tx.get(ref); val m = tx.get(membership)
            check(g.exists()) { "This group is no longer available." }
            check(g.getString("ownerId") != user.id) { "The owner stays in the group as its admin." }
            if (m.exists() == joined) return@socialTransaction
            if (joined) {
                check(g.getString("privacy") == "public") { "Request to join this private group first." }
                tx.set(membership, memberData(user))
            } else tx.delete(membership)
            tx.update(ref, mapOf("memberCount" to ((g.getLong("memberCount") ?: 0) + if (joined) 1 else -1), "lastMemberId" to user.id))
        }
    }
    suspend fun reviewRequest(id: String, applicant: String, approve: Boolean) {
        val ref = group(id); val request = ref.collection("requests").document(applicant); val m = ref.collection("members").document(applicant)
        socialTransaction(db) { tx ->
            val g = tx.get(ref); val r = tx.get(request); val existing = tx.get(m)
            check(g.getString("ownerId") == uid()) { "Only the group owner can review requests." }
            if (!r.exists()) return@socialTransaction
            if (approve && !existing.exists()) {
                tx.set(m, r.data.orEmpty() + ("createdAt" to FieldValue.serverTimestamp()))
                tx.update(ref, mapOf("memberCount" to ((g.getLong("memberCount") ?: 0) + 1), "lastMemberId" to applicant))
            }
            tx.delete(request)
        }
    }
    suspend fun people(id: String, isEvent: Boolean, requests: Boolean, after: DocumentSnapshot? = null): SocialPage<CommunityMember> {
        val ref = if (isEvent) event(id) else group(id)
        var q: Query = ref.collection(if (isEvent) "participants" else if (requests) "requests" else "members").orderBy("createdAt")
        if (after != null) q = q.startAfter(after)
        val s = q.limit(50).get(Source.SERVER).awaitSocial()
        return SocialPage(s.documents.mapNotNull { it.communityMember() }, s.documents.lastOrNull(), s.size() == 50)
    }
    suspend fun createEvent(context: Context, draft: EventDraft, progress: (Float) -> Unit): String {
        draft.error()?.let { error(it) }
        val user = account(); val id = uid(); val ref = event(draft.id)
        check(AccountType.fromStorage(user.getString("accountType")) == AccountType.TALENT_SEEKER) { "Only Spotters can create events." }
        val old = ref.get(Source.SERVER).awaitSocial()
        if (old.exists()) { check(old.getString("organizerId") == id); return ref.id }
        val image = uploadCommunityImage(context, draft.imageUri, "spot/events/$id/${draft.id}", progress)
        check(uid() == id) { "Your account changed. Please retry." }
        socialTransaction(db) { tx ->
            val existing = tx.get(ref)
            val latest = tx.get(db.collection("users").document(id))
            check(latest.getString("accountType") == AccountType.TALENT_SEEKER.storageValue) { "Only Spotters can create events." }
            if (existing.exists()) { check(existing.getString("organizerId") == id); return@socialTransaction }
            tx.set(ref, mapOf("eventId" to ref.id, "title" to draft.title.trim(), "nameKey" to draft.title.trim().lowercase(Locale.ROOT),
                "description" to draft.description.trim(), "imageUrl" to image, "category" to draft.category,
                "startsAt" to Timestamp(Date(draft.startsAt)), "location" to draft.location.trim(), "organizer" to draft.organizer.trim(),
                "organizerId" to id, "organizerName" to latest.getString("displayName").orEmpty(),
                "organizerProfileImageUrl" to latest.getString("profileImageUrl").orEmpty(), "participantLimit" to draft.participantLimit,
                "participantCount" to 0L, "createdAt" to FieldValue.serverTimestamp()))
        }
        progress(1f); return ref.id
    }
    suspend fun setEventJoined(id: String, joined: Boolean) {
        val user = account(); val ref = event(id); val participation = ref.collection("participants").document(user.id)
        socialTransaction(db) { tx ->
            val e = tx.get(ref); val previous = tx.get(participation)
            check(e.exists()) { "This event is no longer available." }
            if (previous.exists() == joined) return@socialTransaction
            val count = e.getLong("participantCount") ?: 0; val limit = e.getLong("participantLimit")
            if (joined) {
                check((e.getTimestamp("startsAt")?.toDate()?.time ?: 0) > System.currentTimeMillis()) { "Registration has closed." }
                check(limit == null || count < limit) { "This event is full." }
                tx.set(participation, memberData(user))
            } else tx.delete(participation)
            tx.update(ref, mapOf("participantCount" to (count + if (joined) 1 else -1), "lastParticipantId" to user.id))
        }
    }
    companion object { val shared by lazy { DiscoverRepository() } }
}
