package com.example.spot.ui.collaboration

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.spot.data.collaboration.CollaborationRepository
import com.example.spot.data.collaboration.CollaborationSuggestion
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class CollaborationUiState(

    val loading: Boolean = false,

    val suggestions: List<CollaborationSuggestion> =
        emptyList(),

    val error: String? = null
)


class CollaborationViewModel(
    private val repository: CollaborationRepository
) : ViewModel() {

    private val _uiState =
        MutableStateFlow(CollaborationUiState())

    val uiState: StateFlow<CollaborationUiState> =
        _uiState.asStateFlow()


    fun loadSuggestions() {

        viewModelScope.launch {

            _uiState.value =
                _uiState.value.copy(
                    loading = true,
                    error = null
                )

            repository
                .getSuggestions()
                .onSuccess { suggestions ->

                    _uiState.value =
                        CollaborationUiState(
                            loading = false,
                            suggestions = suggestions
                        )
                }
                .onFailure { exception ->

                    _uiState.value =
                        CollaborationUiState(
                            loading = false,
                            error =
                                exception.message
                                    ?: "Failed to load suggestions."
                        )
                }
        }
    }
}