package com.example.spotapp

import com.example.spotapp.data.*
import com.example.spotapp.data.ai.PostAiDependencies
import com.example.spotapp.ui.theme.models.SpotUiPost
import com.example.spotapp.ui.theme.models.SpotUiProfile
import org.junit.Assert.*
import org.junit.Test

class ComposerArchitectureTest {
    @Test fun manualPostsHaveNoAiClaimsAndNeedNoService() {
        val profile = SpotUiProfile("author", "Creator", "creator", "", "")
        val draft = PostDraft("id", "My campus performance", listOf("Guitar"), listOf("CampusTalent"), emptyList(), "public")
        assertNull(draft.error()); assertNull(PostAiDependencies().service)
        assertFalse(draft.aiCaption || draft.aiTagged || draft.aiCategorySuggested)
        val ui = SpotUiPost("id", profile, draft.caption, "Guitar", draft.tags)
        assertFalse(ui.aiCaption || ui.aiTagged || ui.aiCategorySuggested)
    }
    @Test fun legacyPostsDefaultToManualAndExplicitMetadataRoundTrips() {
        val data = mapOf("userId" to "creator", "caption" to "A photo", "audience" to "public")
        val manual = PostDocumentMapper.published("id", data)!!
        assertFalse(manual.aiCaption || manual.aiTagged || manual.aiCategorySuggested)
        val future = PostDocumentMapper.published("id", data + mapOf("aiCaption" to true, "aiTagged" to true, "aiCategorySuggested" to true))!!.asUiPost()
        assertTrue(future.aiCaption && future.aiTagged && future.aiCategorySuggested)
    }
    @Test fun eventValidationRejectsPastTimeAndInvalidCapacity() {
        val d = EventDraft("id", "Campus showcase", "Perform on stage", "", "Singing", 2000, "Campus hall", "SPOT Society", null)
        assertNull(d.error(1000)); assertNotNull(d.error(3000))
        assertNotNull(d.copy(participantLimit = 0).error(1000)); assertNotNull(d.copy(participantLimit = 100001).error(1000))
        assertNull(d.copy(participantLimit = 1).error(1000))
    }
    @Test fun groupsRequireRealDescriptionCategoryAndValidPrivacy() {
        val d = GroupDraft("id", "Campus artists", "Paint together", "", "Painting", "private")
        assertNull(d.error()); assertNotNull(d.copy(privacy = "unknown").error())
        assertNotNull(d.copy(name = " ").error()); assertNotNull(d.copy(description = "").error())
    }
}
