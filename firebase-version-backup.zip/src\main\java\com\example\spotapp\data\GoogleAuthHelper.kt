package com.example.spotapp.data

import android.content.Context
import android.util.Log
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.example.spotapp.R
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object GoogleAuthHelper {
    suspend fun signInWithGoogle(context: Context): GoogleSignInResult = runGoogleSignIn(
        requestIdToken = {
            // Use the explicit button flow, with a web OAuth client and foreground context.
            val option = GetSignInWithGoogleOption.Builder(
                context.getString(R.string.default_web_client_id)
            ).build()
            val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
            val credential = CredentialManager.create(context).getCredential(context, request).credential
            check(credential is CustomCredential &&
                credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                "Google ID credential was not returned."
            }
            GoogleIdTokenCredential.createFrom(credential.data).idToken
        },
        authenticate = { idToken ->
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            suspendCancellableCoroutine<Unit> { continuation ->
                FirebaseAuth.getInstance().signInWithCredential(credential)
                    .addOnSuccessListener { result ->
                        if (continuation.isActive) {
                            if (result.user != null) continuation.resume(Unit)
                            else continuation.resumeWithException(IllegalStateException("Google account could not be loaded."))
                        }
                    }
                    .addOnFailureListener { error ->
                        if (continuation.isActive) continuation.resumeWithException(error)
                    }
            }
        },
        onFailure = { stage, error -> Log.w("SpotGoogleAuth", "$stage failed", error) }
    )
}
