package com.example.spotapp.ui.theme.screens.post

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.spotapp.data.PostMediaEdit
import com.example.spotapp.data.ai.SpotAiRepository
import com.example.spotapp.data.ai.TalentPredictionResponse
import com.example.spotapp.data.ai.spotAiError
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** [mediaKey] identifies the media + edit that was analyzed, so a result is never shown for other media. */
data class TalentAiUiState(
    val isLoading: Boolean = false,
    val prediction: TalentPredictionResponse? = null,
    val error: String? = null,
    val mediaKey: String? = null
)

class TalentAiViewModel : ViewModel() {

    private val repository =
        SpotAiRepository()

    private val _uiState =
        MutableStateFlow(
            TalentAiUiState()
        )

    val uiState: StateFlow<TalentAiUiState> =
        _uiState.asStateFlow()

    private var job: Job? = null

    fun analyze(
        context: Context,
        mediaUri: String,
        edit: PostMediaEdit
    ) {
        val key = mediaKey(mediaUri, edit)
        job?.cancel()
        job = viewModelScope.launch {

            _uiState.value =
                TalentAiUiState(
                    isLoading = true,
                    mediaKey = key
                )

            try {

                val result =
                    repository.predictTalent(
                        context = context.applicationContext,
                        mediaUri = mediaUri,
                        edit = edit
                    )

                _uiState.value =
                    TalentAiUiState(
                        prediction = result,
                        mediaKey = key
                    )

            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {

                _uiState.value =
                    TalentAiUiState(
                        error = spotAiError(e),
                        mediaKey = key
                    )
            }
        }
    }

    fun clearPrediction() {
        job?.cancel()
        _uiState.value =
            TalentAiUiState()
    }

    companion object {
        fun mediaKey(mediaUri: String, edit: PostMediaEdit) = "$mediaUri|$edit"
    }
}
