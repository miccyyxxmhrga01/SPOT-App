package com.example.spotapp.ui.theme.screens.discover

import com.example.spotapp.ui.theme.components.spotAmbientBackground
import com.example.spotapp.ui.theme.components.SpotAvatar

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil3.compose.AsyncImage
import com.example.spotapp.data.SpotTalentCategories
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

internal val CommunityGold = Color(0xFFAD8420)
internal val CommunityIvory = Color(0xFFFFFCF6)
internal val CommunityLine = Color(0xFFE8E2D5)

@Composable
internal fun communityChipColors() = FilterChipDefaults.filterChipColors(containerColor = Color.White,
    labelColor = Color(0xFF554F43), selectedContainerColor = Color(0xFFFAF2DF), selectedLabelColor = CommunityGold)

@Composable
internal fun CommunityCover(url: String, event: Boolean, modifier: Modifier = Modifier) {
    Box(modifier.background(Brush.linearGradient(listOf(Color(0xFFF2E7CA), Color(0xFFFAF6EB)))), contentAlignment = Alignment.Center) {
        if (url.isNotBlank()) AsyncImage(url, if (event) "Event poster" else "Group cover", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(if (event) Icons.Default.Event else Icons.Default.Groups, null, Modifier.size(42.dp), tint = CommunityGold.copy(alpha = .65f))
    }
}
@Composable
internal fun CommunityAvatar(url: String, uid: String = "") { SpotAvatar(url, "Profile", Modifier.size(38.dp), uid) }
@Composable
internal fun CommunityWindow(title: String, close: () -> Unit, busy: Boolean = false, content: @Composable (PaddingValues) -> Unit) {
    Dialog(onDismissRequest = { if (!busy) close() }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false, dismissOnBackPress = !busy, dismissOnClickOutside = false)) {
        Scaffold(Modifier.fillMaxSize().spotAmbientBackground(CommunityIvory), containerColor = Color.Transparent, contentWindowInsets = WindowInsets(0, 0, 0, 0), topBar = {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = close, enabled = !busy) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                Text(title, style = MaterialTheme.typography.titleLarge)
            }
        }, content = content)
    }
}
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun CommunityCategories(selected: String, select: (String) -> Unit, all: Boolean = false) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        (if (all) listOf("") + SpotTalentCategories else SpotTalentCategories).forEach { item ->
            FilterChip(selected == item, { select(item) }, label = { Text(item.ifBlank { "All talents" }, style = MaterialTheme.typography.labelMedium) },
                colors = communityChipColors(), border = BorderStroke(1.dp, CommunityLine))
        }
    }
}
@Composable
internal fun CommunityError(message: String, retry: (() -> Unit)? = null) {
    if (message.isNotBlank()) Surface(color = MaterialTheme.colorScheme.errorContainer, shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
            if (retry != null) TextButton(onClick = retry) { Text("Retry") }
        }
    }
}
@Composable
internal fun CommunityBadge(label: String) {
    Surface(color = Color(0xFFFAF2DF), shape = RoundedCornerShape(8.dp), border = BorderStroke(1.dp, CommunityLine)) {
        Text(label, Modifier.padding(horizontal = 8.dp, vertical = 5.dp), color = CommunityGold, style = MaterialTheme.typography.labelSmall)
    }
}
internal fun eventDate(time: Long, pattern: String = "EEE, MMM d · h:mm a"): String =
    SimpleDateFormat(pattern, Locale.getDefault()).format(Date(time))
