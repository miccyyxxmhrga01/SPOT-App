package com.example.spotapp.data.ai

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.Build
import androidx.core.net.toUri
import com.example.spotapp.data.PostMediaEdit
import com.example.spotapp.data.PostMediaExporter
import com.example.spotapp.data.SpotTalentCategories
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import retrofit2.HttpException
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.SocketTimeoutException
import kotlin.math.roundToInt

class SpotAiRepository {

    /**
     * Sends one frame of the post's media to SPOT AI. Photos go through the same renderer as the
     * editor (EXIF orientation, rotation, crop); videos use a frame from the middle of the clip.
     * Everything is re-encoded as a small JPEG, so HEIC/GIF photos and videos are accepted too.
     */
    suspend fun predictTalent(context: Context, mediaUri: String, edit: PostMediaEdit = PostMediaEdit()): TalentPredictionResponse {
        val jpeg = withContext(Dispatchers.IO) {
            val video = context.contentResolver.getType(mediaUri.toUri())?.startsWith("video/") == true
            val bitmap = if (video) videoFrame(context, mediaUri) else PostMediaExporter.imagePreview(context, mediaUri, edit, MAX_EDGE)
            try { ByteArrayOutputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it); it.toByteArray() } }
            finally { bitmap.recycle() }
        }
        val part = MultipartBody.Part.createFormData("image", "spot-post.jpg", jpeg.toRequestBody("image/jpeg".toMediaType()))
        val result = SpotAiClient.api.predictTalent(part)
        if (!result.success) throw IllegalStateException(result.message.ifBlank { "SPOT AI couldn't analyze this media." })
        return result
    }

    private fun videoFrame(context: Context, uri: String): Bitmap {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri.toUri())
            val middleUs = (retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) * 1000 / 2
            val frame = if (Build.VERSION.SDK_INT >= 27) retriever.getScaledFrameAtTime(middleUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, MAX_EDGE, MAX_EDGE)
                else retriever.getFrameAtTime(middleUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { original ->
                    val scale = MAX_EDGE.toFloat() / maxOf(original.width, original.height)
                    if (scale >= 1f) original
                    else Bitmap.createScaledBitmap(original, (original.width * scale).roundToInt().coerceAtLeast(1), (original.height * scale).roundToInt().coerceAtLeast(1), true)
                        .also { if (it !== original) original.recycle() }
                }
            return frame ?: throw IllegalArgumentException("This video couldn't be read. Choose a category yourself.")
        } finally { retriever.release() }
    }

    private companion object { const val MAX_EDGE = 512 } // The model only sees 224 × 224.
}

/** Maps SPOT AI's model classes onto the composer's categories. "other" means no talent was recognized. */
fun TalentSuggestion.composerCategory(): String? = when (rawClass.lowercase()) {
    "other" -> null
    "keyboard" -> "Piano"
    else -> SpotTalentCategories.firstOrNull { it.equals(rawClass, ignoreCase = true) }
}

fun spotAiError(error: Throwable): String = when (error) {
    is HttpException -> when (error.code()) {
        503 -> "SPOT AI isn't ready right now. Choose a category yourself or try again later."
        413 -> "This media is too large for SPOT AI."
        400, 415 -> "SPOT AI couldn't read this media. Choose a category yourself."
        else -> runCatching { JSONObject(error.response()?.errorBody()?.string().orEmpty()).optString("error") }.getOrNull()
            ?.takeIf { it.isNotBlank() } ?: "SPOT AI couldn't analyze this media. Please try again."
    }
    is SocketTimeoutException -> "SPOT AI took too long to answer. It may be waking up, so try again in a moment."
    is IOException -> "Couldn't reach SPOT AI. Check your connection and try again."
    is IllegalArgumentException, is IllegalStateException -> error.message ?: "SPOT AI couldn't analyze this media."
    else -> "SPOT AI couldn't analyze this media. Please try again."
}
