package com.example.spotapp.ui.theme.screens.post

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.spotapp.data.PostDraft
import com.example.spotapp.data.PostMediaEdit
import com.example.spotapp.data.ai.composerCategory
import kotlin.math.roundToInt

/** Suggests talent categories for the post's first photo/video. Nothing is applied until the user taps a suggestion. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun TalentAiCard(draft: PostDraft, update: (PostDraft) -> Unit, enabled: Boolean, modifier: Modifier = Modifier) {
    val cover = draft.mediaUris.firstOrNull() ?: return
    val context = LocalContext.current
    val ai: TalentAiViewModel = viewModel(key = "talent-ai-${draft.id}")
    val state by ai.uiState.collectAsStateWithLifecycle()
    val edit = draft.mediaEdits[cover] ?: PostMediaEdit()
    // A result for a different cover or edit is stale; show the idle state instead.
    val current = state.takeIf { it.mediaKey == TalentAiViewModel.mediaKey(cover, edit) } ?: TalentAiUiState()
    val prediction = current.prediction
    val suggestions = prediction?.suggestions.orEmpty()
        .mapNotNull { suggestion -> suggestion.composerCategory()?.let { it to suggestion.confidencePercent } }
        .distinctBy { it.first }
    fun analyze() = ai.analyze(context, cover, edit)
    fun toggle(category: String) {
        val added = category !in draft.categories
        val categories = if (added) (draft.categories + category).take(8) else draft.categories - category
        update(draft.copy(categories = categories,
            aiCategorySuggested = added || (draft.aiCategorySuggested && categories.any { chosen -> suggestions.any { it.first == chosen } })))
    }
    Surface(color = Color(0xFFF5F1E8), shape = RoundedCornerShape(18.dp), modifier = modifier.fillMaxWidth().testTag("talent-ai")) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AutoAwesome, null, Modifier.size(18.dp), tint = PostGold)
                Spacer(Modifier.width(8.dp))
                Text("SPOT AI", style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                if (prediction != null || current.error != null) TextButton(onClick = ::analyze, enabled = enabled) { Text("Try again", color = PostGold) }
            }
            when {
                current.isLoading -> {
                    LinearProgressIndicator(Modifier.fillMaxWidth().testTag("talent-ai-progress"), color = PostGold, trackColor = PostLine)
                    Text("Looking at your media… The first check can take up to a minute while SPOT AI wakes up.", style = MaterialTheme.typography.bodySmall, color = PostMuted)
                }
                current.error != null -> PostError(current.error)
                prediction != null && suggestions.isEmpty() ->
                    Text("SPOT AI couldn't recognize a talent here. Choose a category yourself.", style = MaterialTheme.typography.bodySmall, color = PostMuted)
                prediction != null -> {
                    Text(if (prediction.recognizedTalent) "Suggested from your media. Tap to add or remove." else "SPOT AI isn't sure. Only add a suggestion that fits.",
                        style = MaterialTheme.typography.bodySmall, color = PostMuted)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        suggestions.forEach { (category, confidence) ->
                            val selected = category in draft.categories
                            FilterChip(selected, onClick = { toggle(category) }, label = { Text("$category · ${confidence.roundToInt()}%") },
                                enabled = enabled && (selected || draft.categories.size < 8), modifier = Modifier.testTag("talent-ai-$category"),
                                leadingIcon = if (selected) { { Icon(Icons.Default.Check, null, Modifier.size(16.dp)) } } else null,
                                colors = FilterChipDefaults.filterChipColors(containerColor = Color.White, selectedContainerColor = Color(0xFFFAF2DF), selectedLabelColor = PostGold),
                                border = BorderStroke(1.dp, PostLine))
                        }
                    }
                }
                else -> {
                    Text("Get a talent category suggestion from one image of your first photo or video. Nothing is added until you tap it.",
                        style = MaterialTheme.typography.bodySmall, color = PostMuted)
                    OutlinedButton(onClick = ::analyze, enabled = enabled, border = BorderStroke(1.dp, PostLine), shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = PostInk),
                        modifier = Modifier.testTag("talent-ai-analyze")) { Text("Suggest a category") }
                }
            }
        }
    }
}
