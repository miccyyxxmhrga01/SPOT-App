package com.example.spotapp.ui.theme.screens.profile

import com.example.spotapp.ui.theme.components.spotAmbientBackground
import com.example.spotapp.ui.theme.components.LocalSpotBottomContentPadding
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Tab
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.material.icons.filled.Movie
import androidx.compose.ui.platform.testTag
import androidx.compose.foundation.layout.offset

import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.DisposableEffect

import com.example.spotapp.ui.theme.components.SpotAvatar

import com.example.spotapp.ui.theme.spotSp

import android.content.Intent

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GridOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import coil3.compose.AsyncImage
import com.example.spotapp.data.cloudinaryVideoThumbnail
import com.example.spotapp.data.isPostVideoUrl

import com.example.spotapp.ui.theme.InterFontFamily
import com.example.spotapp.ui.theme.models.SpotUiPost
import com.example.spotapp.ui.theme.models.SpotUiProfile


private val ProfileWhite = Color.White
private val ProfileBlack = Color(0xFF111111)
private val ProfileSecondary = Color(0xFF707070)
private val ProfileMuted = Color(0xFFA1A1A1)
private val ProfileLine = Color(0xFFE5E5E5)

private val ProfileGold = Color(0xFFFDD87A)
private val ProfileGoldDeep = Color(0xFFE8B84B)
private val ProfileAmberText = Color(0xFF8A5C10)
private val ProfileSoftGold = Color(0xFFFFF6DA)

private val ProfileAvatarBg = Color(0xFFF0F0F0)
private val ProfileInputBg = Color(0xFFF8F8F8)


private enum class ProfileTab {
    POSTS,
    REELS,
    TAGGED
}


private enum class ProfilePage {
    PROFILE,
    EDIT
}


@Composable
fun UserProfileScreen(
    profile: SpotUiProfile,
    isOwnProfile: Boolean,
    post: SpotUiPost?,
    onBack: () -> Unit,
    onSettingsClick: () -> Unit,
    onMessageClick: () -> Unit,
    bio: String? = null,
    onHireMeClick: (() -> Unit)? = null,
    onEditProfileClick: () -> Unit = {},
    onEditAvatarClick: () -> Unit = {},
    onEditBioClick: () -> Unit = {},
    posts: List<SpotUiPost> = listOfNotNull(post),
    postsStatus: @Composable () -> Unit = {},
    onOpenPost: ((SpotUiPost) -> Unit)? = null,
    following: Boolean? = null, onFollowChanged: (() -> Unit)? = null,
    followerCount: Long? = null, followingCount: Long? = null,
    followRequested: Boolean = false, followPending: Boolean = false,
    onDetailVisibilityChanged: (Boolean) -> Unit = {}, onOpenProfile: (SpotUiProfile) -> Unit = {}
) {

    val context = LocalContext.current

    var page by remember {
        mutableStateOf(ProfilePage.PROFILE)
    }

    SideEffect { onDetailVisibilityChanged(page == ProfilePage.EDIT) }
    DisposableEffect(Unit) { onDispose { onDetailVisibilityChanged(false) } }
    var selectedTab by remember {
        mutableStateOf(ProfileTab.POSTS)
    }

    var isFollowing by remember {
        mutableStateOf(false)
    }

    var displayName by remember(profile) {
        mutableStateOf(profile.displayName)
    }

    var username by remember(profile) {
        mutableStateOf(profile.username)
    }

    var talent by remember(profile) {
        mutableStateOf(profile.talent)
    }

    var course by remember(profile) {
        mutableStateOf(profile.course)
    }

    var localBio by remember(profile, bio) {
        mutableStateOf(bio ?: profile.bio)
    }

    var pronouns by remember(profile.uid) {
        mutableStateOf("")
    }

    var links by remember(profile.uid) {
        mutableStateOf("")
    }

    var gender by remember(profile.uid) {
        mutableStateOf("")
    }

    var aiCreator by remember(profile.uid) {
        mutableStateOf(false)
    }

    var localAvatarUri by remember(profile.uid) {
        mutableStateOf<String?>(null)
    }

    var previewPost by remember(profile.uid) { mutableStateOf<SpotUiPost?>(null) }


    val avatarPicker =
        rememberLauncherForActivityResult(
            contract = ActivityResultContracts.GetContent()
        ) { uri ->

            if (uri != null) {
                localAvatarUri = uri.toString()
                onEditAvatarClick()
            }
        }


    previewPost?.let { selected ->
        PostPreviewDialog(post = selected, onDismiss = { previewPost = null })
    }


    AnimatedContent(
        targetState = page,

        modifier = Modifier.fillMaxSize(),

        transitionSpec = {

            if (targetState == ProfilePage.EDIT) {

                (
                        slideInHorizontally(
                            animationSpec = tween(240)
                        ) {
                            it
                        } +
                                fadeIn(
                                    animationSpec = tween(200)
                                )
                        ) togetherWith

                        (
                                slideOutHorizontally(
                                    animationSpec = tween(240)
                                ) {
                                    -it / 4
                                } +
                                        fadeOut(
                                            animationSpec = tween(150)
                                        )
                                )

            } else {

                (
                        slideInHorizontally(
                            animationSpec = tween(240)
                        ) {
                            -it / 4
                        } +
                                fadeIn(
                                    animationSpec = tween(200)
                                )
                        ) togetherWith

                        (
                                slideOutHorizontally(
                                    animationSpec = tween(240)
                                ) {
                                    it
                                } +
                                        fadeOut(
                                            animationSpec = tween(150)
                                        )
                                )
            }
        },

        label = "profile_edit_transition"
    ) { currentPage ->

        when (currentPage) {

            ProfilePage.PROFILE -> {

                ProfileMainPage(
                    profile = profile,
                    isOwnProfile = isOwnProfile,
                    posts = posts,
                    postsStatus = postsStatus,
                    displayName = displayName,
                    username = username,
                    talent = talent,
                    course = course,
                    bio = localBio,
                    avatarUri = localAvatarUri,

                    selectedTab = selectedTab,
                    isFollowing = following ?: isFollowing,
                    followerCount = followerCount, followingCount = followingCount,
                    followRequested = followRequested, followPending = followPending, onOpenProfile = onOpenProfile,

                    onBack = onBack,

                    onSettingsClick = onSettingsClick,

                    onEditProfile = {
                        page = ProfilePage.EDIT
                    },

                    onShareProfile = {

                        val shareIntent =
                            Intent(Intent.ACTION_SEND).apply {

                                type = "text/plain"

                                putExtra(
                                    Intent.EXTRA_TEXT,
                                    "Check out $displayName (@$username) on SPOT."
                                )
                            }

                        context.startActivity(
                            Intent.createChooser(
                                shareIntent,
                                "Share SPOT profile"
                            )
                        )
                    },

                    onChangeAvatar = {
                        page = ProfilePage.EDIT
                    },

                    onFollow = {
                        if (onFollowChanged != null) onFollowChanged() else isFollowing = !isFollowing
                    },

                    onMessage = onMessageClick,

                    onHireMe = onHireMeClick,

                    onTabSelected = {
                        selectedTab = it
                    },

                    onPostClick = { if (onOpenPost != null) onOpenPost(it) else previewPost = it }
                )
            }


            ProfilePage.EDIT -> {
                ConnectedEditProfile(profile, onBack = { page = ProfilePage.PROFILE }, onSaved = {
                    localAvatarUri = null; onEditProfileClick(); page = ProfilePage.PROFILE
                })
            }
        }
    }
}


@Composable
private fun ProfileMainPage(
    profile: SpotUiProfile,
    isOwnProfile: Boolean,
    posts: List<SpotUiPost>,
    postsStatus: @Composable () -> Unit,
    displayName: String,
    username: String,
    talent: String,
    course: String,
    bio: String,
    avatarUri: String?,
    selectedTab: ProfileTab,
    isFollowing: Boolean,
    followerCount: Long?, followingCount: Long?,
    onBack: () -> Unit,
    onSettingsClick: () -> Unit,
    onEditProfile: () -> Unit,
    onShareProfile: () -> Unit,
    onChangeAvatar: () -> Unit,
    onFollow: () -> Unit,
    onMessage: () -> Unit,
    onHireMe: (() -> Unit)?,
    onTabSelected: (ProfileTab) -> Unit,
    onPostClick: (SpotUiPost) -> Unit
,
    followRequested: Boolean, followPending: Boolean, onOpenProfile: (SpotUiProfile) -> Unit
) {

    var connections by androidx.compose.runtime.remember { mutableStateOf<String?>(null) }
    connections?.let { mode -> ConnectionsPage(profile, mode, { connections = null }, onOpenProfile) }
    Column(
        modifier =
            Modifier
                .fillMaxSize()
                .spotAmbientBackground(ProfileWhite)
                .statusBarsPadding()
                .verticalScroll(
                    rememberScrollState()
                )
    ) {

        SpotProfileHeader(
            username = username,
            isOwnProfile = isOwnProfile,
            onBack = onBack,
            onSettingsClick = onSettingsClick
        )


        Spacer(
            modifier =
                Modifier.height(10.dp)
        )


        ProfileTopSection(
            profile = profile,
            avatarOverride = avatarUri,
            displayName = displayName,
            isOwnProfile = isOwnProfile,
            postCount = posts.size,
            followerCount = followerCount, followingCount = followingCount,
            onAvatarClick = onChangeAvatar, onConnections = { connections = it }
        )


        Spacer(
            modifier =
                Modifier.height(13.dp)
        )


        ProfileDetails(
            bio = bio,
            talent = talent,
            course = course,
            isOwnProfile = isOwnProfile,
            onAddBio = onEditProfile,
            accountType = profile.accountType,
            organization = profile.organization
        )


        Spacer(
            modifier =
                Modifier.height(13.dp)
        )


        ProfileActions(
            isOwnProfile = isOwnProfile,
            isFollowing = isFollowing,
            onEditProfile = onEditProfile,
            onShareProfile = onShareProfile,
            onFollow = onFollow,
            onMessage = onMessage,
            onHireMe = onHireMe, followRequested = followRequested, followPending = followPending
        )


        Spacer(
            modifier =
                Modifier.height(21.dp)
        )


        if (profile.accountType == com.example.spotapp.data.AccountType.TALENT_SEEKER && profile.seekingTalents.isNotEmpty()) {
            Text("Looking for · " + profile.seekingTalents.joinToString(" · "),
                style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                color = androidx.compose.ui.graphics.Color(0xFFAD8420),
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 8.dp))
        }
        ConnectedHighlights(profile, isOwnProfile, isFollowing)


        Spacer(
            modifier =
                Modifier.height(17.dp)
        )


        if (profile.isPrivate && !isOwnProfile && !isFollowing) Text("Private account · Follow to see posts", Modifier.padding(horizontal = 18.dp, vertical = 12.dp), style = androidx.compose.material3.MaterialTheme.typography.bodySmall, color = ProfileSecondary)
        ProfileTabRow(
            selectedTab = selectedTab,
            onSelectTab = onTabSelected
        )


        HorizontalDivider(
            color = ProfileLine
        )


        AnimatedContent(
            targetState = selectedTab,

            transitionSpec = {

                fadeIn(
                    tween(180)
                ) togetherWith

                        fadeOut(
                            tween(120)
                        )
            },

            label = "profile_tabs"
        ) { tab ->

            when (tab) {

                ProfileTab.POSTS -> {

                    postsStatus()
                    ProfilePostsGrid(
                        posts = posts,
                        onPostClick = onPostClick
                    )
                }


                ProfileTab.REELS -> {

                    postsStatus()
                    ProfileReelsGrid(
                        posts = posts,
                        onReelClick = onPostClick
                    )
                }


                ProfileTab.TAGGED -> {

                    ProfileEmptyState(
                        icon = Icons.Filled.Person,
                        title = "No tagged posts yet",
                        subtitle = "Posts you're tagged in will appear here."
                    )
                }
            }
        }
        Spacer(Modifier.height(20.dp + LocalSpotBottomContentPadding.current))
    }
}


@Composable
private fun SpotProfileHeader(
    username: String,
    isOwnProfile: Boolean,
    onBack: () -> Unit,
    onSettingsClick: () -> Unit
) {

    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .height(52.dp)
                .padding(
                    horizontal = 8.dp
                ),

        verticalAlignment =
            Alignment.CenterVertically
    ) {

        if (!isOwnProfile) {
        IconButton(
            onClick = onBack,
            modifier = Modifier.size(40.dp)
        ) {

            Icon(
                imageVector =
                    Icons.AutoMirrored.Filled.ArrowBack,

                contentDescription = "Back",

                tint = ProfileBlack,

                modifier =
                    Modifier.size(22.dp)
            )
        }
        } else { Spacer(Modifier.width(12.dp)) }


        Text(
            text =
                "@${username.ifBlank { "username" }}",

            color = ProfileBlack,

            fontFamily = InterFontFamily,

            fontSize = 16.spotSp,

            fontWeight = FontWeight.Bold,

            maxLines = 1,

            overflow = TextOverflow.Ellipsis,

            modifier =
                Modifier
                    .weight(1f)
                    .padding(
                        start = 5.dp
                    )
        )


        if (isOwnProfile) {

            IconButton(
                onClick = onSettingsClick,
                modifier = Modifier.size(40.dp)
            ) {

                Icon(
                    imageVector =
                        Icons.Filled.Settings,

                    contentDescription = "Settings",

                    tint = ProfileBlack,

                    modifier =
                        Modifier.size(22.dp)
                )
            }
        }
    }
}


@Composable
private fun ProfileTopSection(
    profile: SpotUiProfile,
    avatarOverride: String?,
    displayName: String,
    isOwnProfile: Boolean,
    postCount: Int,
    followerCount: Long?, followingCount: Long?,
    onAvatarClick: () -> Unit
,
    onConnections: (String) -> Unit
) {

    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = 18.dp
                ),

        verticalAlignment =
            Alignment.CenterVertically
    ) {

        ProfileAvatarLarge(
            profile = profile,
            avatarOverride = avatarOverride,
            isOwnProfile = isOwnProfile,
            onEditAvatarClick = onAvatarClick
        )


        Spacer(
            modifier =
                Modifier.width(24.dp)
        )


        Row(
            modifier =
                Modifier.weight(1f),

            horizontalArrangement =
                Arrangement.SpaceBetween
        ) {

            ProfileStat(
                value = postCount.toString(),
                label = "posts"
            )

            ProfileStat(
                value = followerCount?.toString() ?: "—",
                label = "followers", onClick = { onConnections("followers") }
            )

            ProfileStat(
                value = followingCount?.toString() ?: "—",
                label = "following", onClick = { onConnections("following") }
            )
        }
    }


    Spacer(
        modifier =
            Modifier.height(10.dp)
    )


    Text(
        text = displayName,

        color = ProfileBlack,

        fontFamily = InterFontFamily,

        fontSize = 13.spotSp,

        fontWeight = FontWeight.SemiBold,

        modifier =
            Modifier.padding(
                horizontal = 18.dp
            )
    )
}


@Composable
private fun ProfileAvatarLarge(
    profile: SpotUiProfile,
    avatarOverride: String?,
    isOwnProfile: Boolean,
    onEditAvatarClick: () -> Unit
) {
    Box(Modifier.size(82.dp)) {
        SpotAvatar(avatarOverride ?: profile.profileImageUrl, "${profile.displayName} profile picture",
            Modifier.fillMaxSize().border(1.5.dp, ProfileGoldDeep, CircleShape).padding(3.dp), profile.uid)
        if (isOwnProfile) IconButton(onEditAvatarClick, Modifier.align(Alignment.BottomEnd).offset(6.dp, 6.dp).size(32.dp)) {
            Icon(Icons.Filled.Edit, "Change profile photo", Modifier.size(20.dp).background(ProfileWhite, CircleShape), tint = ProfileAmberText)
        }
    }
}


@Composable
private fun ProfileStat(
    value: String,
    label: String
,
    onClick: (() -> Unit)? = null
) {

    Column(modifier = Modifier.then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        horizontalAlignment =
            Alignment.CenterHorizontally
    ) {

        Text(
            text = value,
            color = ProfileBlack,
            fontFamily = InterFontFamily,
            fontSize = 16.spotSp,
            fontWeight = FontWeight.SemiBold
        )

        Spacer(
            modifier =
                Modifier.height(1.dp)
        )

        Text(
            text = label,
            color = ProfileBlack,
            fontFamily = InterFontFamily,
            fontSize = 11.spotSp
        )
    }
}


@Composable
private fun ProfileDetails(
    bio: String,
    talent: String,
    course: String,
    isOwnProfile: Boolean,
    onAddBio: () -> Unit,
    accountType: com.example.spotapp.data.AccountType? = null,
    organization: String = ""
) {

    Column(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = 18.dp
                )
    ) {

        if (bio.isNotBlank()) {

            Text(
                text = bio,
                color = ProfileBlack,
                fontFamily = InterFontFamily,
                fontSize = 12.spotSp,
                lineHeight = 16.sp
            )

        } else if (isOwnProfile) {

            Text(
                text = "Add a bio",
                color = ProfileGoldDeep,
                fontFamily = InterFontFamily,
                fontSize = 11.spotSp,
                fontWeight = FontWeight.SemiBold,
                modifier =
                    Modifier.clickable(
                        onClick = onAddBio
                    )
            )
        }


        Spacer(
            modifier =
                Modifier.height(9.dp)
        )


        Surface(
            shape =
                RoundedCornerShape(50),

            color =
                ProfileSoftGold,

            border =
                BorderStroke(
                    width = 1.dp,
                    color =
                        ProfileGold.copy(
                            alpha = 0.7f
                        )
                )
        ) {

            Text(
                text =
                    if (accountType == com.example.spotapp.data.AccountType.TALENT_SEEKER) com.example.spotapp.data.AccountType.TALENT_SEEKER.label else talent.ifBlank {
                        "Talent"
                    },

                color = ProfileAmberText,

                fontFamily = InterFontFamily,

                fontSize = 10.spotSp,

                fontWeight = FontWeight.SemiBold,

                modifier =
                    Modifier.padding(
                        horizontal = 10.dp,
                        vertical = 5.dp
                    )
            )
        }


        // Course is now on its own line.
        Spacer(
            modifier =
                Modifier.height(6.dp)
        )


        Text(
            text =
                if (accountType == com.example.spotapp.data.AccountType.TALENT_SEEKER) organization else course.ifBlank {
                    "Course"
                },

            color = ProfileSecondary,

            fontFamily = InterFontFamily,

            fontSize = 10.5.spotSp,

            maxLines = 2,

            overflow = TextOverflow.Ellipsis
        )
    }
}


@Composable
private fun ProfileActions(
    isOwnProfile: Boolean,
    isFollowing: Boolean,
    onEditProfile: () -> Unit,
    onShareProfile: () -> Unit,
    onFollow: () -> Unit,
    onMessage: () -> Unit,
    onHireMe: (() -> Unit)?
,
    followRequested: Boolean, followPending: Boolean
) {

    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = 18.dp
                ),

        horizontalArrangement =
            Arrangement.spacedBy(8.dp)
    ) {

        if (isOwnProfile) {

            ProfileActionButton(
                text = "Edit profile",
                modifier = Modifier.weight(1f),
                primary = false,
                onClick = onEditProfile
            )

            ProfileActionButton(
                text = "Share profile",
                modifier = Modifier.weight(1f),
                primary = false,
                onClick = onShareProfile
            )

        } else {

            ProfileActionButton(
                text =
                    if (followPending) "Updating…" else if (isFollowing) "Following" else if (followRequested) "Requested" else "Follow",

                modifier =
                    Modifier.weight(1f),

                primary =
                    !isFollowing,

                onClick =
                    onFollow
            )


            ProfileActionButton(
                text = "Message",
                modifier = Modifier.weight(1f),
                primary = false,
                onClick = onMessage
            )


            if (onHireMe != null) ProfileActionButton(
                text = "Invite",
                modifier = Modifier.weight(1f),
                primary = true,
                onClick = onHireMe
            )
        }
    }
}


@Composable
private fun ProfileActionButton(
    text: String,
    modifier: Modifier = Modifier,
    primary: Boolean,
    onClick: () -> Unit
) {

    val interactionSource =
        remember {
            MutableInteractionSource()
        }

    val isPressed by
    interactionSource.collectIsPressedAsState()


    val backgroundColor by
    animateColorAsState(
        targetValue =
            when {

                primary ->
                    ProfileGold

                isPressed ->
                    ProfileSoftGold

                else ->
                    Color(0xFFF2F2F2)
            },

        animationSpec =
            tween(130),

        label =
            "profile_action_color"
    )


    Box(
        modifier =
            modifier
                .heightIn(min = 44.dp)
                .clip(
                    RoundedCornerShape(8.dp)
                )
                .background(
                    backgroundColor
                )
                .border(
                    width = 1.dp,
                    color =
                        if (primary) {
                            ProfileGold
                        } else {
                            ProfileLine
                        },
                    shape =
                        RoundedCornerShape(8.dp)
                )
                .clickable(
                    interactionSource =
                        interactionSource,

                    indication = null,

                    onClick = onClick
                ),

        contentAlignment =
            Alignment.Center
    ) {

        Text(
            text = text,
            color = ProfileBlack,
            fontFamily = InterFontFamily,
            fontSize = 11.spotSp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1
        )
    }
}


@Composable
private fun ProfileHighlightsRow(
    isOwnProfile: Boolean,
    talent: String
) {

    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = 18.dp
                ),

        horizontalArrangement =
            Arrangement.spacedBy(20.dp)
    ) {

        if (isOwnProfile) {

            HighlightItem(
                label = "New",
                icon = Icons.Filled.Add,
                accent = false
            )
        }


        HighlightItem(
            label =
                talent
                    .ifBlank {
                        "Talent"
                    }
                    .take(12),

            icon = Icons.Filled.Person,
            accent = true
        )


        HighlightItem(
            label = "Highlights",
            icon = Icons.Filled.PlayArrow,
            accent = true
        )
    }
}


@Composable
private fun HighlightItem(
    label: String,
    icon: ImageVector,
    accent: Boolean
) {

    Column(
        horizontalAlignment =
            Alignment.CenterHorizontally
    ) {

        Box(
            modifier =
                Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(
                        if (accent) {
                            ProfileSoftGold
                        } else {
                            ProfileWhite
                        }
                    )
                    .border(
                        width =
                            if (accent) {
                                2.dp
                            } else {
                                1.5.dp
                            },

                        color =
                            if (accent) {
                                ProfileGoldDeep
                            } else {
                                ProfileLine
                            },

                        shape = CircleShape
                    ),

            contentAlignment =
                Alignment.Center
        ) {

            Icon(
                imageVector = icon,
                contentDescription = null,

                tint =
                    if (accent) {
                        ProfileGoldDeep
                    } else {
                        ProfileBlack
                    },

                modifier =
                    Modifier.size(25.dp)
            )
        }


        Spacer(
            modifier =
                Modifier.height(6.dp)
        )


        Text(
            text = label,
            color = ProfileBlack,
            fontFamily = InterFontFamily,
            fontSize = 10.spotSp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}


@Composable
private fun ProfileTabRow(selectedTab: ProfileTab, onSelectTab: (ProfileTab) -> Unit) {
    BoxWithConstraints(Modifier.fillMaxWidth().height(52.dp)) {
        val slot = maxWidth / 3
        val offset by animateDpAsState(slot * selectedTab.ordinal + (slot - 30.dp) / 2,
            spring(dampingRatio = .85f, stiffness = 500f), label = "Profile tab indicator")
        Row(Modifier.fillMaxSize()) {
            ProfileTab.entries.forEach { tab ->
                Tab(selectedTab == tab, { onSelectTab(tab) }, modifier = Modifier.weight(1f).fillMaxHeight(),
                    selectedContentColor = ProfileAmberText, unselectedContentColor = ProfileMuted,
                    icon = { Icon(when (tab) { ProfileTab.POSTS -> Icons.Filled.GridOn; ProfileTab.REELS -> Icons.Filled.Movie; ProfileTab.TAGGED -> Icons.Filled.Person },
                        when (tab) { ProfileTab.POSTS -> "Posts"; ProfileTab.REELS -> "Reels"; ProfileTab.TAGGED -> "Tagged" }, Modifier.size(22.dp)) })
            }
        }
        Box(Modifier.align(Alignment.BottomStart).offset { androidx.compose.ui.unit.IntOffset(offset.roundToPx(), 0) }.width(30.dp).height(3.dp)
            .background(ProfileGoldDeep, RoundedCornerShape(2.dp)).testTag("profile-tab-indicator"))
    }
}

@Composable
private fun ProfileTabIcon(
    icon: ImageVector,
    contentDescription: String,
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {

    val tint by
    animateColorAsState(
        targetValue =
            if (selected) {
                ProfileBlack
            } else {
                ProfileMuted
            },

        animationSpec =
            tween(150),

        label =
            "profile_tab_tint"
    )


    Column(
        modifier =
            modifier
                .fillMaxSize()
                .clickable(
                    onClick = onClick
                ),

        horizontalAlignment =
            Alignment.CenterHorizontally,

        verticalArrangement =
            Arrangement.Bottom
    ) {

        Spacer(
            modifier =
                Modifier.weight(1f)
        )


        Icon(
            imageVector = icon,
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(23.dp)
        )


        Spacer(
            modifier =
                Modifier.height(9.dp)
        )


        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(
                        if (selected) {
                            ProfileBlack
                        } else {
                            Color.Transparent
                        }
                    )
        )
    }
}


@Composable
private fun ProfileReelsTabIcon(
    selected: Boolean,
    modifier: Modifier,
    onClick: () -> Unit
) {

    val tint =
        if (selected) {
            ProfileBlack
        } else {
            ProfileMuted
        }


    Column(
        modifier =
            modifier
                .fillMaxSize()
                .clickable(
                    onClick = onClick
                ),

        horizontalAlignment =
            Alignment.CenterHorizontally,

        verticalArrangement =
            Arrangement.Bottom
    ) {

        Spacer(
            modifier =
                Modifier.weight(1f)
        )


        Box(
            modifier =
                Modifier
                    .size(
                        width = 25.dp,
                        height = 21.dp
                    )
                    .border(
                        width = 2.dp,
                        color = tint,
                        shape =
                            RoundedCornerShape(5.dp)
                    ),

            contentAlignment =
                Alignment.Center
        ) {

            Icon(
                imageVector =
                    Icons.Filled.PlayArrow,

                contentDescription = "Reels",

                tint = tint,

                modifier =
                    Modifier.size(14.dp)
            )
        }


        Spacer(
            modifier =
                Modifier.height(9.dp)
        )


        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .background(
                        if (selected) {
                            ProfileBlack
                        } else {
                            Color.Transparent
                        }
                    )
        )
    }
}


@Composable
private fun ProfilePostsGrid(posts: List<SpotUiPost>, onPostClick: (SpotUiPost) -> Unit) {
    if (posts.isEmpty()) {
        ProfileEmptyState(Icons.Filled.GridOn, "No posts yet", "Posts will appear here.")
    } else ProfilePostRows(posts, false, onPostClick)
}

@Composable
private fun ProfileReelsGrid(posts: List<SpotUiPost>, onReelClick: (SpotUiPost) -> Unit) {
    val videos = posts.filter { it.localVideoRes != null || isPostVideoUrl(it.mediaUri.orEmpty()) }
    if (videos.isEmpty()) {
        ProfileEmptyState(Icons.Filled.PlayArrow, "No reels yet", "Video posts will appear here.")
    } else ProfilePostRows(videos, true, onReelClick)
}

@Composable
private fun ProfilePostRows(posts: List<SpotUiPost>, reels: Boolean, onOpen: (SpotUiPost) -> Unit) {
    Column {
        posts.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { item ->
                    ProfileGridTile(item, Modifier.weight(1f), reels || isPostVideoUrl(item.mediaUri.orEmpty())) { onOpen(item) }
                }
                repeat(3 - row.size) { ProfilePlaceholderTile(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun ProfileGridTile(
    post: SpotUiPost,
    modifier: Modifier,
    showReelBadge: Boolean,
    onClick: () -> Unit
) {

    Box(
        modifier =
            modifier
                .aspectRatio(1f)
                .border(
                    width = 0.5.dp,
                    color = ProfileWhite
                )
                .background(ProfileAvatarBg)
                .clickable(
                    onClick = onClick
                )
    ) {

        when {

            post.localImageResources.isNotEmpty() -> {

                Image(
                    painter =
                        painterResource(
                            id =
                                post.localImageResources.first()
                        ),

                    contentDescription = "Post",

                    contentScale = ContentScale.Crop,

                    modifier =
                        Modifier.fillMaxSize()
                )
            }


            !post.mediaUri.isNullOrBlank() -> {

                AsyncImage(
                    model = if (isPostVideoUrl(post.mediaUri.orEmpty())) cloudinaryVideoThumbnail(post.mediaUri.orEmpty()) else post.mediaUri,

                    contentDescription = "Post",

                    contentScale = ContentScale.Crop,

                    modifier =
                        Modifier.fillMaxSize()
                )
            }


            post.localVideoRes != null -> {

                Box(
                    modifier =
                        Modifier
                            .fillMaxSize()
                            .background(ProfileBlack),

                    contentAlignment =
                        Alignment.Center
                ) {

                    Icon(
                        imageVector =
                            Icons.Filled.PlayArrow,

                        contentDescription =
                            "Video",

                        tint = ProfileWhite,

                        modifier =
                            Modifier.size(28.dp)
                    )
                }
            }
        }


        if (
            showReelBadge ||
            post.localVideoRes != null ||
            post.mediaUri
                ?.let {
                    isVideoUri(it)
                } == true
        ) {

            Surface(
                modifier =
                    Modifier
                        .align(
                            Alignment.TopEnd
                        )
                        .padding(6.dp),

                shape =
                    RoundedCornerShape(6.dp),

                color =
                    ProfileBlack.copy(
                        alpha = 0.65f
                    )
            ) {

                Icon(
                    imageVector =
                        Icons.Filled.PlayArrow,

                    contentDescription =
                        "Reel",

                    tint = ProfileWhite,

                    modifier =
                        Modifier
                            .padding(4.dp)
                            .size(13.dp)
                )
            }
        }
    }
}


@Composable
private fun ProfilePlaceholderTile(
    modifier: Modifier
) {

    Box(
        modifier =
            modifier
                .aspectRatio(1f)
                .border(
                    width = 0.5.dp,
                    color = ProfileWhite
                )
                .background(
                    Color(0xFFF7F7F7)
                )
    )
}


@Composable
private fun ProfileEmptyState(
    icon: ImageVector,
    title: String,
    subtitle: String
) {

    Column(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    vertical = 52.dp
                ),

        horizontalAlignment =
            Alignment.CenterHorizontally
    ) {

        Box(
            modifier =
                Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .border(
                        width = 1.5.dp,
                        color = ProfileLine,
                        shape = CircleShape
                    ),

            contentAlignment =
                Alignment.Center
        ) {

            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = ProfileBlack,
                modifier = Modifier.size(24.dp)
            )
        }


        Spacer(
            modifier =
                Modifier.height(10.dp)
        )


        Text(
            text = title,
            color = ProfileBlack,
            fontFamily = InterFontFamily,
            fontSize = 13.spotSp,
            fontWeight = FontWeight.SemiBold
        )


        Spacer(
            modifier =
                Modifier.height(3.dp)
        )


        Text(
            text = subtitle,
            color = ProfileMuted,
            fontFamily = InterFontFamily,
            fontSize = 10.spotSp
        )
    }
}


/* ---------------- EDIT PROFILE PAGE ---------------- */


@Composable
private fun EditProfilePage(
    displayName: String,
    username: String,
    pronouns: String,
    bio: String,
    talent: String,
    course: String,
    links: String,
    gender: String,
    aiCreator: Boolean,
    profile: SpotUiProfile,
    avatarUri: String?,
    onBack: () -> Unit,
    onChangePhoto: () -> Unit,
    onSave: (
        String,
        String,
        String,
        String,
        String,
        String,
        String,
        String,
        Boolean
    ) -> Unit
) {

    var draftName by remember(displayName) {
        mutableStateOf(displayName)
    }

    var draftUsername by remember(username) {
        mutableStateOf(username)
    }

    var draftPronouns by remember(pronouns) {
        mutableStateOf(pronouns)
    }

    var draftBio by remember(bio) {
        mutableStateOf(bio)
    }

    var draftTalent by remember(talent) {
        mutableStateOf(talent)
    }

    var draftCourse by remember(course) {
        mutableStateOf(course)
    }

    var draftLinks by remember(links) {
        mutableStateOf(links)
    }

    var draftGender by remember(gender) {
        mutableStateOf(gender)
    }

    var draftAiCreator by remember(aiCreator) {
        mutableStateOf(aiCreator)
    }


    Column(
        modifier =
            Modifier
                .fillMaxSize()
                .spotAmbientBackground(ProfileWhite)
                .statusBarsPadding()
    ) {

        EditProfileHeader(
            onBack = onBack,

            onDone = {

                onSave(
                    draftName,
                    draftUsername,
                    draftPronouns,
                    draftBio,
                    draftTalent,
                    draftCourse,
                    draftLinks,
                    draftGender,
                    draftAiCreator
                )
            }
        )


        HorizontalDivider(
            color = ProfileLine
        )


        Column(
            modifier =
                Modifier
                    .fillMaxSize()
                    .verticalScroll(
                        rememberScrollState()
                    )
        ) {

            EditAvatarSection(
                profile = profile,
                avatarUri = avatarUri,
                onChangePhoto = onChangePhoto
            )


            HorizontalDivider(
                color = ProfileLine
            )


            Spacer(
                modifier =
                    Modifier.height(7.dp)
            )


            EditProfileTextRow(
                label = "Name",
                value = draftName,
                placeholder = "Name",
                onValueChange = {
                    draftName = it
                }
            )


            EditProfileTextRow(
                label = "Username",
                value = draftUsername,
                placeholder = "Username",
                onValueChange = {
                    draftUsername = it
                }
            )


            EditProfileTextRow(
                label = "Pronouns",
                value = draftPronouns,
                placeholder = "Pronouns",
                onValueChange = {
                    draftPronouns = it
                }
            )


            EditProfileTextRow(
                label = "Bio",
                value = draftBio,
                placeholder = "Bio",
                singleLine = false,
                onValueChange = {
                    draftBio = it
                }
            )


            EditProfileTextRow(
                label = "Talent",
                value = draftTalent,
                placeholder = "Your talent",
                onValueChange = {
                    draftTalent = it
                }
            )


            // Course has its own separate row.
            EditProfileTextRow(
                label = "Course",
                value = draftCourse,
                placeholder = "Your course",
                singleLine = false,
                onValueChange = {
                    draftCourse = it
                }
            )


            EditProfileTextRow(
                label = "Links",
                value = draftLinks,
                placeholder = "Add links",
                onValueChange = {
                    draftLinks = it
                }
            )


            Spacer(
                modifier =
                    Modifier.height(8.dp)
            )


            HorizontalDivider(
                color = ProfileLine
            )


            EditProfileTextRow(
                label = "Gender",
                value = draftGender,
                placeholder = "Add gender",
                onValueChange = {
                    draftGender = it
                }
            )


            HorizontalDivider(
                color = ProfileLine
            )


            EditToggleRow(
                title = "AI creator",
                subtitle =
                    "Add this label to your profile if your content often uses AI.",

                checked = draftAiCreator,

                onCheckedChange = {
                    draftAiCreator = it
                }
            )


            HorizontalDivider(
                color = ProfileLine
            )


            EditNavigationRow(
                text =
                    "Personal information settings"
            )


            HorizontalDivider(
                color = ProfileLine
            )


            EditNavigationRow(
                text =
                    "Profile visibility"
            )


            Spacer(
                modifier =
                    Modifier.height(36.dp)
            )
        }
    }
}


@Composable
private fun EditProfileHeader(
    onBack: () -> Unit,
    onDone: () -> Unit
) {

    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .height(64.dp)
                .padding(
                    horizontal = 8.dp
                )
    ) {

        IconButton(
            onClick = onBack,

            modifier =
                Modifier
                    .align(
                        Alignment.CenterStart
                    )
                    .size(42.dp)
        ) {

            Icon(
                imageVector =
                    Icons.AutoMirrored.Filled.ArrowBack,

                contentDescription =
                    "Back",

                tint = ProfileBlack,

                modifier =
                    Modifier.size(23.dp)
            )
        }


        Text(
            text = "Edit profile",

            color = ProfileBlack,

            style = androidx.compose.material3.MaterialTheme.typography.titleLarge,

            modifier =
                Modifier.align(
                    Alignment.Center
                )
        )


        Text(
            text = "Done",

            color = ProfileAmberText,

            fontFamily = InterFontFamily,

            fontSize = 11.spotSp,

            fontWeight = FontWeight.SemiBold,

            modifier =
                Modifier
                    .align(
                        Alignment.CenterEnd
                    )
                    .clip(
                        RoundedCornerShape(8.dp)
                    )
                    .clickable(
                        onClick = onDone
                    )
                    .padding(
                        horizontal = 10.dp,
                        vertical = 8.dp
                    )
        )
    }
}


@Composable
private fun EditAvatarSection(
    profile: SpotUiProfile,
    avatarUri: String?,
    onChangePhoto: () -> Unit
) {

    val imageModel =
        avatarUri
            ?.takeIf {
                it.isNotBlank()
            }
            ?: profile.profileImageUrl


    Column(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    vertical = 28.dp
                ),

        horizontalAlignment =
            Alignment.CenterHorizontally
    ) {

        if (imageModel.isNotBlank()) {

            AsyncImage(
                model = imageModel,

                contentDescription =
                    "Profile picture",

                contentScale =
                    ContentScale.Crop,

                modifier =
                    Modifier
                        .size(96.dp)
                        .clip(CircleShape)
                        .background(ProfileAvatarBg)
            )

        } else {

            Box(
                modifier =
                    Modifier
                        .size(96.dp)
                        .clip(CircleShape)
                        .background(ProfileAvatarBg),

                contentAlignment =
                    Alignment.Center
            ) {

                Icon(
                    imageVector =
                        Icons.Filled.Person,

                    contentDescription =
                        "Profile picture",

                    tint = ProfileMuted,

                    modifier =
                        Modifier.size(45.dp)
                )
            }
        }


        Spacer(
            modifier =
                Modifier.height(14.dp)
        )


        Text(
            text =
                "Edit picture or avatar",

            color = ProfileGoldDeep,

            fontFamily = InterFontFamily,

            fontSize = 12.spotSp,

            fontWeight = FontWeight.SemiBold,

            modifier =
                Modifier
                    .clickable(
                        onClick = onChangePhoto
                    )
                    .padding(
                        horizontal = 12.dp,
                        vertical = 6.dp
                    )
        )
    }
}


@Composable
private fun EditProfileTextRow(
    label: String,
    value: String,
    placeholder: String,
    singleLine: Boolean = true,
    onValueChange: (String) -> Unit
) {

    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    start = 18.dp,
                    end = 18.dp
                ),

        verticalAlignment =
            Alignment.Top
    ) {

        Text(
            text = label,

            color = ProfileBlack,

            fontFamily = InterFontFamily,

            fontSize = 12.spotSp,

            fontWeight = FontWeight.Normal,

            modifier =
                Modifier
                    .width(100.dp)
                    .padding(
                        top = 16.dp
                    )
        )


        Column(
            modifier =
                Modifier.weight(1f)
        ) {

            OutlinedTextField(
                value = value,

                onValueChange =
                    onValueChange,

                placeholder = {

                    Text(
                        text = placeholder,

                        color = ProfileMuted,

                        fontFamily = InterFontFamily,

                        fontSize = 11.spotSp
                    )
                },

                textStyle =
                    TextStyle(
                        color = ProfileBlack,
                        fontFamily = InterFontFamily,
                        fontSize = 12.spotSp
                    ),

                singleLine = singleLine,

                minLines =
                    if (singleLine) {
                        1
                    } else {
                        2
                    },

                colors =
                    OutlinedTextFieldDefaults.colors(
                        focusedBorderColor =
                            Color.Transparent,

                        unfocusedBorderColor =
                            Color.Transparent,

                        focusedContainerColor =
                            Color.Transparent,

                        unfocusedContainerColor =
                            Color.Transparent
                    ),

                modifier =
                    Modifier.fillMaxWidth()
            )


            HorizontalDivider(
                color = ProfileLine
            )
        }
    }
}


@Composable
private fun EditToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {

    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    horizontal = 18.dp,
                    vertical = 14.dp
                ),

        verticalAlignment =
            Alignment.CenterVertically
    ) {

        Column(
            modifier =
                Modifier.weight(1f)
        ) {

            Text(
                text = title,

                color = ProfileBlack,

                fontFamily = InterFontFamily,

                fontSize = 12.spotSp,

                fontWeight = FontWeight.Medium
            )


            Spacer(
                modifier =
                    Modifier.height(3.dp)
            )


            Text(
                text = subtitle,

                color = ProfileMuted,

                fontFamily = InterFontFamily,

                fontSize = 9.5.spotSp,

                lineHeight = 13.sp
            )
        }


        Spacer(
            modifier =
                Modifier.width(12.dp)
        )


        Switch(
            checked = checked,

            onCheckedChange =
                onCheckedChange
        )
    }
}


@Composable
private fun EditNavigationRow(
    text: String
) {

    Text(
        text = text,

        color = ProfileGoldDeep,

        fontFamily = InterFontFamily,

        fontSize = 12.spotSp,

        fontWeight = FontWeight.Medium,

        modifier =
            Modifier
                .fillMaxWidth()
                .clickable {
                    // Connect this later to its own settings page.
                }
                .padding(
                    horizontal = 18.dp,
                    vertical = 18.dp
                )
    )
}


@Composable
private fun PostPreviewDialog(
    post: SpotUiPost,
    onDismiss: () -> Unit
) {

    AlertDialog(
        onDismissRequest = onDismiss,

        title = {

            Text(
                text =
                    post.user.displayName,

                color = ProfileBlack,

                fontFamily = InterFontFamily,

                fontSize = 13.spotSp,

                fontWeight = FontWeight.Bold
            )
        },

        text = {

            Column {

                Box(
                    modifier =
                        Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .clip(
                                RoundedCornerShape(12.dp)
                            )
                            .background(
                                ProfileAvatarBg
                            ),

                    contentAlignment =
                        Alignment.Center
                ) {

                    when {

                        post.localImageResources.isNotEmpty() -> {

                            Image(
                                painter =
                                    painterResource(
                                        id =
                                            post.localImageResources.first()
                                    ),

                                contentDescription =
                                    "Post image",

                                contentScale =
                                    ContentScale.Crop,

                                modifier =
                                    Modifier.fillMaxSize()
                            )
                        }


                        !post.mediaUri.isNullOrBlank() -> {

                            AsyncImage(
                                model =
                                    post.mediaUri,

                                contentDescription =
                                    "Post image",

                                contentScale =
                                    ContentScale.Crop,

                                modifier =
                                    Modifier.fillMaxSize()
                            )
                        }


                        else -> {

                            Icon(
                                imageVector =
                                    Icons.Filled.PlayArrow,

                                contentDescription =
                                    null,

                                tint = ProfileBlack,

                                modifier =
                                    Modifier.size(30.dp)
                            )
                        }
                    }
                }


                if (post.caption.isNotBlank()) {

                    Spacer(
                        modifier =
                            Modifier.height(10.dp)
                    )


                    Text(
                        text = post.caption,

                        color = ProfileBlack,

                        fontFamily = InterFontFamily,

                        fontSize = 11.spotSp,

                        lineHeight = 15.sp
                    )
                }
            }
        },

        confirmButton = {

            TextButton(
                onClick = onDismiss
            ) {

                Text(
                    text = "Close",

                    color = ProfileAmberText,

                    fontFamily = InterFontFamily,

                    fontSize = 11.spotSp,

                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    )
}


private fun isVideoUri(
    uri: String
): Boolean {

    val extension =
        uri
            .substringAfterLast(
                ".",
                ""
            )
            .substringBefore("?")
            .lowercase()


    return extension in
            setOf(
                "mp4",
                "mov",
                "m4v",
                "webm",
                "3gp",
                "mkv"
            )
}
