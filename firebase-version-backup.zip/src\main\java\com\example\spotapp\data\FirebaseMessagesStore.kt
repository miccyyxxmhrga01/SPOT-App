package com.example.spotapp.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.cloudinary.android.MediaManager
import com.example.spotapp.data.cloudinary.CloudinaryUploader
import com.google.android.gms.tasks.Task
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.*
import java.io.File
import java.security.MessageDigest
import java.net.URL
import javax.net.ssl.HttpsURLConnection
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

internal fun validChatMediaUrl(url: String, path: String): Boolean {
    if (!path.matches(Regex("chat_media/[A-Za-z0-9_-]{1,100}/[A-Za-z0-9_-]{1,128}/[A-Za-z0-9_-]{1,100}"))) return false
    val parsed = Uri.parse(url)
    return parsed.scheme == "https" && parsed.host == "res.cloudinary.com" && parsed.port == -1 &&
        parsed.query == null && parsed.fragment == null &&
        parsed.path.orEmpty().matches(Regex("/jcuzzxsz/raw/upload/v[0-9]+/spot/${Regex.escape(path)}/[A-Za-z0-9_.-]+[.]bin"))
}

class FirebaseMessagesStore(
    override val uid: String,
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val storage: FirebaseStorage = FirebaseStorage.getInstance()
) : MessagesStore {
    private val chats get() = db.collection("conversations")
    private val account get() = db.collection("users").document(uid)
    private fun checkAccount() { check(auth.currentUser?.uid == uid) { "Sign in again to use Messages." } }

    override fun inbox(): Flow<MessagesInbox> = combine(
        chats.whereArrayContains("memberIds", uid).orderBy("updatedAt", Query.Direction.DESCENDING).limit(100).snapshots(),
        chats.whereArrayContains("invitedIds", uid).orderBy("createdAt", Query.Direction.DESCENDING).limit(100).snapshots(),
        account.collection("chatSettings").snapshots(), account.collection("blockedUsers").snapshots()
    ) { joined, requests, prefs, blocked ->
        MessagesInbox(joined.mapNotNull(::parseConversation), requests.mapNotNull(::parseConversation),
            prefs.associate { it.id to ChatPreferences(it.getString("nickname").orEmpty(), it.getBoolean("muted") == true,
                it.getTimestamp("hiddenAt")?.toDate()?.time ?: 0, it.getTimestamp("readAt")?.toDate()?.time ?: 0) },
            blocked.map { it.id }.toSet(), loading = false)
    }.catch { emit(MessagesInbox(loading = false, error = messagesError(it))) }

    override fun messages(id: String): Flow<List<CampusMessage>> = chats.document(id).collection("messages")
        .orderBy("createdAt", Query.Direction.DESCENDING).orderBy(FieldPath.documentId(), Query.Direction.DESCENDING)
        .limit(50).snapshots().map { docs -> docs.map(::parseMessage).reversed() }

    override suspend fun olderMessages(id: String, before: CampusMessage): List<CampusMessage> =
        chats.document(id).collection("messages").orderBy("createdAt", Query.Direction.DESCENDING)
            .orderBy(FieldPath.documentId(), Query.Direction.DESCENDING)
            .startAfter(Timestamp(java.util.Date(before.createdAt)), before.id).limit(50)
            .get(Source.SERVER).awaitChat().documents.map(::parseMessage).reversed()

    override suspend fun syncProfile() { checkAccount(); ProfileRepository(db, auth).syncPublicProfile() }

    override suspend fun people(search: String): List<ChatPerson> {
        checkAccount()
        val key = search.trim().lowercase().removePrefix("@")
        val directory = db.collection("publicProfiles")
        val docs = if (key.isBlank()) directory.orderBy("nameKey").limit(30).get().awaitChat().documents
        else coroutineScope {
            listOf("nameKey", "usernameKey").map { field -> async {
                directory.orderBy(field).startAt(key).endAt(key + "\uf8ff").limit(20).get().awaitChat().documents
            } }.awaitAll().flatten()
        }
        return docs.distinctBy { it.id }.filter { it.id != uid }.map(::parsePerson)
    }
    override suspend fun person(uid: String): ChatPerson? = db.collection("publicProfiles").document(uid)
        .get(Source.SERVER).awaitChat().takeIf { it.exists() }?.let(::parsePerson)

    override suspend fun create(people: List<ChatPerson>, title: String, note: String, group: Boolean, id: String): String {
        checkAccount()
        require(people.size in 1..7 && people.map { it.uid }.distinct().size == people.size && people.none { it.uid == uid }) { "Choose one to seven campus connections." }
        require(group || people.size == 1) { "Choose one person for a direct chat." }
        require(!group || title.trim().length in 1..60) { "Give your collaboration a name (up to 60 characters)." }
        require(note.length <= 500) { "Keep the invitation under 500 characters." }
        syncProfile()
        val ref = chats.document(id)
        db.runTransaction { transaction ->
            if (transaction.get(ref).exists()) return@runTransaction
            val ids = listOf(uid) + people.map { it.uid }
            val profiles = ids.associateWith { personId ->
                val snapshot = transaction.get(db.collection("publicProfiles").document(personId))
                check(snapshot.exists()) { "This person hasn't activated Messages yet." }
                mapOf("displayName" to snapshot.getString("displayName").orEmpty(), "username" to snapshot.getString("username").orEmpty(),
                    "profileImageUrl" to snapshot.getString("profileImageUrl").orEmpty())
            }
            transaction.set(ref, mapOf("kind" to if (group) "group" else "direct", "demo" to false,
                "title" to title.trim(), "creatorId" to uid, "partyIds" to ids, "memberIds" to listOf(uid),
                "invitedIds" to people.map { it.uid }, "people" to profiles, "inviteNote" to note.trim(),
                "preview" to "", "lastMessageId" to "", "lastSenderId" to "",
                "createdAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp()))
        }.awaitChat()
        return id
    }

    override suspend fun respond(id: String, accept: Boolean) {
        checkAccount()
        val ref = chats.document(id)
        db.runTransaction { tx ->
            val old = tx.get(ref)
            val invited = old.strings("invitedIds")
            if (uid !in invited) return@runTransaction
            val members = old.strings("memberIds")
            tx.update(ref, mapOf("invitedIds" to invited.filter { it != uid },
                "memberIds" to if (accept) (members + uid).distinct() else members))
        }.awaitChat()
    }

    override suspend fun send(id: String, draft: ChatDraft) {
        checkAccount()
        draft.error()?.let { throw IllegalArgumentException(it) }
        val chat = chats.document(id)
        val message = chat.collection("messages").document(draft.id)
        db.runTransaction { tx ->
            if (tx.get(message).exists()) return@runTransaction // Retry after a lost acknowledgement uses the same id.
            val state = tx.get(chat)
            check(uid in state.strings("memberIds")) { "Join this conversation before sending a message." }
            val attachment = draft.attachment?.let {
                mapOf("path" to it.path, "mime" to it.mime, "name" to it.name, "size" to it.size) +
                    if (it.encrypted) mapOf("url" to it.url, "key" to it.key, "iv" to it.iv) else emptyMap()
            }
            tx.set(message, mapOf("senderId" to uid, "text" to draft.text.trim(), "attachment" to attachment, "createdAt" to FieldValue.serverTimestamp()))
            tx.update(chat, mapOf("preview" to draft.text.trim().take(160).ifBlank { if (draft.attachment?.isVideo == true) "Video" else "Photo" },
                "lastSenderId" to uid, "lastMessageId" to draft.id, "updatedAt" to FieldValue.serverTimestamp()))
        }.awaitChat()
    }

    override suspend fun unsend(id: String, messageId: String) {
        checkAccount()
        val chat = chats.document(id)
        val message = chat.collection("messages").document(messageId)
        db.runTransaction { tx ->
            val old = tx.get(message)
            check(old.exists()) { "This message is no longer available." }
            check(old.getString("senderId") == uid) { "You can only unsend your own messages." }
            if (old.contains("unsentAt")) return@runTransaction
            val latest = tx.get(chat).getString("lastMessageId") == messageId
            // Clearing the attachment also drops its decryption key, so the stored file can't be opened again.
            tx.update(message, mapOf("text" to "", "attachment" to null, "unsentAt" to FieldValue.serverTimestamp()))
            if (latest) tx.update(chat, "preview", UNSENT_MESSAGE_PREVIEW)
        }.awaitChat()
    }

    override suspend fun deleteForMe(id: String, messageId: String) {
        checkAccount()
        hidden(id).document(messageId).set(mapOf("createdAt" to FieldValue.serverTimestamp())).awaitChat()
    }

    override fun hiddenMessages(id: String): Flow<Set<String>> =
        hidden(id).snapshots().map { docs -> docs.map { it.id }.toSet() }

    private fun hidden(id: String) = account.collection("chatSettings").document(id).collection("hiddenMessages")

    override suspend fun upload(context: Context, id: String, messageId: String, uri: Uri, mime: String?, progress: (Float) -> Unit): ChatAttachment {
        checkAccount()
        val type = mime?.takeIf { it.isNotBlank() } ?: context.contentResolver.getType(uri).orEmpty()
        val source = withContext(Dispatchers.IO) {
            var name = "Photo"
            var size = -1L
            if (uri.scheme != "file") context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use {
                if (it.moveToFirst()) { name = it.getString(0).orEmpty(); if (!it.isNull(1)) size = it.getLong(1) }
            }
            if (uri.scheme == "file") size = File(uri.path.orEmpty()).length()
            ChatAttachment("chat_media/$id/$uid/$messageId", type, name.take(120), size)
        }
        require(type.startsWith("image/") || type.startsWith("video/")) { "Choose a photo or video." }
        if (source.size > ChatMediaCrypto.MAX_BYTES) throw IllegalArgumentException("Choose a photo or video under 25 MB.")
        // The existing Firebase Storage bucket is not provisioned. Protect the chat media before
        // using the app's Cloudinary upload preset: the public URL alone cannot reveal the photo.
        val encrypted = File.createTempFile("chat-media-", ".bin", context.cacheDir)
        try {
            val (secret, actualSize) = withContext(Dispatchers.IO) {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    encrypted.outputStream().use { output -> ChatMediaCrypto.encrypt(input, output, source.path) }
                } ?: throw IllegalArgumentException("Couldn't read that photo or video. Choose it again.")
            }
            val url = suspendCancellableCoroutine<String> { continuation ->
                val requestId = CloudinaryUploader.uploadMedia(Uri.fromFile(encrypted),
                    "spot/chat_media/$id/$uid/$messageId",
                    onSuccess = { if (continuation.isActive) continuation.resume(it) },
                    onError = { reason ->
                        if (continuation.isActive) continuation.resumeWithException(IllegalStateException(
                            "Photo or video upload failed. " + reason.take(180).ifBlank { "Please retry." }))
                    },
                    onProgress = { done, total -> if (total > 0) progress((done.toFloat() / total).coerceIn(0f, 1f)) },
                    resourceType = "raw")
                continuation.invokeOnCancellation { MediaManager.get().cancelRequest(requestId) }
            }
            require(validChatMediaUrl(url, source.path)) { "The media service returned an invalid attachment. Retry." }
            return source.copy(size = actualSize, url = url, key = secret.key, iv = secret.iv)
        } finally { encrypted.delete() }
    }

    override suspend fun mediaFile(context: Context, attachment: ChatAttachment): Uri = withContext(Dispatchers.IO) {
        checkAccount()
        val key = MessageDigest.getInstance("SHA-256").digest((attachment.path + attachment.url + attachment.key).toByteArray())
            .joinToString("") { "%02x".format(it) }
        val folder = File(context.cacheDir, "chat-media/$uid").apply { mkdirs() }
        val file = File(folder, key + if (attachment.isVideo) ".mp4" else ".jpg")
        if (!file.exists() || file.length() != attachment.size) {
            val temp = File.createTempFile(key, ".part", folder)
            try {
                if (attachment.encrypted) {
                    require(validChatMediaUrl(attachment.url, attachment.path)) { "This attachment address is invalid." }
                    val connection = (URL(attachment.url).openConnection() as HttpsURLConnection).apply {
                        connectTimeout = 15_000; readTimeout = 30_000; instanceFollowRedirects = false
                    }
                    try {
                        require(connection.responseCode == 200) { "Couldn't download this attachment. Retry." }
                        require(connection.contentLengthLong in -1..(attachment.size + 16)) { "This attachment is too large." }
                        connection.inputStream.use { input -> temp.outputStream().use { output ->
                            ChatMediaCrypto.decrypt(input, output, attachment.path,
                                ChatMediaCrypto.Secret(attachment.key, attachment.iv), attachment.size)
                        } }
                    } finally { connection.disconnect() }
                } else {
                    // Existing Firebase Storage attachments remain readable if their bucket is restored.
                    val task = storage.reference.child(attachment.path).getFile(temp)
                    suspendCancellableCoroutine<Unit> { continuation ->
                        task.addOnSuccessListener { if (continuation.isActive) continuation.resume(Unit) }
                            .addOnFailureListener { if (continuation.isActive) continuation.resumeWithException(it) }
                        continuation.invokeOnCancellation { task.cancel() }
                    }
                }
                checkAccount()
                check(temp.renameTo(file)) { "Couldn't open this attachment. Please retry." }
            } finally { temp.delete() }
            folder.listFiles()?.filter { it != file && System.currentTimeMillis() - it.lastModified() > 7 * 86400000L }?.forEach { it.delete() }
        }
        Uri.fromFile(file)
    }

    override suspend fun preferences(id: String, values: Map<String, Any>) {
        checkAccount()
        val data = values.mapValues { (key, value) -> if (key in listOf("readAt", "hiddenAt")) FieldValue.serverTimestamp() else value }
        account.collection("chatSettings").document(id).set(data, SetOptions.merge()).awaitChat()
    }
    override suspend fun block(otherUid: String, blocked: Boolean) {
        checkAccount()
        require(otherUid.isNotBlank() && otherUid != uid)
        val ref = account.collection("blockedUsers").document(otherUid)
        if (blocked) ref.set(mapOf("createdAt" to FieldValue.serverTimestamp())).awaitChat() else ref.delete().awaitChat()
    }
    override suspend fun leave(id: String) {
        checkAccount()
        chats.document(id).update("memberIds", FieldValue.arrayRemove(uid)).awaitChat()
    }
    override suspend fun report(id: String, reason: String) {
        checkAccount()
        require(reason.trim().length in 5..1000) { "Describe the issue in 5–1,000 characters." }
        db.collection("conversationReports").document("${id}_$uid").set(mapOf("conversationId" to id,
            "reporterId" to uid, "reason" to reason.trim(), "createdAt" to FieldValue.serverTimestamp())).awaitChat()
    }

    override suspend fun addSamples() {
        checkAccount()
        for (group in listOf(false, true)) {
            val id = "demo_${uid}_${if (group) "group" else "chat"}"
            val ref = chats.document(id)
            db.runTransaction { tx ->
                if (tx.get(ref).exists()) return@runTransaction
                val texts = if (group) listOf("Welcome to the Campus Creators sample collaboration.", "Try sharing ideas, searching this chat, or changing its nickname.")
                    else listOf("Welcome to Messages! This is a private sample chat, not a real person.", "Send a message here to try the experience. Sample chats never contact other accounts.")
                tx.set(ref, mapOf("kind" to if (group) "group" else "direct", "demo" to true,
                    "title" to if (group) "Campus Creators · Demo" else "SPOT Guide · Demo", "creatorId" to uid,
                    "partyIds" to listOf(uid), "memberIds" to listOf(uid), "invitedIds" to emptyList<String>(), "people" to emptyMap<String, Any>(),
                    "inviteNote" to "Private sample conversation", "preview" to texts.last(), "lastMessageId" to "sample-1", "lastSenderId" to "demo",
                    "createdAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp()))
                texts.forEachIndexed { index, text -> tx.set(ref.collection("messages").document("sample-$index"),
                    mapOf("senderId" to "demo", "text" to text, "attachment" to null, "createdAt" to FieldValue.serverTimestamp())) }
            }.awaitChat()
            account.collection("chatSettings").document(id).set(mapOf("hiddenAt" to FieldValue.delete()), SetOptions.merge()).awaitChat()
        }
    }

    private fun parsePerson(doc: DocumentSnapshot) = ChatPerson(doc.id, doc.getString("displayName").orEmpty(), doc.getString("username").orEmpty(), doc.getString("profileImageUrl").orEmpty())
    private fun parseConversation(doc: DocumentSnapshot): CampusConversation? {
        val creator = doc.getString("creatorId") ?: return null
        val people = (doc.get("people") as? Map<*, *>).orEmpty().mapNotNull { (key, value) ->
            val data = value as? Map<*, *> ?: return@mapNotNull null
            val id = key as? String ?: return@mapNotNull null
            id to ChatPerson(id, data["displayName"] as? String ?: "Campus connection", data["username"] as? String ?: "", data["profileImageUrl"] as? String ?: "")
        }.toMap()
        return CampusConversation(doc.id, doc.getString("title").orEmpty(), doc.getString("kind") ?: "direct", doc.getBoolean("demo") == true,
            creator, doc.strings("partyIds"), doc.strings("memberIds"), doc.strings("invitedIds"), people,
            doc.getString("inviteNote").orEmpty(), doc.getString("preview").orEmpty(), doc.getString("lastSenderId").orEmpty(),
            doc.getTimestamp("updatedAt")?.toDate()?.time ?: 0, doc.getTimestamp("createdAt")?.toDate()?.time ?: 0)
    }
    private fun parseMessage(doc: DocumentSnapshot): CampusMessage {
        val media = doc.get("attachment") as? Map<*, *>
        return CampusMessage(doc.id, doc.getString("senderId").orEmpty(), doc.getString("text").orEmpty(),
            media?.let { ChatAttachment(it["path"] as? String ?: "", it["mime"] as? String ?: "", it["name"] as? String ?: "",
                (it["size"] as? Number)?.toLong() ?: 0, it["url"] as? String ?: "", it["key"] as? String ?: "", it["iv"] as? String ?: "") },
            doc.getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0, doc.metadata.hasPendingWrites(),
            unsent = doc.contains("unsentAt"))
    }
}

private fun DocumentSnapshot.strings(field: String) = (get(field) as? List<*>)?.filterIsInstance<String>().orEmpty()
private fun Query.snapshots(): Flow<List<DocumentSnapshot>> = callbackFlow {
    val registration = addSnapshotListener(MetadataChanges.INCLUDE) { snapshot, error ->
        if (error != null) close(error) else trySend(snapshot?.documents.orEmpty())
    }
    awaitClose { registration.remove() }
}
private suspend fun <T> Task<T>.awaitChat(): T = suspendCancellableCoroutine { continuation ->
    addOnSuccessListener { if (continuation.isActive) continuation.resume(it) }
    addOnFailureListener { if (continuation.isActive) continuation.resumeWithException(it) }
}
fun messagesError(error: Throwable): String = when (error) {
    is IllegalArgumentException, is IllegalStateException -> error.message ?: "Please check your message and retry."
    is FirebaseFirestoreException -> when (error.code) {
        FirebaseFirestoreException.Code.PERMISSION_DENIED -> "Messages couldn't access this conversation. Check that your invitation was accepted and try again."
        FirebaseFirestoreException.Code.UNAVAILABLE -> "You're offline. Reconnect and retry; your draft is still here."
        else -> "Messages couldn't finish that action. Please retry."
    }
    is com.google.firebase.storage.StorageException -> "The attachment couldn't upload or open. Please retry when media storage is available."
    else -> "Something interrupted Messages. Please retry."
}
