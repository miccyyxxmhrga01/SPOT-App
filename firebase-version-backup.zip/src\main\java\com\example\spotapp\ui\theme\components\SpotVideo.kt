package com.example.spotapp.ui.theme.components

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.PlaybackException
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.ui.AspectRatioFrameLayout
import coil3.compose.AsyncImage
import com.example.spotapp.data.cloudinaryVideoThumbnail
import kotlinx.coroutines.delay

/** One decoder/player for the entire social navigation tree, including outgoing animations. */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
internal class SpotVideoController(context: Context) {
    val player = ExoPlayer.Builder(context.applicationContext).build().apply { repeatMode = Player.REPEAT_MODE_ONE }
    var owner by mutableStateOf<Any?>(null); private set
    var buffering by mutableStateOf(false); private set
    var failure by mutableStateOf(false); private set
    var playing by mutableStateOf(false); private set
    var paused by mutableStateOf(false); private set
    private var foreground = false
    private val positions = linkedMapOf<String, Long>()
    private var currentUrl = ""
    init {
        player.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) { buffering = state == Player.STATE_BUFFERING }
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlayerError(error: PlaybackException) { failure = true; buffering = false }
        })
    }
    fun claim(token: Any, url: String, startMs: Long = 0, endMs: Long = 0) {
        val playbackKey = if (startMs == 0L && endMs == 0L) url else "$url|$startMs|$endMs"
        player.pause()
        owner = token
        paused = false
        if (currentUrl != playbackKey) {
            if (currentUrl.isNotEmpty()) positions[currentUrl] = player.currentPosition
            while (positions.size > 20) positions.remove(positions.keys.first())
            currentUrl = playbackKey; failure = false
            val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs(startMs.coerceAtLeast(0))
            if (endMs > startMs) clip.setEndPositionMs(endMs)
            player.setMediaItem(MediaItem.Builder().setUri(url).setClippingConfiguration(clip.build()).build(), positions[playbackKey] ?: 0)
            player.prepare()
        }
        sync()
    }
    fun unclaim(token: Any) { if (owner === token) { owner = null; player.pause() } }
    fun foreground(value: Boolean) { foreground = value; sync() }
    fun toggle() { paused = !paused; sync() }
    fun retry() { failure = false; player.prepare(); sync() }
    private fun sync() { player.playWhenReady = foreground && owner != null && !paused && !failure }
    fun release() { player.release() }
}

internal val LocalSpotVideo = staticCompositionLocalOf<SpotVideoController?> { null }
internal val LocalSpotVideoEnabled = compositionLocalOf { true }

@Composable
internal fun ProvideSpotVideo(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val controller = remember { SpotVideoController(context) }
    DisposableEffect(controller, lifecycle) {
        fun update() = controller.foreground(lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED))
        val observer = LifecycleEventObserver { _, _ -> update() }
        lifecycle.addObserver(observer); update()
        onDispose { lifecycle.removeObserver(observer); controller.release() }
    }
    CompositionLocalProvider(LocalSpotVideo provides controller, content = content)
}

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
@Composable
internal fun SpotVideo(url: String, active: Boolean, modifier: Modifier = Modifier, muted: Boolean = true,
    onTap: (() -> Unit)? = null, onQualifiedView: (() -> Unit)? = null,
    clipStartMs: Long = 0, clipEndMs: Long = 0, fill: Boolean = false, showControls: Boolean = true) {
    val controller = LocalSpotVideo.current
    if (controller == null) {
        ProvideSpotVideo { SpotVideo(url, active, modifier, muted, onTap, onQualifiedView, clipStartMs, clipEndMs, fill, showControls) }
        return
    }
    val enabled = active && LocalSpotVideoEnabled.current
    val token = remember(url, clipStartMs, clipEndMs) { Any() }
    DisposableEffect(controller, token, enabled) {
        if (enabled) controller.claim(token, url, clipStartMs, clipEndMs)
        onDispose { controller.unclaim(token) }
    }
    val owns = enabled && controller.owner === token
    SideEffect { if (owns) controller.player.volume = if (muted) 0f else 1f }
    var progress by remember(url) { mutableFloatStateOf(0f) }
    val latestView by rememberUpdatedState(onQualifiedView)
    LaunchedEffect(owns, controller.playing) {
        if (owns && controller.playing) { delay(2000); latestView?.invoke() }
    }
    LaunchedEffect(owns) {
        while (owns) {
            val duration = controller.player.duration
            progress = if (duration > 0) (controller.player.currentPosition.toFloat() / duration).coerceIn(0f, 1f) else 0f
            delay(250)
        }
    }
    Box(modifier.background(Color.Black).testTag(if (owns) "active-social-video" else "inactive-social-video"), contentAlignment = Alignment.Center) {
        AsyncImage(cloudinaryVideoThumbnail(url), "Video preview", Modifier.fillMaxSize(), contentScale = if (fill) ContentScale.Crop else ContentScale.Fit)
        if (owns) AndroidView(factory = { context -> PlayerView(context).apply {
            useController = false
            resizeMode = if (fill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
            player = controller.player
            setKeepContentOnPlayerReset(true)
        } }, update = { it.player = controller.player; it.keepScreenOn = controller.playing; it.resizeMode = if (fill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT },
            onRelease = { it.player = null; it.keepScreenOn = false }, modifier = Modifier.fillMaxSize())
        if (showControls) Box(Modifier.fillMaxSize().clickable(onClickLabel = if (onTap != null) "Open reel" else "Play or pause video") {
            if (onTap != null) onTap() else if (owns) controller.toggle()
        })
        if (owns && controller.failure) TextButton(onClick = controller::retry) { Text("Video couldn't play. Retry", color = Color.White) }
        else if (owns && controller.buffering) CircularProgressIndicator(Modifier.size(28.dp), color = Color.White, strokeWidth = 2.dp)
        else if (showControls && (!owns || controller.paused)) Icon(Icons.Filled.PlayArrow, "Play video", Modifier.size(44.dp), tint = Color.White)
        if (owns && showControls) LinearProgressIndicator(progress = { progress }, modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(2.dp),
            color = Color(0xFFFDD87A), trackColor = Color.White.copy(alpha = 0.2f))
    }
}
