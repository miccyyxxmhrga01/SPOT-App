package com.example.spotapp.ui.theme.screens.discover

import com.example.spotapp.ui.theme.components.spotAmbientBackground
import com.example.spotapp.ui.theme.components.SpotAvatar
import com.example.spotapp.ui.theme.components.SpotSectionTab
import com.example.spotapp.ui.theme.components.SpotSectionTabs

import com.example.spotapp.ui.theme.spotSp

import android.net.Uri
import android.widget.VideoView

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width

import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send

import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Verified

import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Handshake
import androidx.compose.material.icons.outlined.Groups

import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text

import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale

import androidx.compose.ui.graphics.Color

import androidx.compose.ui.layout.ContentScale

import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource

import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import androidx.compose.ui.viewinterop.AndroidView

import coil3.compose.AsyncImage

import com.example.spotapp.ui.theme.InterFontFamily

import com.example.spotapp.ui.theme.models.SpotMockData
import com.example.spotapp.ui.theme.models.SpotRoute
import com.example.spotapp.ui.theme.models.SpotUiEvent
import com.example.spotapp.ui.theme.models.SpotUiGroup
import com.example.spotapp.ui.theme.models.SpotUiPost
import com.example.spotapp.ui.theme.models.SpotUiProfile

import com.example.spotapp.ui.theme.navigation.SpotMainBottomNavigation


private val DiscoverWhite =
    Color.White

private val DiscoverBlack =
    Color(0xFF111111)

private val DiscoverSecondary =
    Color(0xFF838383)

private val DiscoverMuted =
    Color(0xFFA1A1A1)

private val DiscoverLine =
    Color(0xFFE5E5E5)

private val DiscoverPlaceholder =
    Color(0xFFD9D9D9)

private val DiscoverGold =
    Color(0xFFFDD87A)

private val DiscoverGoldDeep =
    Color(0xFFE8B84B)

private val DiscoverLikeRed =
    Color(0xFFE5484D)


private val DiscoverVideoExtensions =
    setOf(
        "mp4",
        "mov",
        "webm",
        "mkv",
        "3gp"
    )


private fun isDiscoverVideoUri(
    uri: String?
): Boolean {

    if (uri.isNullOrBlank()) {
        return false
    }

    return uri
        .substringAfterLast(
            ".",
            ""
        )
        .substringBefore(
            "?"
        )
        .lowercase() in DiscoverVideoExtensions
}


@Composable
fun DiscoverScreen(profile: SpotUiProfile, onNavigate: (SpotRoute) -> Unit,
    onProfileClick: (SpotUiProfile) -> Unit, onOpenReels: (SpotUiPost) -> Unit,
    showBottomNavigation: Boolean = true, onWorkOpen: (String) -> Unit = {}) {
    var selectedTopTab by rememberSaveable { mutableStateOf("Explore") }
    var collabRequested by remember { mutableStateOf(false) }
    Scaffold(modifier = Modifier.spotAmbientBackground(Color(0xFFFFFCF6)), containerColor = Color.Transparent, contentWindowInsets = WindowInsets(0, 0, 0, 0), bottomBar = {
        if (showBottomNavigation) SpotMainBottomNavigation(SpotRoute.DISCOVER, profile, onNavigate = onNavigate)
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).statusBarsPadding()) {
            DiscoverHeader { onNavigate(SpotRoute.SEARCH) }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (profile.accountType == com.example.spotapp.data.AccountType.TALENT_SEEKER)
                    androidx.compose.material3.AssistChip({ onWorkOpen("talent") }, { Text("Find creators") })
            }
            DiscoverSections(selectedTopTab) { selectedTopTab = it }
            androidx.compose.animation.AnimatedContent(selectedTopTab, label = "Discover section") { tab ->
                when (tab) {
                    "Groups" -> DiscoverCommunity(false, profile, onProfileClick)
                    "Events" -> DiscoverCommunity(true, profile, onProfileClick)
                    "Collabs" -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                        Text("Campus preview · sample content", style = MaterialTheme.typography.bodySmall,
                            color = DiscoverSecondary, modifier = Modifier.padding(16.dp))
                        CollabsContent(collabRequested) { collabRequested = !collabRequested }
                    }
                    else -> DiscoverExplore(profile, onProfileClick, onOpenReels)
                }
            }
        }
    }
}

@Composable
private fun DiscoverHeader(
    onSearch: () -> Unit
) {

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(
                58.dp
            )
            .padding(
                start =
                    18.dp,

                end =
                    12.dp
            ),

        verticalAlignment =
            Alignment.CenterVertically
    ) {

        Column(
            modifier =
                Modifier.weight(
                    1f
                )
        ) {

            Text(
                text =
                    "Discover",

                color =
                    DiscoverBlack,

                style =
                    MaterialTheme.typography.headlineSmall,

                fontWeight =
                    FontWeight.Bold
            )


            Spacer(
                modifier =
                    Modifier.height(
                        1.dp
                    )
            )


        }


        Surface(
            modifier =
                Modifier.size(
                    36.dp
                ),

            shape =
                CircleShape,

            color =
                DiscoverWhite,

            border =
                BorderStroke(
                    width =
                        1.dp,

                    color =
                        DiscoverLine
                )
        ) {

            IconButton(
                onClick =
                    onSearch
            ) {

                Icon(
                    imageVector =
                        Icons.Filled.Search,

                    contentDescription =
                        "Search",

                    tint =
                        DiscoverBlack,

                    modifier =
                        Modifier.size(
                            20.dp
                        )
                )
            }
        }
    }
}


@Composable
internal fun DiscoverSections(selected: String, onSelected: (String) -> Unit) {
    SpotSectionTabs(listOf(
        SpotSectionTab("Explore", "Explore", Icons.Outlined.Explore),
        SpotSectionTab("Events", "Events", Icons.Outlined.CalendarMonth),
        SpotSectionTab("Collabs", "Collabs", Icons.Outlined.Handshake),
        SpotSectionTab("Groups", "Groups", Icons.Outlined.Groups)
    ), selected, onSelected)
}


@Composable
private fun EventsContent(
    events: List<SpotUiEvent>,
    onToggleInterested: (SpotUiEvent) -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                horizontal =
                    12.dp,

                vertical =
                    12.dp
            ),

        verticalArrangement =
            Arrangement.spacedBy(
                9.dp
            )
    ) {

        DiscoverSectionHeader(
            title =
                "Campus events",

            description =
                "Find upcoming activities and performances."
        )


        events.forEach { event ->

            Surface(
                modifier =
                    Modifier.fillMaxWidth(),

                shape =
                    RoundedCornerShape(
                        16.dp
                    ),

                border =
                    BorderStroke(
                        width =
                            1.dp,

                        color =
                            DiscoverLine
                    ),

                color =
                    DiscoverWhite
            ) {

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            13.dp
                        ),

                    verticalAlignment =
                        Alignment.CenterVertically
                ) {

                    Box(
                        modifier =
                            Modifier
                                .size(
                                    38.dp
                                )
                                .background(
                                    DiscoverGold.copy(
                                        alpha =
                                            0.35f
                                    ),

                                    RoundedCornerShape(
                                        11.dp
                                    )
                                ),

                        contentAlignment =
                            Alignment.Center
                    ) {

                        Icon(
                            imageVector =
                                Icons.Filled.AutoAwesome,

                            contentDescription =
                                null,

                            tint =
                                DiscoverBlack,

                            modifier =
                                Modifier.size(
                                    18.dp
                                )
                        )
                    }


                    Spacer(
                        modifier =
                            Modifier.width(
                                10.dp
                            )
                    )


                    Column(
                        modifier =
                            Modifier.weight(
                                1f
                            )
                    ) {

                        Text(
                            text =
                                event.title,

                            fontFamily =
                                InterFontFamily,

                            fontWeight =
                                FontWeight.SemiBold,

                            fontSize =
                                12.spotSp,

                            color =
                                DiscoverBlack
                        )


                        Spacer(
                            modifier =
                                Modifier.height(
                                    3.dp
                                )
                        )


                        Text(
                            text =
                                event.subtitle,

                            color =
                                DiscoverSecondary,

                            fontFamily =
                                InterFontFamily,

                            fontSize =
                                9.spotSp,

                            lineHeight =
                                13.sp
                        )
                    }


                    Spacer(
                        modifier =
                            Modifier.width(
                                8.dp
                            )
                    )


                    DiscoverToggleButton(
                        isDone =
                            event.interested,

                        doneLabel =
                            "Interested",

                        actionLabel =
                            "Join",

                        onClick = {

                            onToggleInterested(
                                event
                            )
                        }
                    )
                }
            }
        }
    }
}


@Composable
private fun CollabsContent(
    requested: Boolean,
    onRequest: () -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                horizontal =
                    12.dp,

                vertical =
                    12.dp
            )
    ) {

        DiscoverSectionHeader(
            title =
                "Collaborations",

            description =
                "Connect with students and create together."
        )


        Spacer(
            modifier =
                Modifier.height(
                    9.dp
                )
        )


        Surface(
            modifier =
                Modifier.fillMaxWidth(),

            shape =
                RoundedCornerShape(
                    16.dp
                ),

            border =
                BorderStroke(
                    width =
                        1.dp,

                    color =
                        DiscoverLine
                ),

            color =
                DiscoverWhite
        ) {

            Column(
                modifier =
                    Modifier.padding(
                        14.dp
                    )
            ) {

                Row(
                    verticalAlignment =
                        Alignment.CenterVertically
                ) {

                    Box(
                        modifier =
                            Modifier
                                .size(
                                    40.dp
                                )
                                .background(
                                    DiscoverGold.copy(
                                        alpha =
                                            0.35f
                                    ),

                                    RoundedCornerShape(
                                        12.dp
                                    )
                                ),

                        contentAlignment =
                            Alignment.Center
                    ) {

                        Icon(
                            imageVector =
                                Icons.Filled.Handshake,

                            contentDescription =
                                null,

                            tint =
                                DiscoverBlack,

                            modifier =
                                Modifier.size(
                                    20.dp
                                )
                        )
                    }


                    Spacer(
                        modifier =
                            Modifier.width(
                                10.dp
                            )
                    )


                    Column {

                        Text(
                            text =
                                "Looking for a guitarist",

                            fontFamily =
                                InterFontFamily,

                            fontSize =
                                13.spotSp,

                            fontWeight =
                                FontWeight.SemiBold,

                            color =
                                DiscoverBlack
                        )


                        Spacer(
                            modifier =
                                Modifier.height(
                                    2.dp
                                )
                        )


                        Text(
                            text =
                                "Campus performance",

                            fontFamily =
                                InterFontFamily,

                            fontSize =
                                9.spotSp,

                            fontWeight =
                                FontWeight.Medium,

                            color =
                                DiscoverMuted
                        )
                    }
                }


                Spacer(
                    modifier =
                        Modifier.height(
                            11.dp
                        )
                )


                Text(
                    text =
                        "Campus performance this Friday. Acoustic or electric guitar welcome.",

                    fontFamily =
                        InterFontFamily,

                    fontSize =
                        10.spotSp,

                    lineHeight =
                        15.sp,

                    color =
                        DiscoverSecondary
                )


                Spacer(
                    modifier =
                        Modifier.height(
                            12.dp
                        )
                )


                DiscoverToggleButton(
                    isDone =
                        requested,

                    doneLabel =
                        "Request sent",

                    actionLabel =
                        "Send collab request",

                    onClick =
                        onRequest,

                    modifier =
                        Modifier.fillMaxWidth()
                )
            }
        }
    }
}


@Composable
private fun GroupsContent(
    groups: List<SpotUiGroup>,
    onToggleJoin: (SpotUiGroup) -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                horizontal =
                    12.dp,

                vertical =
                    12.dp
            ),

        verticalArrangement =
            Arrangement.spacedBy(
                9.dp
            )
    ) {

        DiscoverSectionHeader(
            title =
                "Campus groups",

            description =
                "Join communities that match your interests."
        )


        groups.forEach { group ->

            Surface(
                modifier =
                    Modifier.fillMaxWidth(),

                shape =
                    RoundedCornerShape(
                        16.dp
                    ),

                border =
                    BorderStroke(
                        width =
                            1.dp,

                        color =
                            DiscoverLine
                    ),

                color =
                    DiscoverWhite
            ) {

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            12.dp
                        ),

                    verticalAlignment =
                        Alignment.CenterVertically
                ) {

                    Box(
                        modifier =
                            Modifier
                                .size(
                                    40.dp
                                )
                                .background(
                                    DiscoverPlaceholder,
                                    CircleShape
                                ),

                        contentAlignment =
                            Alignment.Center
                    ) {

                        Icon(
                            imageVector =
                                Icons.Filled.Groups,

                            contentDescription =
                                null,

                            tint =
                                DiscoverBlack,

                            modifier =
                                Modifier.size(
                                    19.dp
                                )
                        )
                    }


                    Spacer(
                        modifier =
                            Modifier.width(
                                10.dp
                            )
                    )


                    Column(
                        modifier =
                            Modifier.weight(
                                1f
                            )
                    ) {

                        Text(
                            text =
                                group.name,

                            fontFamily =
                                InterFontFamily,

                            fontWeight =
                                FontWeight.SemiBold,

                            fontSize =
                                11.spotSp,

                            color =
                                DiscoverBlack
                        )


                        Spacer(
                            modifier =
                                Modifier.height(
                                    3.dp
                                )
                        )


                        Text(
                            text =
                                group.preview,

                            color =
                                DiscoverSecondary,

                            fontFamily =
                                InterFontFamily,

                            fontSize =
                                9.spotSp,

                            maxLines =
                                1,

                            overflow =
                                TextOverflow.Ellipsis
                        )
                    }


                    Spacer(
                        modifier =
                            Modifier.width(
                                8.dp
                            )
                    )


                    DiscoverToggleButton(
                        isDone =
                            group.joined,

                        doneLabel =
                            "Joined",

                        actionLabel =
                            "Join",

                        onClick = {

                            onToggleJoin(
                                group
                            )
                        }
                    )
                }
            }
        }
    }
}


@Composable
private fun DiscoverSectionHeader(
    title: String,
    description: String
) {

    Column(
        modifier =
            Modifier.fillMaxWidth()
    ) {

        Text(
            text =
                title,

            color =
                DiscoverBlack,

            fontFamily =
                InterFontFamily,

            fontSize =
                14.spotSp,

            fontWeight =
                FontWeight.SemiBold
        )


        Spacer(
            modifier =
                Modifier.height(
                    2.dp
                )
        )


        Text(
            text =
                description,

            color =
                DiscoverMuted,

            fontFamily =
                InterFontFamily,

            fontSize =
                9.spotSp,

            lineHeight =
                13.sp
        )
    }
}


@Composable
private fun DiscoverToggleButton(
    isDone: Boolean,
    doneLabel: String,
    actionLabel: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {

    if (isDone) {

        OutlinedButton(
            onClick =
                onClick,

            modifier =
                modifier.height(
                    34.dp
                ),

            shape =
                RoundedCornerShape(
                    11.dp
                ),

            border =
                BorderStroke(
                    width =
                        1.dp,

                    color =
                        DiscoverGoldDeep
                ),

            colors =
                ButtonDefaults
                    .outlinedButtonColors(
                        contentColor =
                            DiscoverBlack
                    )
        ) {

            Text(
                text =
                    doneLabel,

                fontFamily =
                    InterFontFamily,

                fontSize =
                    9.spotSp,

                fontWeight =
                    FontWeight.Medium
            )
        }

    } else {

        Button(
            onClick =
                onClick,

            modifier =
                modifier.height(
                    34.dp
                ),

            shape =
                RoundedCornerShape(
                    11.dp
                ),

            colors =
                ButtonDefaults
                    .buttonColors(
                        containerColor =
                            DiscoverGold,

                        contentColor =
                            DiscoverBlack
                    )
        ) {

            Text(
                text =
                    actionLabel,

                fontFamily =
                    InterFontFamily,

                fontSize =
                    9.spotSp,

                fontWeight =
                    FontWeight.SemiBold
            )
        }
    }
}


@Composable
private fun DiscoverAction(
    count: Int,
    onClick: (() -> Unit)? = null,
    icon: @Composable () -> Unit
) {

    Row(
        modifier =
            Modifier.then(
                if (onClick != null) {

                    Modifier.clickable(
                        onClick =
                            onClick
                    )

                } else {

                    Modifier
                }
            ),

        verticalAlignment =
            Alignment.CenterVertically
    ) {

        icon()


        if (count > 0) {

            Spacer(
                modifier =
                    Modifier.width(
                        4.dp
                    )
            )


            Text(
                text =
                    formatDiscoverCount(
                        count
                    ),

                color =
                    DiscoverBlack,

                fontFamily =
                    InterFontFamily,

                fontSize =
                    9.spotSp,

                fontWeight =
                    FontWeight.Medium
            )
        }
    }
}


@Composable
private fun DiscoverAvatar(
    profile: SpotUiProfile
) {
    SpotAvatar(profile.profileImageUrl, "${profile.displayName} profile picture", Modifier.size(38.dp), profile.uid)
}


private fun formatDiscoverCount(
    count: Int
): String {

    return when {

        count >= 1_000_000 -> {

            String.format(
                "%.1fM",
                count / 1_000_000f
            )
        }


        count >= 1_000 -> {

            String.format(
                "%.1fK",
                count / 1_000f
            )
        }


        else -> {

            count.toString()
        }
    }
}
