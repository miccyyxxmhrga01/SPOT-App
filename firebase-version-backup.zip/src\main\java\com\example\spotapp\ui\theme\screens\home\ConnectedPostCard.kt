package com.example.spotapp.ui.theme.screens.home

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.example.spotapp.data.*
import com.example.spotapp.ui.theme.components.*
import com.example.spotapp.ui.theme.models.SpotUiPost
import com.example.spotapp.ui.theme.models.SpotUiProfile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
internal fun ConnectedPostCard(post: PublishedPost, playback: FeedPlayback, enabled: Boolean,
    onProfile: (SpotUiProfile) -> Unit, onComments: (PublishedPost) -> Unit, onImage: (PublishedPost) -> Unit,
    onReel: (SpotUiPost) -> Unit, onHide: () -> Unit = {}, modifier: Modifier = Modifier) {
    var liked by remember(post.id) { mutableStateOf<Boolean?>(null) }
    var saved by remember(post.id) { mutableStateOf(false) }
    var pending by remember(post.id) { mutableStateOf(false) }
    var error by remember(post.id) { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    LifecycleDisposableEffect(post.id) {
        val like = SpotPostsRepository.listenInteraction(post.id) { liked = it }
        val save = SocialRepository.shared.listenSaved(post.id) { saved = it }
        onDispose { like?.remove(); save.remove() }
    }
    fun action(block: suspend () -> Unit) {
        if (pending) return
        pending = true
        scope.launch {
            try { block(); error = "" }
            catch (c: CancellationException) { throw c }
            catch (_: Exception) { error = "Couldn't save this action. Please retry." }
            finally { pending = false }
        }
    }
    Column(modifier) {
        HomePostCard(post.asUiPost(liked == true).copy(saved = saved), onProfileClick = { onProfile(post.author) },
            onLike = { if (liked != null) action { SpotPostsRepository.setLiked(post.id, liked != true) } },
            onComment = { onComments(post) }, onShare = {
                runCatching { context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "${post.author.displayName} on SPOT: ${post.caption}\n${post.media.firstOrNull()?.url.orEmpty()}")
                }, "Share SPOT post")) }.onFailure { error = "No sharing app is available." }
            }, onSave = { action { SocialRepository.shared.setSaved(post.id, !saved) } },
            onNotInterested = onHide, onReport = { error = "Post reporting isn't available yet." },
            onOpenReels = { onReel(post.asUiPost(liked == true)) },
            mediaContent = { if (post.media.isNotEmpty()) FeedPostMedia(post, playback, enabled, onImage, onReel) })
        if (error.isNotBlank()) Text(error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp))
    }
}

@Composable
internal fun FeedPostMedia(post: PublishedPost, playback: FeedPlayback, enabled: Boolean,
    onImage: (PublishedPost) -> Unit, onReel: (SpotUiPost) -> Unit) {
    val pager = rememberPagerState(pageCount = { post.media.size })
    val scope = rememberCoroutineScope()
    Box(Modifier.fillMaxWidth().aspectRatio(1f).background(Color(0xFFF1EEE6))) {
        HorizontalPager(pager, modifier = Modifier.fillMaxSize()) { index ->
            val media = post.media[index]
            val id = "feed:${post.id}:$index"
            if (media.isVideo) SpotVideo(media.url, enabled && pager.settledPage == index && playback.activeId == id,
                modifier = Modifier.fillMaxSize().then(if (pager.settledPage == index) Modifier.feedVideo(playback, id) else Modifier),
                onTap = { onReel(post.asUiPost().copy(mediaUri = media.url)) }, onQualifiedView = {
                    scope.launch { try { SpotPostsRepository.recordView(post.id) } catch (c: CancellationException) { throw c } catch (_: Exception) { } }
                })
            else AsyncImage(media.url, "Photo ${index + 1}", Modifier.fillMaxSize().clickable { onImage(post) }, contentScale = ContentScale.Crop)
        }
        if (post.media.size > 1) Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp)
            .background(Color.Black.copy(alpha = .25f), androidx.compose.foundation.shape.CircleShape).padding(horizontal = 9.dp, vertical = 7.dp)) {
            SpotPageIndicator(post.media.size, pager.currentPage, dark = true)
        }
        if (post.media.size > 1) Surface(Modifier.align(Alignment.TopEnd).padding(12.dp), color = Color.Black.copy(alpha = 0.5f), shape = MaterialTheme.shapes.large) {
            Text("${pager.currentPage + 1}/${post.media.size}", color = Color.White, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp))
        }
    }
}
