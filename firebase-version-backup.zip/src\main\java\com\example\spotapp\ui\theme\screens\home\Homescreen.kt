package com.example.spotapp.ui.theme.screens.home

import com.example.spotapp.ui.theme.components.*
import androidx.compose.material.icons.filled.Bookmark
import com.example.spotapp.ui.theme.components.SpotAvatar

import com.example.spotapp.ui.theme.spotSp

import android.content.Intent
import android.net.Uri
import android.widget.VideoView

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.material3.MaterialTheme
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width

import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState

import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send

import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NotInterested
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search

import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

import androidx.compose.ui.layout.ContentScale

import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource

import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import androidx.compose.ui.viewinterop.AndroidView

import coil3.compose.AsyncImage

import com.example.spotapp.ui.theme.InterFontFamily

import com.example.spotapp.ui.theme.models.SpotRoute
import com.example.spotapp.ui.theme.models.SpotUiPost
import com.example.spotapp.ui.theme.models.SpotUiProfile

import com.example.spotapp.ui.theme.navigation.SpotMainBottomNavigation


private val HomeWhite = Color.White
private val HomeBlack = Color(0xFF111111)
private val HomeMuted = Color(0xFF74746C)
private val HomeLine = Color(0xFFE8E5DD)
private val HomePlaceholder = Color(0xFFEDEDED)

private val HomeGold =
    Color(0xFFFDD87A)

private val HomeGoldDeep =
    Color(0xFFAD8420)

private val HomeBadgeRed =
    Color(0xFFE5484D)


private val HomeStoryGradient =
    Brush.linearGradient(
        colors =
            listOf(
                HomeGoldDeep,
                Color(0xFFE8794C),
                Color(0xFFD2456E)
            )
    )


private val VideoExtensions =
    setOf(
        "mp4",
        "mov",
        "webm",
        "mkv",
        "3gp"
    )


private fun isVideoUri(
    uri: String?
): Boolean {

    if (uri.isNullOrBlank()) {
        return false
    }


    return uri
        .substringAfterLast(
            ".",
            ""
        )
        .substringBefore(
            "?"
        )
        .lowercase() in VideoExtensions
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpotHomePage(
    profile: SpotUiProfile,
    post: SpotUiPost,
    storyImageUri: String?,
    onPostChanged: (SpotUiPost) -> Unit,
    onStoryChanged: (String) -> Unit,
    onNavigate: (SpotRoute) -> Unit,
    onProfileClick: (SpotUiProfile) -> Unit,
    onOpenReels: (SpotUiPost) -> Unit,
    onSearchClick: () -> Unit = {
        onNavigate(
            SpotRoute.SEARCH
        )
    },
    hasUnseenStory: Boolean = true,
    showBottomNavigation: Boolean = true,
    showPost: Boolean = true,
    contentAfterStories: @Composable () -> Unit = {},
    feedContent: LazyListScope.() -> Unit = {},
    onOverlayVisible: (Boolean) -> Unit = {},
    storiesContent: (@Composable () -> Unit)? = null
) {

    var showComments by remember {
        mutableStateOf(false)
    }


    var showStoryViewer by remember {
        mutableStateOf(false)
    }

    androidx.compose.runtime.SideEffect { onOverlayVisible(showStoryViewer || showComments) }


    val commentsSheetState =
        rememberModalBottomSheetState()


    val postComments =
        remember {
            mutableStateListOf<SpotUiComment>()
        }


    val context =
        LocalContext.current


    val storyPicker =
        rememberLauncherForActivityResult(
            contract =
                ActivityResultContracts.GetContent()
        ) { uri ->

            if (uri != null) {

                onStoryChanged(
                    uri.toString()
                )


                showStoryViewer =
                    true
            }
        }


    if (showComments) {

        HomeCommentsSheet(
            sheetState =
                commentsSheetState,

            comments =
                postComments,

            currentUserAvatarUrl =
                profile.profileImageUrl,

            onDismiss = {

                showComments =
                    false
            },

            onSendComment = { text ->

                postComments.add(
                    SpotUiComment(
                        id =
                            "c${System.currentTimeMillis()}",

                        username =
                            profile.username,

                        avatarUrl =
                            profile.profileImageUrl,

                        text =
                            text
                    )
                )


                onPostChanged(
                    post.copy(
                        comments =
                            post.comments + 1
                    )
                )
            },

            onToggleLike = { commentId ->

                val index =
                    postComments.indexOfFirst {
                        it.id ==
                                commentId
                    }


                if (index != -1) {

                    val comment =
                        postComments[index]


                    postComments[index] =
                        comment.copy(
                            liked =
                                !comment.liked,

                            likes =
                                if (comment.liked) {

                                    (
                                            comment.likes - 1
                                            ).coerceAtLeast(0)

                                } else {

                                    comment.likes + 1
                                }
                        )
                }
            }
        )
    }


    if (showStoryViewer) {

        AlertDialog(
            onDismissRequest = {

                showStoryViewer =
                    false
            },

            confirmButton = {

                TextButton(
                    onClick = {

                        showStoryViewer =
                            false
                    }
                ) {

                    Text(
                        text =
                            "Close",

                        fontFamily =
                            InterFontFamily,

                        fontSize =
                            12.spotSp,
                lineHeight = 18.sp,

                        fontWeight =
                            FontWeight.Medium
                    )
                }
            },

            title = {

                Text(
                    text =
                        "@${profile.username}",

                    fontFamily =
                        InterFontFamily,

                    fontSize =
                        15.spotSp,
                lineHeight = 22.sp,

                    fontWeight =
                        FontWeight.SemiBold
                )
            },

            text = {

                if (
                    storyImageUri
                        .isNullOrBlank()
                ) {

                    Column(
                        horizontalAlignment =
                            Alignment.CenterHorizontally
                    ) {

                        Text(
                            text =
                                "No story image yet.",

                            fontFamily =
                                InterFontFamily,

                            fontSize =
                                12.spotSp
                        )


                        Spacer(
                            modifier =
                                Modifier.height(
                                    10.dp
                                )
                        )


                        Button(
                            onClick = {

                                storyPicker.launch(
                                    "image/*"
                                )
                            },

                            colors =
                                ButtonDefaults
                                    .buttonColors(
                                        containerColor =
                                            HomeGold,

                                        contentColor =
                                            HomeBlack
                                    )
                        ) {

                            Text(
                                text =
                                    "Add story",

                                fontFamily =
                                    InterFontFamily,

                                fontSize =
                                    12.spotSp,
                lineHeight = 18.sp,

                                fontWeight =
                                    FontWeight.SemiBold
                            )
                        }
                    }

                } else {

                    AsyncImage(
                        model =
                            storyImageUri,

                        contentDescription =
                            "Story",

                        contentScale =
                            ContentScale.Crop,

                        modifier =
                            Modifier
                                .fillMaxWidth()
                                .aspectRatio(
                                    0.78f
                                )
                                .clip(
                                    RoundedCornerShape(
                                        16.dp
                                    )
                                )
                    )
                }
            }
        )
    }


    Scaffold(
        containerColor =
            HomeWhite,

        contentWindowInsets =
            WindowInsets(
                0,
                0,
                0,
                0
            ),

        bottomBar = {

            if (showBottomNavigation) {

                SpotMainBottomNavigation(
                    selectedRoute =
                        SpotRoute.HOME,

                    profile =
                        profile,

                    onNavigate =
                        onNavigate
                )
            }
        }
    ) { innerPadding ->

        LazyColumn(Modifier.fillMaxSize().spotAmbientBackground(HomeWhite).padding(innerPadding)) {
            item(key = "home-intro") {
                HomeTopBar(onAddPostClick = { onNavigate(SpotRoute.NEW_POST) }, onSearchClick = onSearchClick)
                if (storiesContent != null) storiesContent() else HomeStoryRow(profile, storyImageUri, hasUnseenStory,
                    onStoryClick = { showStoryViewer = true }, onAddStory = { storyPicker.launch("image/*") })
                contentAfterStories()
            }
            feedContent()
            if (showPost) item(key = "local-post") {
            HomePostCard(
                post =
                    post,

                onProfileClick = {

                    onProfileClick(
                        post.user
                    )
                },

                onOpenReels = {

                    onOpenReels(
                        post
                    )
                },

                onLike = {

                    onPostChanged(
                        post.copy(
                            liked =
                                !post.liked,

                            likes =
                                if (post.liked) {

                                    (
                                            post.likes - 1
                                            ).coerceAtLeast(0)

                                } else {

                                    post.likes + 1
                                }
                        )
                    )
                },

                onComment = {

                    showComments =
                        true
                },

                onShare = {

                    val shareIntent =
                        Intent(
                            Intent.ACTION_SEND
                        ).apply {

                            type =
                                "text/plain"


                            putExtra(
                                Intent.EXTRA_TEXT,
                                "${post.user.displayName} on SPOT: ${post.caption}"
                            )
                        }


                    context.startActivity(
                        Intent.createChooser(
                            shareIntent,
                            "Share SPOT post"
                        )
                    )


                    onPostChanged(
                        post.copy(
                            shares =
                                post.shares + 1
                        )
                    )
                },

                onSave = {

                    onPostChanged(
                        post.copy(
                            saved =
                                !post.saved
                        )
                    )
                },

                onNotInterested = {},

                onReport = {}
            )
            }
            item { Spacer(Modifier.height(14.dp + LocalSpotBottomContentPadding.current)) }
        }
    }
}


@Composable
private fun HomeTopBar(
    onAddPostClick: () -> Unit,
    onSearchClick: () -> Unit
) {

    Surface(
        color =
            HomeWhite.copy(alpha = .78f),

        shadowElevation =
            0.dp
    ) {

        Column {

            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(
                            56.dp
                        )
                        .padding(
                            horizontal =
                                16.dp
                        )
            ) {

                HomeQuickPostButton(
                    onClick =
                        onAddPostClick,

                    modifier =
                        Modifier.align(
                            Alignment.CenterStart
                        )
                )


                SpotWordmark(
                    modifier =
                        Modifier.align(
                            Alignment.Center
                        )
                )


                IconButton(
                    onClick =
                        onSearchClick,

                    modifier =
                        Modifier
                            .align(
                                Alignment.CenterEnd
                            )
                            .size(
                                38.dp
                            )
                ) {

                    Icon(
                        imageVector =
                            Icons.Filled.Search,

                        contentDescription =
                            "Search",

                        tint =
                            HomeBlack,

                        modifier =
                            Modifier.size(
                                20.dp
                            )
                    )
                }
            }


            HorizontalDivider(
                color =
                    HomeLine
            )
        }
    }
}


@Composable
private fun HomeQuickPostButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {

    Box(
        modifier =
            modifier
                .size(
                    32.dp
                )
                .shadow(
                    elevation =
                        2.dp,

                    shape =
                        CircleShape
                )
                .clip(
                    CircleShape
                )
                .background(
                    Brush.linearGradient(
                        colors =
                            listOf(
                                HomeGold,
                                HomeGoldDeep
                            )
                    )
                )
                .clickable(
                    onClick =
                        onClick
                ),

        contentAlignment =
            Alignment.Center
    ) {

        Icon(
            imageVector =
                Icons.Filled.Add,

            contentDescription =
                "Create new post",

            tint =
                HomeBlack,

            modifier =
                Modifier.size(
                    17.dp
                )
        )
    }
}


@Composable
private fun SpotWordmark(modifier: Modifier = Modifier) {
    Column(modifier.padding(horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(buildAnnotatedString {
            append("SP")
            withStyle(SpanStyle(color = HomeGoldDeep)) { append("O") }
            append("T")
        }, color = HomeBlack, fontFamily = InterFontFamily, fontWeight = FontWeight.Bold,
            fontSize = 22.spotSp, lineHeight = 28.sp, letterSpacing = 1.5.sp)
        Box(Modifier.width(24.dp).height(2.dp).clip(CircleShape)
            .background(Brush.horizontalGradient(listOf(HomeGoldDeep, HomeGold))))
    }
}


@Composable
private fun HomeStoryRow(
    profile: SpotUiProfile,
    storyImageUri: String?,
    hasUnseenStory: Boolean,
    onStoryClick: () -> Unit,
    onAddStory: () -> Unit
) {

    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .height(
                    96.dp
                )
                .padding(
                    start =
                        16.dp,

                    end =
                        12.dp,

                    top =
                        8.dp,

                    bottom =
                        5.dp
                ),

        verticalAlignment =
            Alignment.CenterVertically
    ) {

        Column(
            horizontalAlignment =
                Alignment.CenterHorizontally
        ) {

            Box(
                modifier =
                    Modifier
                        .size(
                            56.dp
                        )
                        .clickable {

                            if (
                                storyImageUri
                                    .isNullOrBlank()
                            ) {

                                onAddStory()

                            } else {

                                onStoryClick()
                            }
                        },

                contentAlignment =
                    Alignment.Center
            ) {

                if (
                    !storyImageUri.isNullOrBlank() &&
                    hasUnseenStory
                ) {

                    Box(
                        modifier =
                            Modifier
                                .size(
                                    56.dp
                                )
                                .background(
                                    HomeStoryGradient,
                                    CircleShape
                                )
                    )
                }


                Box(
                    modifier =
                        Modifier
                            .size(
                                51.dp
                            )
                            .background(
                                HomeWhite,
                                CircleShape
                            ),

                    contentAlignment =
                        Alignment.Center
                ) {

                    ProfileAvatar(
                        profile =
                            profile,

                        imageOverride =
                            storyImageUri,

                        size =
                            47
                    )
                }


                Box(
                    modifier =
                        Modifier
                            .align(
                                Alignment.BottomEnd
                            )
                            .size(
                                17.dp
                            )
                            .background(
                                HomeWhite,
                                CircleShape
                            ),

                    contentAlignment =
                        Alignment.Center
                ) {

                    Box(
                        modifier =
                            Modifier
                                .size(
                                    14.dp
                                )
                                .shadow(
                                    elevation =
                                        1.dp,

                                    shape =
                                        CircleShape
                                )
                                .background(
                                    HomeGoldDeep,
                                    CircleShape
                                ),

                        contentAlignment =
                            Alignment.Center
                    ) {

                        Icon(
                            imageVector =
                                Icons.Filled.Add,

                            contentDescription =
                                "Add story",

                            tint =
                                HomeBlack,

                            modifier =
                                Modifier.size(
                                    10.dp
                                )
                        )
                    }
                }
            }


            Spacer(
                modifier =
                    Modifier.height(
                        4.dp
                    )
            )


            Text(
                text =
                    "Your Story",

                fontFamily =
                    InterFontFamily,

                fontSize =
                    11.spotSp,
                lineHeight = 16.sp,

                fontWeight =
                    FontWeight.Medium,

                color =
                    HomeBlack
            )
        }
    }
}


@Composable
internal fun HomePostCard(
    post: SpotUiPost, onProfileClick: () -> Unit, onLike: () -> Unit,
    onComment: () -> Unit, onShare: () -> Unit, onSave: () -> Unit,
    onNotInterested: () -> Unit, onReport: () -> Unit, onOpenReels: () -> Unit,
    mediaContent: (@Composable () -> Unit)? = null, modifier: Modifier = Modifier
) {
    var menu by remember { mutableStateOf(false) }
    Column(modifier.fillMaxWidth().background(HomeWhite)) {
        Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 8.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f).heightIn(min = 48.dp).clip(RoundedCornerShape(14.dp))
                .clickable(role = Role.Button, onClickLabel = "Open ${post.user.displayName}'s profile", onClick = onProfileClick),
                verticalAlignment = Alignment.CenterVertically) {
                ProfileAvatar(post.user, null, 40)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text("@${post.user.username.removePrefix("@")}", color = HomeBlack,
                        style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(listOf(post.category, post.postedTime).filter { it.isNotBlank() }.joinToString(" · "),
                        color = HomeMuted, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            Box {
                SpotAnimatedIconButton(Icons.Filled.MoreVert, "More options", { menu = true }, tint = HomeMuted)
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Not interested") }, leadingIcon = { Icon(Icons.Filled.NotInterested, null) },
                        onClick = { menu = false; onNotInterested() })
                    DropdownMenuItem(text = { Text("Report") }, leadingIcon = { Icon(Icons.Filled.Flag, null) },
                        onClick = { menu = false; onReport() })
                }
            }
        }
        Box(Modifier.padding(horizontal = 10.dp).clip(RoundedCornerShape(18.dp))) {
            if (mediaContent != null) mediaContent() else HomePostMedia(post, onOpenReels)
        }
        if (post.caption.isNotBlank()) {
            Spacer(Modifier.height(12.dp))
            ExpandableCaption(post.user.username, post.caption)
        }
        if (post.aiCaption) Text("AI-assisted caption", Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            color = HomeMuted, style = MaterialTheme.typography.labelSmall)
        if (post.tags.isNotEmpty()) Row(Modifier.padding(horizontal = 16.dp).padding(top = 5.dp)) {
            Text(post.tags.joinToString("  ") { "#$it" }, color = HomeGoldDeep, style = MaterialTheme.typography.bodySmall,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            if (post.aiTagged) Text("Auto-tagged", color = HomeMuted, style = MaterialTheme.typography.labelSmall)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            HomeReaction(if (post.liked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                "Like", post.likes, onLike, if (post.liked) HomeBadgeRed else HomeBlack, post.liked)
            HomeReaction(Icons.Outlined.ChatBubbleOutline, "Comment", post.comments, onComment)
            HomeReaction(Icons.AutoMirrored.Filled.Send, "Share", post.shares, onShare)
            Spacer(Modifier.weight(1f))
            SpotAnimatedIconButton(if (post.saved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                if (post.saved) "Saved" else "Save", onSave, tint = if (post.saved) HomeGoldDeep else HomeBlack, selected = post.saved)
        }
        HorizontalDivider(Modifier.padding(horizontal = 16.dp), color = HomeLine.copy(alpha = .65f), thickness = .5.dp)
    }
}

@Composable
private fun HomeReaction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, count: Int,
    onClick: () -> Unit, color: Color = HomeBlack, selected: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        SpotAnimatedIconButton(icon, label, onClick, tint = color, selected = selected)
        if (count > 0) Text(formatHomeCount(count), color = HomeBlack, style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.padding(end = 6.dp))
    }
}

@Composable
private fun HomePostMedia(
    post: SpotUiPost,
    onOpenReels: () -> Unit
) {

    when {

        post.localImageResources
            .isNotEmpty() -> {

            HomeImagePager(
                images =
                    post.localImageResources
            )
        }


        post.localVideoRes !=
                null -> {

            HomeVideoPlayer(
                localVideoRes =
                    post.localVideoRes,

                videoUri =
                    null,

                onOpenReels =
                    onOpenReels
            )
        }


        isVideoUri(
            post.mediaUri
        ) -> {

            HomeVideoPlayer(
                localVideoRes =
                    null,

                videoUri =
                    post.mediaUri,

                onOpenReels =
                    onOpenReels
            )
        }


        !post.mediaUri
            .isNullOrBlank() -> {

            AsyncImage(
                model =
                    post.mediaUri,

                contentDescription =
                    "Post media",

                contentScale =
                    ContentScale.Crop,

                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal =
                                8.dp
                        )
                        .aspectRatio(
                            1f
                        )
                        .clip(
                            RoundedCornerShape(
                                14.dp
                            )
                        )
            )
        }


        else -> {

            Box(
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(
                            horizontal =
                                8.dp
                        )
                        .aspectRatio(
                            1f
                        )
                        .clip(
                            RoundedCornerShape(
                                14.dp
                            )
                        )
                        .background(
                            HomePlaceholder
                        ),

                contentAlignment =
                    Alignment.Center
            ) {

                Icon(
                    imageVector =
                        Icons.Filled.Person,

                    contentDescription =
                        null,

                    tint =
                        HomeMuted,

                    modifier =
                        Modifier.size(
                            28.dp
                        )
                )
            }
        }
    }
}


@Composable
private fun HomeImagePager(
    images: List<Int>
) {

    val pagerState =
        rememberPagerState(
            pageCount = {
                images.size
            }
        )


    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    horizontal =
                        8.dp
                )
                .aspectRatio(
                    1f
                )
                .clip(
                    RoundedCornerShape(
                        14.dp
                    )
                )
                .background(
                    HomePlaceholder
                )
    ) {

        HorizontalPager(
            state =
                pagerState,

            modifier =
                Modifier.fillMaxSize()
        ) { page ->

            Image(
                painter =
                    painterResource(
                        id =
                            images[page]
                    ),

                contentDescription =
                    "Post image ${page + 1}",

                contentScale =
                    ContentScale.Crop,

                modifier =
                    Modifier.fillMaxSize()
            )
        }


        if (
            images.size >
            1
        ) {

            Surface(
                modifier =
                    Modifier
                        .align(
                            Alignment.TopEnd
                        )
                        .padding(
                            10.dp
                        ),

                shape =
                    RoundedCornerShape(
                        20.dp
                    ),

                color =
                    HomeBlack.copy(
                        alpha =
                            0.55f
                    )
            ) {

                Text(
                    text =
                        "${pagerState.currentPage + 1}/${images.size}",

                    color =
                        HomeWhite,

                    fontFamily =
                        InterFontFamily,

                    fontSize =
                        11.spotSp,
                lineHeight = 16.sp,

                    fontWeight =
                        FontWeight.SemiBold,

                    modifier =
                        Modifier.padding(
                            horizontal =
                                8.dp,

                            vertical =
                                4.dp
                        )
                )
            }


            Row(
                modifier =
                    Modifier
                        .align(
                            Alignment.BottomCenter
                        )
                        .padding(
                            bottom =
                                10.dp
                        ),

                horizontalArrangement =
                    Arrangement.spacedBy(
                        4.dp
                    )
            ) {

                repeat(
                    images.size
                ) { index ->

                    Box(
                        modifier =
                            Modifier
                                .size(
                                    if (
                                        pagerState.currentPage ==
                                        index
                                    ) {

                                        6.dp

                                    } else {

                                        5.dp
                                    }
                                )
                                .background(
                                    color =
                                        if (
                                            pagerState.currentPage ==
                                            index
                                        ) {

                                            HomeWhite

                                        } else {

                                            HomeWhite.copy(
                                                alpha =
                                                    0.45f
                                            )
                                        },

                                    shape =
                                        CircleShape
                                )
                    )
                }
            }
        }
    }
}


@Composable
private fun HomeVideoPlayer(
    localVideoRes: Int?,
    videoUri: String?,
    onOpenReels: () -> Unit
) {

    val context =
        LocalContext.current


    var videoView by remember {
        mutableStateOf<VideoView?>(
            null
        )
    }


    val uri =
        remember(
            localVideoRes,
            videoUri
        ) {

            when {

                localVideoRes != null -> {

                    Uri.parse(
                        "android.resource://${context.packageName}/$localVideoRes"
                    )
                }


                !videoUri.isNullOrBlank() -> {

                    Uri.parse(
                        videoUri
                    )
                }


                else -> {

                    null
                }
            }
        }


    DisposableEffect(
        uri
    ) {

        onDispose {

            videoView?.stopPlayback()

            videoView =
                null
        }
    }


    if (uri == null) {
        return
    }


    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(
                    horizontal =
                        8.dp
                )
                .aspectRatio(
                    1f
                )
                .clip(
                    RoundedCornerShape(
                        14.dp
                    )
                )
                .background(
                    Color.Black
                ),

        contentAlignment =
            Alignment.Center
    ) {

        AndroidView(
            factory = {

                VideoView(
                    context
                ).apply {

                    tag =
                        uri.toString()


                    setVideoURI(
                        uri
                    )


                    setOnPreparedListener { mediaPlayer ->

                        mediaPlayer.isLooping =
                            true


                        mediaPlayer.setVolume(
                            0f,
                            0f
                        )


                        start()
                    }


                    videoView =
                        this
                }
            },

            update = { view ->

                if (
                    view.tag !=
                    uri.toString()
                ) {

                    view.tag =
                        uri.toString()


                    view.setVideoURI(
                        uri
                    )
                }
            },

            modifier =
                Modifier.fillMaxSize()
        )


        Box(
            modifier =
                Modifier
                    .fillMaxSize()
                    .clickable {

                        videoView?.pause()


                        onOpenReels()
                    }
        )


        Surface(
            modifier =
                Modifier
                    .align(
                        Alignment.BottomEnd
                    )
                    .padding(
                        10.dp
                    ),

            shape =
                RoundedCornerShape(
                    20.dp
                ),

            color =
                HomeBlack.copy(
                    alpha =
                        0.48f
                )
        ) {

            Text(
                text =
                    "Watch reel",

                color =
                    HomeWhite,

                fontFamily =
                    InterFontFamily,

                fontSize =
                    11.spotSp,
                lineHeight = 16.sp,

                fontWeight =
                    FontWeight.SemiBold,

                modifier =
                    Modifier.padding(
                        horizontal =
                            8.dp,

                        vertical =
                            4.dp
                    )
            )
        }
    }
}


@Composable
private fun ExpandableCaption(username: String, text: String) {
    var expanded by remember(text) { mutableStateOf(false) }
    var overflowing by remember(text) { mutableStateOf(false) }
    Column(Modifier.padding(horizontal = 16.dp).animateContentSize(tween(180))) {
        Text(text, color = HomeBlack, style = MaterialTheme.typography.bodyMedium,
            maxLines = if (expanded) Int.MAX_VALUE else 2, overflow = TextOverflow.Ellipsis,
            onTextLayout = { if (!expanded) overflowing = it.hasVisualOverflow })
        if (overflowing || expanded) Text(if (expanded) "See less" else "See more", color = HomeMuted,
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { expanded = !expanded }.padding(vertical = 8.dp))
    }
}

@Composable
private fun HomeAction(
    count: Int,
    onClick: () -> Unit,
    icon: @Composable () -> Unit
) {

    Row(
        modifier =
            Modifier.clickable(
                onClick =
                    onClick
            ),

        verticalAlignment =
            Alignment.CenterVertically
    ) {

        icon()


        if (
            count >
            0
        ) {

            Spacer(
                modifier =
                    Modifier.width(
                        4.dp
                    )
            )


            Text(
                text =
                    formatHomeCount(
                        count
                    ),

                color =
                    HomeBlack,

                fontFamily =
                    InterFontFamily,

                fontSize =
                    11.spotSp,
                lineHeight = 16.sp,

                fontWeight =
                    FontWeight.Medium,

                textAlign =
                    TextAlign.Center
            )
        }
    }
}


@Composable
private fun ProfileAvatar(
    profile: SpotUiProfile,
    imageOverride: String?,
    size: Int
) {
    SpotAvatar(imageOverride ?: profile.profileImageUrl, "${profile.displayName} profile picture",
        Modifier.size(size.dp).border(1.dp, HomeLine, CircleShape), if (imageOverride.isNullOrBlank()) profile.uid else "")
}


private fun formatHomeCount(
    count: Int
): String {

    return when {

        count >=
                1_000_000 -> {

            String.format(
                "%.1fM",
                count /
                        1_000_000f
            )
        }


        count >=
                1_000 -> {

            String.format(
                "%.1fK",
                count /
                        1_000f
            )
        }


        else -> {

            count.toString()
        }
    }
}
