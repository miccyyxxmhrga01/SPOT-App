package com.example.spotapp.data

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.Flow
import java.util.UUID

data class ChatPerson(val uid: String, val name: String, val username: String = "", val photo: String = "")

data class ChatPreferences(
    val nickname: String = "", val muted: Boolean = false,
    val hiddenAt: Long = 0, val readAt: Long = 0
)

data class CampusConversation(
    val id: String, val title: String, val kind: String = "direct", val demo: Boolean = false,
    val creatorId: String, val partyIds: List<String>, val memberIds: List<String>,
    val invitedIds: List<String> = emptyList(), val people: Map<String, ChatPerson> = emptyMap(),
    val inviteNote: String = "", val preview: String = "", val lastSenderId: String = "",
    val updatedAt: Long = 0, val createdAt: Long = 0
) {
    fun nameFor(uid: String, prefs: ChatPreferences = ChatPreferences()): String =
        prefs.nickname.ifBlank { if (kind == "group" || demo) title else people[otherUid(uid)]?.name ?: "Campus connection" }
    fun otherUid(uid: String): String = partyIds.firstOrNull { it != uid }.orEmpty()
    fun unread(uid: String, prefs: ChatPreferences): Boolean =
        preview.isNotBlank() && lastSenderId != uid && updatedAt > prefs.readAt
    fun visible(prefs: ChatPreferences): Boolean = prefs.hiddenAt == 0L || updatedAt > prefs.hiddenAt
}

data class ChatAttachment(val path: String, val mime: String, val name: String, val size: Long,
    val url: String = "", val key: String = "", val iv: String = "") {
    val isVideo get() = mime.startsWith("video/")
    val encrypted get() = url.isNotBlank() && key.isNotBlank() && iv.isNotBlank()
}

/** [unsent]: the sender removed it for everyone; its text and attachment are already cleared. */
data class CampusMessage(
    val id: String, val senderId: String, val text: String = "", val attachment: ChatAttachment? = null,
    val createdAt: Long = 0, val pending: Boolean = false, val unsent: Boolean = false
) {
    fun canUnsend(uid: String) = senderId == uid && !unsent && !pending
}

/** Inbox preview once the latest message is unsent. Firestore rules require this exact text. */
const val UNSENT_MESSAGE_PREVIEW = "Message unsent"

data class ChatDraft(
    val id: String = UUID.randomUUID().toString(), val text: String = "", val attachment: ChatAttachment? = null
) {
    fun error(): String? = when {
        text.isBlank() && attachment == null -> "Write a message or choose a photo or video."
        text.length > 4000 -> "Keep your message under 4,000 characters."
        attachment != null && (attachment.size !in 1..25L * 1024 * 1024 ||
            !(attachment.mime.startsWith("image/") || attachment.mime.startsWith("video/"))) -> "Choose a photo or video under 25 MB."
        else -> null
    }
}

data class MessagesInbox(
    val conversations: List<CampusConversation> = emptyList(),
    val requests: List<CampusConversation> = emptyList(),
    val preferences: Map<String, ChatPreferences> = emptyMap(),
    val blockedIds: Set<String> = emptySet(), val loading: Boolean = true, val error: String = ""
)

/** Firebase is behind this boundary so interaction tests never message real accounts. */
interface MessagesStore {
    val uid: String
    fun inbox(): Flow<MessagesInbox>
    fun messages(id: String): Flow<List<CampusMessage>>
    suspend fun olderMessages(id: String, before: CampusMessage): List<CampusMessage>
    suspend fun syncProfile()
    suspend fun people(search: String): List<ChatPerson>
    suspend fun person(uid: String): ChatPerson?
    suspend fun create(people: List<ChatPerson>, title: String, note: String, group: Boolean, id: String): String
    suspend fun respond(id: String, accept: Boolean)
    suspend fun send(id: String, draft: ChatDraft)
    /** Removes your own message for everyone in the conversation. */
    suspend fun unsend(id: String, messageId: String)
    /** Hides any message for you only; other members still see it. */
    suspend fun deleteForMe(id: String, messageId: String)
    fun hiddenMessages(id: String): Flow<Set<String>>
    suspend fun upload(context: Context, id: String, messageId: String, uri: Uri, mime: String?, progress: (Float) -> Unit): ChatAttachment
    suspend fun mediaFile(context: Context, attachment: ChatAttachment): Uri
    suspend fun preferences(id: String, values: Map<String, Any>)
    suspend fun block(otherUid: String, blocked: Boolean)
    suspend fun leave(id: String)
    suspend fun report(id: String, reason: String)
    suspend fun addSamples()
}
