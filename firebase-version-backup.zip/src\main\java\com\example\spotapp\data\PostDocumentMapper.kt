package com.example.spotapp.data

import com.example.spotapp.ui.theme.models.SpotUiProfile
import com.google.firebase.Timestamp
import java.util.Date

/** Reads the current flat Firestore schema and albums published by older SPOT builds. */
object PostDocumentMapper {
    fun published(id: String, data: Map<String, Any?>): PublishedPost? {
        val uid = data.text("userId").ifBlank { return null }
        val author = data["author"] as? Map<*, *> ?: emptyMap<String, Any>()
        val categories = data.strings("categories").ifEmpty {
            data.strings("talentCategories").ifEmpty { listOfNotNull(data.text("talentCategory").takeIf(String::isNotBlank)) }
        }
        val type = data.text("mediaType").lowercase()
        val album = (data["media"] as? List<*>)?.mapNotNull { value ->
            val item = value as? Map<*, *> ?: return@mapNotNull null
            val url = item.text("url").takeIf(::isWebUrl) ?: return@mapNotNull null
            PublishedMedia(url, item.text("contentType").ifBlank { mimeType(type, url) },
                item.text("storagePath"), item.text("thumbnailUrl"))
        }.orEmpty()
        val media = album.ifEmpty {
            (listOfNotNull(data.text("mediaUrl").takeIf(String::isNotBlank)) + data.strings("mediaUrls"))
                .distinct().filter(::isWebUrl).map { PublishedMedia(it, mimeType(type, it)) }
        }
        return PublishedPost(
            id = id,
            author = SpotUiProfile(uid,
                data.text("displayName").ifBlank { author.text("displayName").ifBlank { "Campus creator" } },
                data.text("username").ifBlank { author.text("username") },
                data.text("talentCategory").ifBlank { author.text("talent").ifBlank { categories.firstOrNull().orEmpty() } },
                data.text("course").ifBlank { author.text("course") },
                data.text("userProfileImageUrl").ifBlank { data.text("profileImageUrl").ifBlank { author.text("profileImageUrl") } }),
            caption = data.text("caption"), categories = categories, tags = data.strings("tags"), media = media,
            audience = data.text("audience").ifBlank { "private" },
            likes = data.count("likesCount"), views = data.count("viewsCount"),
            comments = data.count("commentsCount"), shares = data.count("sharesCount"),
            createdAt = when (val value = data["createdAt"]) {
                is Timestamp -> value.toDate().time
                is Date -> value.time
                is Number -> value.toLong()
                else -> 0L
            }, location = data.text("location"), taggedPeople = data.strings("taggedPeople"),
            aiCaption = data["aiCaption"] == true, aiTagged = data["aiTagged"] == true,
            aiCategorySuggested = data["aiCategorySuggested"] == true
        )
    }

    fun spotPost(id: String, data: Map<String, Any?>): SpotPost? = published(id, data)?.let { post ->
        SpotPost(id = post.id, userId = post.author.uid, caption = post.caption,
            talentCategory = post.categories.joinToString(", "), tags = post.tags,
            mediaType = if (post.media.firstOrNull()?.isVideo == true) PostMediaType.VIDEO else PostMediaType.IMAGE,
            mediaUrls = post.media.map { it.url }, likesCount = post.likes, commentsCount = post.comments,
            sharesCount = post.shares, createdAt = post.createdAt,
            user = SpotUser(uid = post.author.uid, displayName = post.author.displayName,
                username = post.author.username, course = post.author.course,
                talentCategories = post.categories, profileImageUrl = post.author.profileImageUrl))
    }

    private fun Map<*, *>.text(key: String) = (this[key] as? String)?.trim().orEmpty()
    private fun Map<*, *>.strings(key: String) = (this[key] as? List<*>)?.filterIsInstance<String>()
        ?.map(String::trim)?.filter(String::isNotBlank).orEmpty()
    private fun Map<*, *>.count(key: String) = (this[key] as? Number)?.toLong()?.coerceAtLeast(0) ?: 0L
    private fun isWebUrl(value: String) = value.startsWith("https://") || value.startsWith("http://")
    private fun mimeType(type: String, url: String): String = if (type == "video" || type.startsWith("video/") || isPostVideoUrl(url)) "video/mp4" else "image/jpeg"
}
