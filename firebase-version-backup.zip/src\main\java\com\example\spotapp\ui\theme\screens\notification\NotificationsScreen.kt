package com.example.spotapp.ui.theme.screens.notification

import com.example.spotapp.ui.theme.components.spotAmbientBackground
import com.example.spotapp.ui.theme.components.LocalSpotBottomContentPadding
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import coil3.compose.AsyncImage
import java.util.Calendar
import com.example.spotapp.ui.theme.components.SpotLoading
import com.example.spotapp.ui.theme.components.SkeletonKind

import com.example.spotapp.ui.theme.components.LifecycleDisposableEffect

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.outlined.NotificationsNone
import androidx.compose.material.icons.outlined.Handshake
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import com.example.spotapp.ui.theme.components.SpotSectionTabs
import com.example.spotapp.ui.theme.components.SpotSectionTab
import com.example.spotapp.ui.theme.screens.seeker.WorkRequests
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.spotapp.data.*
import com.example.spotapp.ui.theme.models.*
import com.example.spotapp.ui.theme.navigation.SpotMainBottomNavigation
import com.example.spotapp.ui.theme.screens.home.SocialAvatar
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
fun NotificationsScreen(profile: SpotUiProfile, onNavigate: (SpotRoute) -> Unit, showBottomNavigation: Boolean = true,
    onOpen: (SocialNotification) -> Unit = {}, repository: SocialRepository = SocialRepository.shared,
    onProfile: (SpotUiProfile) -> Unit = {}, onMessage: (String) -> Unit = {}) {
    Scaffold(modifier = Modifier.spotAmbientBackground(Color(0xFFFFFCF6)), containerColor = Color.Transparent, contentWindowInsets = WindowInsets(0, 0, 0, 0), bottomBar = {
        if (showBottomNavigation) SpotMainBottomNavigation(SpotRoute.NOTIFICATIONS, profile, onNavigate = onNavigate)
    }) { padding ->
        Box(Modifier.fillMaxSize().padding(padding).statusBarsPadding()) {
            NotificationSections(profile,
                activity = { NotificationActivity(profile, onOpen, repository) },
                requests = { category -> WorkRequests(profile, onProfile = onProfile, onMessage = onMessage, category = category) })
        }
    }
}

@Composable
internal fun NotificationSections(profile: SpotUiProfile, activity: @Composable () -> Unit,
    requests: @Composable (String) -> Unit) {
    var category by rememberSaveable(profile.uid) { mutableStateOf("activity") }
    val saved = rememberSaveableStateHolder()
    Column(Modifier.fillMaxSize()) {
        Text("Notifications", Modifier.padding(horizontal = 18.dp, vertical = 16.dp), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        SpotSectionTabs(listOf(
            SpotSectionTab("activity", "Activity", Icons.Outlined.NotificationsNone),
            SpotSectionTab("invitation", if (profile.accountType == AccountType.TALENT_SEEKER) "Invitations" else "Spotter requests", Icons.Outlined.Handshake)
        ), category, { category = it })
        androidx.compose.animation.AnimatedContent(category, Modifier.weight(1f), label = "notification category") { current ->
            saved.SaveableStateProvider(current) {
                if (current == "activity") activity() else requests(current)
            }
        }
    }
}

@Composable
private fun NotificationActivity(profile: SpotUiProfile, onOpen: (SocialNotification) -> Unit, repository: SocialRepository) {
    val pages = remember(profile.uid) { mutableStateMapOf<Int, SocialPage<SocialNotification>>() }
    val cursors = remember(profile.uid) { mutableStateListOf<DocumentSnapshot?>(null) }
    var error by remember { mutableStateOf("") }
    var retry by remember { mutableIntStateOf(0) }
    var saving by remember { mutableStateOf(false) }
    var preferences by remember { mutableStateOf(SpotPreferences()) }
    LifecycleDisposableEffect(profile.uid) {
        val listener = PrivacyRepository.shared.listenPreferences({ preferences = it })
        onDispose { listener.remove() }
    }
    val scope = rememberCoroutineScope()
    cursors.forEachIndexed { index, cursor ->
        LifecycleDisposableEffect(profile.uid, cursor, retry) {
            val listener = repository.listenNotifications(cursor, { page ->
                pages[index] = page
                if (index + 1 < cursors.size && page.cursor != null && cursors[index + 1]?.id != page.cursor.id) cursors[index + 1] = page.cursor
            }, { error = it })
            onDispose { listener.remove() }
        }
    }
    val all = pages.toSortedMap().values.flatMap { it.items }.distinctBy { it.id }.sortedByDescending { it.createdAt }.filter { when (it.type) { "like" -> preferences.likes; "comment" -> preferences.comments; "follow" -> preferences.follows; else -> true } }
    fun action(block: suspend () -> Unit) {
        if (saving) return
        saving = true
        scope.launch {
            try { block(); error = "" }
            catch (c: CancellationException) { throw c }
            catch (_: Exception) { error = "Couldn't update notifications. Please retry." }
            finally { saving = false }
        }
    }
        LazyColumn(Modifier.fillMaxSize().testTag("notifications-feed"), contentPadding = PaddingValues(bottom = 24.dp + LocalSpotBottomContentPadding.current)) {
            item {
                Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 8.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Recent activity", style = MaterialTheme.typography.titleSmall)
                        
                    }
                    IconButton({ action { repository.markAllRead() } }, enabled = !saving) { Icon(Icons.Filled.DoneAll, "Mark all as read", tint = Color(0xFFAD8420)) }
                }
                if (pages.isEmpty() && error.isBlank()) SpotLoading(true, SkeletonKind.ROWS)
                if (saving) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(0xFFAD8420))
                if (error.isNotBlank()) TextButton({ error = ""; retry++ }, Modifier.padding(horizontal = 16.dp)) { Text(error, color = Color(0xFFAD8420)) }
            }
            if (pages.isNotEmpty() && all.isEmpty()) item {
                Column(Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 64.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Outlined.NotificationsNone, null, Modifier.size(42.dp), tint = Color(0xFFAD8420))
                    Spacer(Modifier.height(16.dp))
                    Text("You're all caught up", style = MaterialTheme.typography.titleMedium)

                }
            }
            all.groupBy { notificationSection(it.createdAt) }.forEach { (section, notifications) ->
                item(key = "section-$section") {
                    Text(section, Modifier.padding(start = 20.dp, top = 18.dp, bottom = 8.dp),
                        style = MaterialTheme.typography.labelMedium, color = Color(0xFF74746C))
                }
                items(notifications, key = { it.id }) { notification ->
                    var preview by remember(notification.postId) { mutableStateOf<String?>(null) }
                    LifecycleDisposableEffect(notification.postId) {
                        val listener = notification.postId.takeIf { it.isNotBlank() }?.let { id ->
                            HomeRepository.listenPost(id, { preview = it?.media?.firstOrNull()?.previewUrl }, { preview = null })
                        }
                        onDispose { listener?.remove() }
                    }
                    NotificationCard(notification, Modifier.animateItem(), onOpen = {
                        action { repository.markRead(notification.id); onOpen(notification) }
                    }, onToggleRead = { action { repository.markRead(notification.id, !notification.isRead) } }, previewUrl = preview)
                }
            }
            val last = pages[cursors.lastIndex]
            if (last?.hasMore == true) item { TextButton({ last.cursor?.let { if (cursors.none { c -> c?.id == it.id }) cursors.add(it) } }, Modifier.fillMaxWidth()) { Text("Load older notifications") } }
        }
}

@Composable
internal fun NotificationCard(item: SocialNotification, modifier: Modifier = Modifier, onOpen: () -> Unit, onToggleRead: () -> Unit, previewUrl: String? = null) {
    var menu by remember { mutableStateOf(false) }
    val background by animateColorAsState(if (item.isRead) Color.White else Color(0xFFFFF6DA), label = "Notification read state")
    Surface(modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 5.dp).clickable(onClick = onOpen),
        shape = RoundedCornerShape(18.dp), color = background) {
        Row(Modifier.padding(start = 12.dp, top = 12.dp, bottom = 12.dp, end = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            SocialAvatar(item.senderProfileImageUrl, "${item.senderName} profile", Modifier.size(42.dp), item.senderId)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(item.senderName, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(item.message, style = MaterialTheme.typography.bodyMedium, color = Color(0xFF74746C), maxLines = 3, overflow = TextOverflow.Ellipsis)
                Text(postTimeLabel(item.createdAt), style = MaterialTheme.typography.labelSmall, color = Color(0xFF74746C), modifier = Modifier.padding(top = 4.dp))
            }
            if (!previewUrl.isNullOrBlank()) AsyncImage(previewUrl, "Post preview",
                Modifier.padding(start = 8.dp, end = 5.dp).size(44.dp, 54.dp).clip(RoundedCornerShape(9.dp)), contentScale = ContentScale.Crop)
            if (!item.isRead) Surface(Modifier.size(6.dp), shape = CircleShape, color = Color(0xFFAD8420)) { }
            Box {
                IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "Notification options", tint = Color(0xFF74746C)) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text(if (item.isRead) "Mark as unread" else "Mark as read") }, onClick = { menu = false; onToggleRead() })
                }
            }
        }
    }
}

internal fun notificationSection(time: Long, now: Long = System.currentTimeMillis()): String {
    val day = Calendar.getInstance().apply {
        timeInMillis = now; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }
    if (time >= day.timeInMillis) return "Today"
    day.add(Calendar.DAY_OF_YEAR, -6)
    return if (time >= day.timeInMillis) "This week" else "Earlier"
}
