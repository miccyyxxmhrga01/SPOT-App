package com.example.spotapp.data.ai

import okhttp3.MultipartBody
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

interface SpotAiApi {

    @Multipart
    @POST("predict")
    suspend fun predictTalent(
        @Part file: MultipartBody.Part
    ): TalentPredictionResponse
}