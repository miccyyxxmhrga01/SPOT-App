package com.example.spotapp.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.os.Build
import androidx.core.content.FileProvider
import androidx.core.net.toUri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.security.MessageDigest
import kotlin.math.roundToInt

/** Real local edits using Android media APIs. Originals are never overwritten. */
object PostMediaExporter {
    suspend fun imagePreview(context: Context, uri: String, edit: PostMediaEdit, maxEdge: Int = 1200): Bitmap =
        withContext(Dispatchers.IO) { renderImage(context, uri, edit, maxEdge) }

    private fun renderImage(context: Context, value: String, edit: PostMediaEdit, maxEdge: Int): Bitmap {
        val uri = value.toUri(); val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "This image couldn't be opened. Choose another image." }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxEdge) sample *= 2
        var bitmap = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
            ?: error("This image couldn't be opened.")
        val orientation = runCatching { resolver.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) } }.getOrNull()
        val matrix = Matrix().apply {
            when (orientation) {
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> setScale(-1f, 1f)
                ExifInterface.ORIENTATION_ROTATE_180 -> setRotate(180f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> setScale(1f, -1f)
                ExifInterface.ORIENTATION_TRANSPOSE -> { setRotate(90f); postScale(-1f, 1f) }
                ExifInterface.ORIENTATION_ROTATE_90 -> setRotate(90f)
                ExifInterface.ORIENTATION_TRANSVERSE -> { setRotate(270f); postScale(-1f, 1f) }
                ExifInterface.ORIENTATION_ROTATE_270 -> setRotate(270f)
            }
            postRotate(edit.rotation * 90f)
        }
        fun replace(next: Bitmap) { if (bitmap !== next) bitmap.recycle(); bitmap = next }
        replace(Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true))
        edit.aspectRatio?.let { ratio ->
            val current = bitmap.width.toFloat() / bitmap.height
            val width = if (current > ratio) (bitmap.height * ratio).roundToInt().coerceAtLeast(1) else bitmap.width
            val height = if (current < ratio) (bitmap.width / ratio).roundToInt().coerceAtLeast(1) else bitmap.height
            replace(Bitmap.createBitmap(bitmap, (bitmap.width - width) / 2, (bitmap.height - height) / 2, width, height))
        }
        val factor = maxEdge.toFloat() / maxOf(bitmap.width, bitmap.height)
        if (factor < 1) replace(Bitmap.createScaledBitmap(bitmap, (bitmap.width * factor).roundToInt().coerceAtLeast(1), (bitmap.height * factor).roundToInt().coerceAtLeast(1), true))
        return bitmap
    }

    suspend fun thumbnail(context: Context, uri: String): Bitmap? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri.toUri())
            if (Build.VERSION.SDK_INT >= 27) retriever.getScaledFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 240, 240)
            else retriever.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { original ->
                val scale = 240f / maxOf(original.width, original.height)
                Bitmap.createScaledBitmap(original, (original.width * scale).roundToInt().coerceAtLeast(1), (original.height * scale).roundToInt().coerceAtLeast(1), true).also { if (it !== original) original.recycle() }
            }
        } catch (_: Exception) { null } finally { retriever.release() }
    }

    suspend fun export(context: Context, uid: String, draftId: String, uri: String, edit: PostMediaEdit): String = withContext(Dispatchers.IO) {
        val video = context.contentResolver.getType(uri.toUri())?.startsWith("video/") == true
        if ((video && !edit.muted) || (!video && !edit.changesImage)) return@withContext uri
        val directory = draftDirectory(context, uid, draftId).apply { mkdirs() }
        val key = MessageDigest.getInstance("SHA-256").digest("$uri|$edit".toByteArray()).joinToString("") { "%02x".format(it) }
        val output = File(directory, "$key.${if (video) "mp4" else "png"}")
        if (!output.exists() || output.length() == 0L) {
            val partial = File(directory, "$key.partial")
            try {
                if (video) muteVideo(context, uri, partial)
                else {
                    val bitmap = renderImage(context, uri, edit, 2560)
                    try { partial.outputStream().use { check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, it)) { "Image export failed." } } }
                    finally { bitmap.recycle() }
                }
                ensureActive()
                check(partial.renameTo(output)) { "Couldn't save your edited media. Please retry." }
            } finally { if (partial.exists()) partial.delete() }
        }
        FileProvider.getUriForFile(context, "${context.packageName}.postmedia", output).toString()
    }

    private suspend fun muteVideo(context: Context, uri: String, output: File) {
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        try {
            extractor.setDataSource(context, uri.toUri(), null)
            val tracks = (0 until extractor.trackCount).filter { extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true }
            require(tracks.size == 1) { "This video can't be muted here. Keep its original sound or choose another clip." }
            val index = tracks.single(); val format = extractor.getTrackFormat(index)
            muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val retriever = MediaMetadataRetriever()
            try { retriever.setDataSource(context, uri.toUri()); val rotation = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0; muxer.setOrientationHint(rotation) }
            finally { retriever.release() }
            val target = muxer.addTrack(format)
            extractor.selectTrack(index); muxer.start(); started = true
            val size = if (format.containsKey(MediaFormat.KEY_MAX_INPUT_SIZE)) format.getInteger(MediaFormat.KEY_MAX_INPUT_SIZE) else 4 * 1024 * 1024
            val buffer = ByteBuffer.allocateDirect(size.coerceIn(4 * 1024 * 1024, 32 * 1024 * 1024))
            val info = MediaCodec.BufferInfo(); var frames = 0
            while (true) {
                kotlinx.coroutines.currentCoroutineContext().ensureActive()
                buffer.clear()
                val bytes = extractor.readSampleData(buffer, 0)
                if (bytes < 0) break
                val flags = extractor.sampleFlags
                // Only complete, unencrypted samples can be copied directly into the output.
                require(flags and MediaExtractor.SAMPLE_FLAG_SYNC.inv() == 0) {
                    "This clip can't be muted here. Keep its original sound or choose another clip."
                }
                val codecFlags = if (flags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                info.set(0, bytes, extractor.sampleTime, codecFlags)
                muxer.writeSampleData(target, buffer, info); frames++; extractor.advance()
            }
            check(frames > 0) { "The video has no readable frames." }
            muxer.stop(); started = false
        } finally { if (started) runCatching { muxer?.stop() }; muxer?.release(); extractor.release() }
    }

    fun clear(context: Context, uid: String, draftId: String) {
        val directory = draftDirectory(context, uid, draftId)
        if (directory.exists()) directory.deleteRecursively()
    }
    private fun draftDirectory(context: Context, uid: String, draftId: String): File {
        require(uid.matches(Regex("[a-zA-Z0-9_-]{1,128}")) && draftId.matches(Regex("[a-zA-Z0-9_-]{1,100}")))
        val root = File(context.filesDir, "post_media").canonicalFile
        return File(root, "$uid/$draftId").canonicalFile.also { check(it.path.startsWith(root.path + File.separator)) }
    }
}
