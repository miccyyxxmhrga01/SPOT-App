package com.example.spotapp.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.Locale

class ProfileRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    companion object { val shared by lazy { ProfileRepository() } }
    private fun uid() = checkNotNull(auth.currentUser?.uid) { "Sign in to continue." }
    fun listen(id: String, result: (SpotUser?) -> Unit, error: (String) -> Unit = {}): ListenerRegistration =
        db.collection(if (id == auth.currentUser?.uid) "users" else "publicProfiles").document(id).addSnapshotListener { s, e ->
            if (e != null) error("Profile couldn't load.") else result(s?.takeIf { it.exists() }?.let { profileFrom(it.id, it.data.orEmpty()) })
        }

    suspend fun search(text: String): List<SpotUser> = coroutineScope {
        val key = text.trim().lowercase(Locale.ROOT).removePrefix("@")
        val directory = db.collection("publicProfiles")
        val docs = if (key.isBlank()) directory.orderBy("nameKey").limit(30).get().awaitSocial().documents
        else listOf("nameKey", "usernameKey").map { field -> async {
            directory.orderBy(field).startAt(key).endAt(key + "\uf8ff").limit(30).get().awaitSocial().documents
        } }.flatMap { it.await() }
        docs.distinctBy { it.id }.map { profileFrom(it.id, it.data.orEmpty()) }
    }

    /** Role-aware, paged public directory. Prefix search supports names and @usernames. */
    suspend fun creators(search: String = "", category: String = "", after: DocumentSnapshot? = null): SocialPage<com.example.spotapp.ui.theme.models.SpotUiProfile> {
        val term = search.trim().lowercase(Locale.ROOT)
        val field = if (term.startsWith("@")) "usernameKey" else "nameKey"
        val key = term.removePrefix("@")
        var query: Query = db.collection("publicProfiles").whereEqualTo("accountType", AccountType.STUDENT.storageValue)
        if (category.isNotBlank()) query = query.whereArrayContains("talentCategories", category)
        query = query.orderBy(field)
        if (key.isNotBlank()) query = query.whereGreaterThanOrEqualTo(field, key).whereLessThanOrEqualTo(field, key + "\uf8ff")
        if (after != null) query = query.startAfter(after)
        val snapshot = query.limit(30).get(Source.SERVER).awaitSocial()
        return SocialPage(snapshot.documents.map { profileFrom(it.id, it.data.orEmpty()).asProfileUi() }, snapshot.documents.lastOrNull(), snapshot.size() == 30)
    }

    suspend fun loadProfiles(ids: List<String>): List<SpotUser> = ids.distinct().chunked(30).flatMap { group ->
        db.collection("publicProfiles").whereIn(FieldPath.documentId(), group).limit(30).get().awaitSocial()
            .documents.map { profileFrom(it.id, it.data.orEmpty()) }
    }

    suspend fun save(details: ProfileDetails, photo: String?, pronouns: String, links: String, gender: String, completing: Boolean = false) {
        details.validationError()?.let { throw IllegalArgumentException(it) }
        require(pronouns.length <= 40 && links.length <= 300 && gender.length <= 40) { "One of your fields is too long." }
        require(links.isBlank() || links.startsWith("https://")) { "Use a full https:// link." }
        val me = uid()
        val name = details.username.trim().lowercase(Locale.ROOT).removePrefix("@")
        val duplicate = db.collection("publicProfiles").whereEqualTo("usernameKey", name).limit(2).get(Source.SERVER).awaitSocial()
        require(duplicate.documents.none { it.id != me }) { "That username is already taken." }
        val account = db.collection("users").document(me)
        val reservation = db.collection("usernames").document(name)
        db.runTransaction { tx ->
            val old = tx.get(account)
            val reserved = tx.get(reservation)
            check(!reserved.exists() || reserved.getString("uid") == me) { "That username is already taken." }
            if (old.getBoolean("profileCompleted") == true) check(old.getString("accountType") == details.accountType.storageValue) { "Your account type can't be changed here." }
            val oldName = old.getString("username").orEmpty().lowercase(Locale.ROOT)
            val oldReservation = if (oldName.isNotBlank() && oldName != name) db.collection("usernames").document(oldName) else null
            val releaseOld = oldReservation?.let { tx.get(it).getString("uid") == me } == true
            val fields = details.firestoreFields().toMutableMap().apply {
                put("profileImageUrl", photo ?: old.getString("profileImageUrl").orEmpty()); put("pronouns", pronouns.trim()); put("links", links.trim()); put("gender", gender.trim())
                put("updatedAt", FieldValue.serverTimestamp())
                if (completing) {
                    put("uid", me); put("email", auth.currentUser?.email.orEmpty()); put("emailVerified", auth.currentUser?.isEmailVerified == true)
                    put("profileCompleted", true)
                    if (!old.exists()) put("createdAt", FieldValue.serverTimestamp())
                }
            }
            tx.set(account, fields, SetOptions.merge())
            tx.set(db.collection("publicProfiles").document(me), publicProfileFields(old.data.orEmpty() + fields))
            tx.set(reservation, mapOf("uid" to me))
            if (releaseOld) tx.delete(oldReservation!!)
        }.awaitSocial()
    }

    suspend fun syncPublicProfile() {
        val account = db.collection("users").document(uid())
        db.runTransaction { tx ->
            val s = tx.get(account)
            if (s.getBoolean("profileCompleted") == true) tx.set(db.collection("publicProfiles").document(s.id), publicProfileFields(s.data.orEmpty()))
        }.awaitSocial()
    }
}

internal fun publicProfileFields(d: Map<String, Any?>): Map<String, Any> {
    val keys = listOf("displayName", "username", "profileImageUrl", "bio", "course", "organization", "accountType", "pronouns", "links", "gender")
    return keys.associateWith { d[it] as? String ?: "" } + mapOf(
        "talentCategories" to (d["talentCategories"] as? List<*>).orEmpty().filterIsInstance<String>(),
        "seekingTalents" to (d["seekingTalents"] as? List<*>).orEmpty().filterIsInstance<String>(),
        "nameKey" to (d["displayName"] as? String).orEmpty().lowercase(Locale.ROOT),
        "usernameKey" to (d["username"] as? String).orEmpty().lowercase(Locale.ROOT).removePrefix("@"),
        "isPrivate" to (d["isPrivate"] == true), "privacyUpdating" to (d["privacyUpdating"] == true))
}

internal fun profileFrom(id: String, d: Map<String, Any?>) = SpotUser(
    uid = id, displayName = d["displayName"] as? String ?: d["fullName"] as? String ?: "",
    username = d["username"] as? String ?: "", course = d["course"] as? String ?: "",
    talentCategories = (d["talentCategories"] as? List<*>).orEmpty().filterIsInstance<String>(),
    bio = d["bio"] as? String ?: "", profileImageUrl = d["profileImageUrl"] as? String ?: "",
    accountType = AccountType.fromStorage(d["accountType"] as? String), organization = d["organization"] as? String ?: "",
    seekingTalents = (d["seekingTalents"] as? List<*>).orEmpty().filterIsInstance<String>(),
    pronouns = d["pronouns"] as? String ?: "", links = d["links"] as? String ?: "", gender = d["gender"] as? String ?: "",
    isPrivate = d["isPrivate"] == true, privacyUpdating = d["privacyUpdating"] == true)

/** Reference-counted identity streams prevent repeated listeners for the same visible author. */
object ProfileIdentityStore {
    private data class Entry(val state: MutableStateFlow<SpotUser?> = MutableStateFlow(null), var clients: Int = 0, var listener: ListenerRegistration? = null)
    private val entries = linkedMapOf<String, Entry>()
    private var account: String? = null
    @Synchronized private fun entry(uid: String): Entry {
        val current = runCatching { FirebaseAuth.getInstance().currentUser?.uid }.getOrNull()
        if (current != account) { entries.values.forEach { it.listener?.remove(); it.state.value = null }; entries.clear(); account = current }
        return entries.getOrPut(uid) { Entry() }
    }
    @Synchronized fun identity(uid: String): StateFlow<SpotUser?> = entry(uid).state
    @Synchronized fun acquire(uid: String): () -> Unit {
        if (uid.isBlank()) return {}
        val e = entry(uid)
        if (account == null) return {}
        e.clients++
        if (e.listener == null) e.listener = ProfileRepository.shared.listen(uid, { e.state.value = it })
        return { synchronized(this) {
            e.clients = (e.clients - 1).coerceAtLeast(0)
            if (e.clients == 0) { e.listener?.remove(); e.listener = null }
            if (entries.size > 256) entries.entries.removeAll { it.value.clients == 0 && it.value !== e }
        } }
    }
}

fun SpotUser.asProfileUi() = com.example.spotapp.ui.theme.models.SpotUiProfile(
    uid, displayName, username, talentCategories.joinToString(", "), course, profileImageUrl,
    accountType = accountType, organization = organization, bio = bio, talentCategories = talentCategories,
    seekingTalents = seekingTalents, pronouns = pronouns, links = links, gender = gender,
    isPrivate = isPrivate, privacyUpdating = privacyUpdating)
