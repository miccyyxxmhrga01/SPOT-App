package com.example.spotapp.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot

data class CampusGroup(val groupId: String, val name: String, val description: String, val imageUrl: String,
    val category: String, val privacy: String, val ownerId: String, val ownerName: String,
    val ownerProfileImageUrl: String, val memberCount: Long, val createdAt: Long)
data class CampusEvent(val eventId: String, val title: String, val description: String, val imageUrl: String,
    val category: String, val startsAt: Long, val location: String, val organizer: String, val organizerId: String,
    val organizerName: String, val organizerProfileImageUrl: String, val participantLimit: Long?,
    val participantCount: Long, val createdAt: Long)
data class CommunityMember(val userId: String, val displayName: String, val profileImageUrl: String, val role: String = "member")
data class GroupDraft(val id: String, val name: String, val description: String, val imageUri: String,
    val category: String, val privacy: String) {
    fun error(): String? = when {
        name.trim().length !in 2..80 -> "Use 2–80 characters for your group name."
        description.isBlank() || description.length > 2000 -> "Add a description of up to 2,000 characters."
        category.isBlank() || category.length > 60 -> "Choose a talent category."
        privacy !in listOf("public", "private") -> "Choose Public or Private."
        else -> null
    }
}
data class EventDraft(val id: String, val title: String, val description: String, val imageUri: String,
    val category: String, val startsAt: Long, val location: String, val organizer: String, val participantLimit: Long?) {
    fun error(now: Long = System.currentTimeMillis()): String? = when {
        title.trim().length !in 2..100 -> "Use 2–100 characters for the event title."
        description.isBlank() || description.length > 3000 -> "Add a description of up to 3,000 characters."
        category.isBlank() || category.length > 60 -> "Choose a talent category."
        startsAt <= now -> "Choose a future date and time."
        location.isBlank() || location.length > 160 -> "Enter an event location of up to 160 characters."
        organizer.isBlank() || organizer.length > 100 -> "Enter the organizer name."
        participantLimit != null && participantLimit !in 1..100000 -> "Use a participant limit between 1 and 100,000, or leave it empty."
        else -> null
    }
}
internal fun DocumentSnapshot.group() = if (!exists()) null else CampusGroup(id, getString("name").orEmpty(),
    getString("description").orEmpty(), getString("imageUrl").orEmpty(), getString("category").orEmpty(),
    getString("privacy").orEmpty(), getString("ownerId").orEmpty(), getString("ownerName").orEmpty(),
    getString("ownerProfileImageUrl").orEmpty(), getLong("memberCount") ?: 0, millis("createdAt"))
internal fun DocumentSnapshot.event() = if (!exists()) null else CampusEvent(id, getString("title").orEmpty(),
    getString("description").orEmpty(), getString("imageUrl").orEmpty(), getString("category").orEmpty(), millis("startsAt"),
    getString("location").orEmpty(), getString("organizer").orEmpty(), getString("organizerId").orEmpty(),
    getString("organizerName").orEmpty(), getString("organizerProfileImageUrl").orEmpty(), getLong("participantLimit"),
    getLong("participantCount") ?: 0, millis("createdAt"))
internal fun DocumentSnapshot.communityMember() = if (!exists()) null else CommunityMember(id,
    getString("displayName").orEmpty(), getString("profileImageUrl").orEmpty(), getString("role") ?: "member")
private fun DocumentSnapshot.millis(key: String) = (get(key) as? Timestamp)?.toDate()?.time ?: 0L
