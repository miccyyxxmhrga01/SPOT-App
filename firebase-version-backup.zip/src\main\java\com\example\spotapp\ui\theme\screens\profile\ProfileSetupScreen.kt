package com.example.spotapp

import com.example.spotapp.ui.theme.spotSp

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.example.spotapp.data.AccountType
import com.example.spotapp.data.AuthRepository
import com.example.spotapp.data.ProfileDetails
import com.example.spotapp.data.cloudinary.CloudinaryUploader
import com.example.spotapp.ui.theme.SPOTAppTheme
import com.example.spotapp.ui.theme.InterFontFamily
import com.example.spotapp.ui.theme.components.SpotAuthButton
import com.example.spotapp.ui.theme.components.awaitSpotAuthResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.launch
import java.util.Locale

private val ProfileTalentOptions = com.example.spotapp.data.SpotTalentCategories

// Keep the original degree names as the stored values for student profiles.
internal val ProfileCourseOptions = listOf(
    "Bachelor of Science in Computer Science",
    "Bachelor of Science in Information Technology",
    "Bachelor of Science in Criminology",
    "Bachelor of Science in Food Technology",
    "Bachelor of Science in Electrical Technology",
    "Bachelor of Science in Electronics Technology"
)

@Composable
fun ProfileSetupScreen(
    onSetupComplete: () -> Unit
) {
    var loading by remember {
        mutableStateOf(false)
    }

    var message by remember {
        mutableStateOf("")
    }

    val scope = rememberCoroutineScope()

    val latestComplete by rememberUpdatedState(
        onSetupComplete
    )

    ProfileSetupFlow(
        initialName = AuthRepository.currentUserDisplayName(),

        loading = loading,

        message = message,

        onEdit = {
            message = ""
        },

        onExit = {
            if (!loading) {
                AuthRepository.logOut()
            }
        },

        onSave = { profile, photo ->

            if (loading) {
                return@ProfileSetupFlow
            }

            loading = true
            message = ""

            /*
             * Saves the profile AFTER we have the
             * Cloudinary image URL.
             */
            fun saveProfile(
                profileImageUrl: String?
            ) {

                scope.launch {

                    try {

                        val result =
                            awaitSpotAuthResult { callback ->

                                AuthRepository.completeProfile(
                                    profile = profile,
                                    profileImageUrl = profileImageUrl,
                                    callback = callback
                                )
                            }

                        if (result.first) {

                            latestComplete()

                        } else {

                            message =
                                result.second
                                    ?: "Could not save your profile. Please retry."

                            loading = false
                        }

                    } catch (
                        timeout: TimeoutCancellationException
                    ) {

                        message =
                            "This took too long. Check your connection and retry."

                        loading = false

                    } catch (
                        cancelled: CancellationException
                    ) {

                        loading = false

                        throw cancelled

                    } catch (
                        error: Exception
                    ) {

                        message =
                            error.message
                                ?: "Could not save your profile. Please retry."

                        loading = false
                    }
                }
            }

            /*
             * Photo is optional in your existing UI.
             *
             * If the user didn't select one,
             * simply save the profile without an image.
             */
            if (photo == null) {

                saveProfile(
                    profileImageUrl = null
                )

            } else {

                /*
                 * Upload selected profile picture
                 * to Cloudinary first.
                 */
                CloudinaryUploader.uploadMedia(
                    uri = photo,

                    folder = "spot/profile_images",

                    onSuccess = { imageUrl ->

                        // Cloudinary returned the permanent URL.
                        saveProfile(
                            profileImageUrl = imageUrl
                        )
                    },

                    onError = { error ->

                        loading = false

                        message =
                            "Profile photo upload failed: $error"
                    }
                )
            }
        }
    )
}

@Composable
internal fun ProfileSetupFlow(
    initialName: String = "",
    loading: Boolean = false,
    message: String = "",
    onEdit: () -> Unit = {},
    onExit: () -> Unit,
    onSave: (ProfileDetails, Uri?) -> Unit
) {
    var step by rememberSaveable { mutableIntStateOf(0) }
    var roleValue by rememberSaveable { mutableStateOf<String?>(null) }
    val role = AccountType.fromStorage(roleValue)
    var name by rememberSaveable { mutableStateOf(initialName) }
    var username by rememberSaveable { mutableStateOf("") }
    var course by rememberSaveable { mutableStateOf("") }
    var organization by rememberSaveable { mutableStateOf("") }
    var talents by rememberSaveable { mutableStateOf(emptyList<String>()) }
    var interests by rememberSaveable { mutableStateOf(emptyList<String>()) }
    var bio by rememberSaveable { mutableStateOf("") }
    var photoValue by rememberSaveable { mutableStateOf<String?>(null) }
    var editingUsername by rememberSaveable { mutableStateOf(false) }
    var localError by remember { mutableStateOf("") }
    var choosingTalents by remember { mutableStateOf(false) }
    var choosingCourse by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val focus = LocalFocusManager.current
    val density = LocalDensity.current
    val nameFocus = remember { FocusRequester() }
    val usernameFocus = remember { FocusRequester() }
    val keyboardVisible = WindowInsets.ime.getBottom(density) > 0
    val photo = photoValue?.let(Uri::parse)
    val isStudent = role == AccountType.STUDENT
    val details = ProfileDetails(role ?: AccountType.STUDENT, name, username, course, talents, organization, interests, bio)

    fun edited() { localError = ""; onEdit() }
    fun back() {
        if (loading) return
        focus.clearFocus()
        if (step > 0) { step--; editingUsername = false; edited() }
        else onExit()
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                photoValue = uri.toString()
                edited()
            } catch (error: SecurityException) {
                localError = "Couldn't keep access to this photo. Please choose another image."
            }
        }
    }

    BackHandler { back() }
    if (choosingCourse) {
        CoursePicker(
            selected = course,
            onSelect = { course = it; choosingCourse = false; edited() },
            onDismiss = { choosingCourse = false }
        )
    }
    if (choosingTalents) {
        TalentPicker(
            title = if (isStudent) "Your talents" else "Talents to discover",
            selected = if (isStudent) talents else interests,
            onToggle = { value ->
                val selected = if (isStudent) talents else interests
                val updated = if (value in selected) selected - value else selected + value
                if (isStudent) talents = updated else interests = updated
                edited()
            },
            onDismiss = { choosingTalents = false }
        )
    }

    SignupFrame(step = 2, onBack = { back() }, enabled = !loading,
        backLabel = if (step == 0) "Sign out" else "Previous profile step") {
        val height = maxHeight / density.fontScale
        val compact = height < 450.dp
        val tiny = height < 360.dp
        Column(Modifier.fillMaxSize()) {
            if (!tiny) {
                Text("YOUR PROFILE  ·  ${step + 1} / 4", color = SignupGoldDark,
                    fontSize = 10.spotSp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp,
                    modifier = Modifier.padding(top = 8.dp, bottom = if (compact) 8.dp else 16.dp))
            }
            BoxWithConstraints(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                val bodyHeight = maxHeight / density.fontScale
                val oneIdentityField = bodyHeight < 390.dp

                fun advance() {
                    if (loading) return
                    val error = when (step) {
                        0 -> if (role == null) "Choose how you'd like to use SPOT." else null
                        1 -> details.identityError()
                        2 -> details.detailsError()
                        else -> details.validationError()
                    }
                    if (step == 1 && oneIdentityField && !editingUsername && name.isNotBlank()) {
                        editingUsername = true
                        edited()
                    } else if (error != null) {
                        localError = error
                    } else if (step < 3) {
                        focus.clearFocus()
                        step++
                        editingUsername = false
                        edited()
                    } else {
                        focus.clearFocus()
                        onSave(details, photo)
                    }
                }

                LaunchedEffect(oneIdentityField, editingUsername, step) {
                    if (step == 1 && keyboardVisible && editingUsername) usernameFocus.requestFocus()
                }

                // Footer is outside the card and always gets its own bounded space.
                Column(Modifier.fillMaxSize()) {
                    BoxWithConstraints(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        // Use the space left after the footer, including scaled text and errors.
                        val cardHeight = maxHeight / density.fontScale
                        val dense = cardHeight < 340.dp
                        Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(26.dp), color = Color.White,
                            border = BorderStroke(1.dp, Color(0xFFE9E5D8)), shadowElevation = if (dense) 0.dp else 2.dp) {
                            Column(Modifier.padding(if (dense) 16.dp else 24.dp)) {
                                val heading = when (step) {
                                    0 -> "I'm here to..."
                                    1 -> "Make it yours"
                                    2 -> if (isStudent) "Show what you do" else "Find your next talent"
                                    else -> "A little more you"
                                }
                                if (cardHeight >= 320.dp || step == 0) {
                                    Text(heading, color = SignupInk, fontSize = if (dense) 23.spotSp else 28.spotSp,
                                        fontWeight = FontWeight.Bold, letterSpacing = (-0.6).sp)
                                    if (!dense) {
                                        Spacer(Modifier.height(7.dp))
                                        Text(when (step) {
                                            0 -> "Choose the profile that fits you."
                                            1 -> "Choose how you'll appear to the community."
                                            2 -> if (isStudent) "Let people know what you love creating."
                                                else "Tell the community what you're looking for."
                                            else -> "Photo and bio are optional. Finish whenever you're ready."
                                        }, color = SignupMuted, fontSize = 13.spotSp, lineHeight = 19.sp)
                                    }
                                    Spacer(Modifier.height(if (dense) 10.dp else 22.dp))
                                }
                                when (step) {
                                    0 -> Column(Modifier.selectableGroup(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        ProfileRoleCard(AccountType.STUDENT, role, dense, !loading) { roleValue = it.storageValue; edited() }
                                        ProfileRoleCard(AccountType.TALENT_SEEKER, role, dense, !loading) { roleValue = it.storageValue; edited() }
                                    }
                                    1 -> {
                                        if (oneIdentityField && editingUsername) {
                                            TextButton(onClick = { editingUsername = false; edited() }, enabled = !loading,
                                                contentPadding = PaddingValues(0.dp)) {
                                                Text("Edit display name", color = SignupGoldDark, fontSize = 12.spotSp)
                                            }
                                        }
                                        if (!oneIdentityField || !editingUsername) {
                                            ProfileField(name, { name = it.take(60); edited() }, "Display name", "e.g. Alex Santos",
                                                Modifier.focusRequester(nameFocus).testTag("profile-name")
                                                    .onFocusChanged { if (it.isFocused) editingUsername = false },
                                                enabled = !loading, capitalization = KeyboardCapitalization.Words,
                                                imeAction = ImeAction.Next, onDone = {
                                                    if (name.isBlank()) localError = "Enter the name you want people to see."
                                                    else { editingUsername = true; if (!oneIdentityField) usernameFocus.requestFocus() }
                                                })
                                        }
                                        if (!oneIdentityField) Spacer(Modifier.height(10.dp))
                                        if (!oneIdentityField || editingUsername) {
                                            ProfileField(username, { username = it.lowercase(Locale.ROOT).take(30); edited() },
                                                "Username", "3–30 letters, numbers or underscores",
                                                Modifier.focusRequester(usernameFocus).testTag("profile-username")
                                                    .onFocusChanged { if (it.isFocused) editingUsername = true },
                                                enabled = !loading, prefix = "@", onDone = { advance() })
                                        }
                                        if (!dense) {
                                            Spacer(Modifier.height(12.dp))
                                            Text("Use a name you're comfortable sharing publicly.", color = SignupMuted,
                                                fontSize = 12.spotSp, lineHeight = 18.sp)
                                        }
                                    }
                                    2 -> {
                                        if (isStudent) {
                                            CourseSelector(course, enabled = !loading,
                                                onClick = { focus.clearFocus(); choosingCourse = true })
                                        } else {
                                            ProfileField(organization, { organization = it.take(80); edited() }, "Organization (optional)",
                                                "Company, team or independent",
                                                Modifier.testTag("profile-organization"), enabled = !loading,
                                                capitalization = KeyboardCapitalization.Words, onDone = { focus.clearFocus() })
                                        }
                                        Spacer(Modifier.height(12.dp))
                                        TalentSelector(if (isStudent) "Your talents" else "Looking for (optional)",
                                            if (isStudent) talents else interests, !loading,
                                            onClick = { focus.clearFocus(); choosingTalents = true })
                                        if (!dense) {
                                            Spacer(Modifier.height(12.dp))
                                            Text(if (isStudent) "Choose at least one. You can showcase more than one talent."
                                                else "No organization yet? You can leave both fields empty.",
                                                color = SignupMuted, fontSize = 12.spotSp, lineHeight = 18.sp)
                                        }
                                    }
                                    3 -> {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(onClick = { picker.launch(arrayOf("image/*")) }, enabled = !loading,
                                                shape = CircleShape, color = Color(0xFFFFF5D6), modifier = Modifier.size(if (dense) 48.dp else 68.dp)) {
                                                if (photo != null) AsyncImage(photo, "Selected profile photo", contentScale = ContentScale.Crop,
                                                    modifier = Modifier.fillMaxSize())
                                                else Box(contentAlignment = Alignment.Center) {
                                                    Icon(Icons.Default.CameraAlt, "Add profile photo", tint = SignupGoldDark)
                                                }
                                            }
                                            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                                                Text(name, color = SignupInk, fontWeight = FontWeight.Bold, fontSize = 15.spotSp,
                                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text("@${username.trim()}", color = SignupMuted, fontSize = 12.spotSp,
                                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                if (!dense) Text(role?.label.orEmpty(), color = SignupGoldDark, fontSize = 12.spotSp)
                                            }
                                            if (photo != null) TextButton(onClick = { photoValue = null; edited() }, enabled = !loading) {
                                                Text("Remove", color = SignupGoldDark, fontSize = 12.spotSp)
                                            }
                                        }
                                        Spacer(Modifier.height(if (dense) 8.dp else 18.dp))
                                        ProfileField(bio, { bio = it.take(160); edited() }, "Bio (optional)",
                                            if (isStudent) "What do you love creating?" else "What opportunities are you looking to offer?",
                                            Modifier.testTag("profile-bio"), enabled = !loading,
                                            capitalization = KeyboardCapitalization.Sentences,
                                            singleLine = dense, onDone = { focus.clearFocus() })
                                        if (!dense) Text("${bio.length}/160  ·  Photo and bio are optional", color = SignupMuted,
                                            fontSize = 11.spotSp, modifier = Modifier.padding(top = 8.dp))
                                    }
                                }
                            }
                        }
                    }
                    val error = localError.ifBlank { message }
                    if (error.isNotBlank()) {
                        Text(error, color = Color(0xFFB3261E), fontSize = 12.spotSp, lineHeight = 16.sp,
                            maxLines = 3, overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 8.dp).semantics { liveRegion = LiveRegionMode.Polite })
                    }
                    Spacer(Modifier.height(if (tiny) 8.dp else 16.dp))
                    Box(Modifier.testTag("profile-submit")) {
                        SpotAuthButton(if (step == 3) "Finish setup" else "Continue", loading = loading,
                            enabled = step != 0 || role != null, onClick = { advance() })
                    }
                    if (!compact) Text(when (step) {
                        0 -> "Up next: your name and username."
                        1 -> if (isStudent) "Next: your course and talents." else "Next: what you're looking for."
                        2 -> "Next: an optional photo and bio."
                        else -> "Your public profile is ready to meet the community."
                    }, color = SignupMuted, fontSize = 12.spotSp, lineHeight = 17.sp,
                        modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                }
            }
        }
    }
}

@Composable
private fun ProfileRoleCard(type: AccountType, selected: AccountType?, compact: Boolean, enabled: Boolean,
    onSelect: (AccountType) -> Unit) {
    val active = selected == type
    Surface(Modifier.fillMaxWidth().selectable(active, enabled, Role.RadioButton) { onSelect(type) }
        .testTag("role-${type.storageValue}"),
        shape = RoundedCornerShape(18.dp), color = if (active) Color(0xFFFFF6D9) else Color(0xFFFCFCF9),
        border = BorderStroke(if (active) 2.dp else 1.dp, if (active) SignupGold else Color(0xFFE4E2D8))) {
        Row(Modifier.padding(if (compact) 12.dp else 18.dp).heightIn(min = 40.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(if (type == AccountType.STUDENT) Icons.Default.School else Icons.Default.Search,
                null, Modifier.size(26.dp), tint = SignupGoldDark)
            Column(Modifier.padding(horizontal = 12.dp).weight(1f)) {
                Text(type.label, color = SignupInk, fontSize = 16.spotSp, fontWeight = FontWeight.Bold)
                if (!compact) {
                    Spacer(Modifier.height(5.dp))
                    Text(if (type == AccountType.STUDENT) "Showcase my talent and connect." else "Discover and hire campus talent.",
                        color = SignupMuted, fontSize = 12.spotSp, lineHeight = 17.sp)
                }
            }
            if (active) Icon(Icons.Default.Check, "Selected", Modifier.size(20.dp), tint = SignupGoldDark)
        }
    }
}

@Composable
private fun ProfileField(
    value: String, onChange: (String) -> Unit, label: String, placeholder: String,
    modifier: Modifier = Modifier, enabled: Boolean = true, prefix: String? = null,
    capitalization: KeyboardCapitalization = KeyboardCapitalization.None,
    singleLine: Boolean = true, imeAction: ImeAction = ImeAction.Done, onDone: () -> Unit = {}
) {
    OutlinedTextField(value, onChange, modifier.fillMaxWidth(), enabled = enabled,
        label = { Text(label) }, placeholder = { Text(placeholder, fontSize = 13.spotSp) },
        prefix = prefix?.let { { Text(it) } }, singleLine = singleLine, minLines = if (singleLine) 1 else 3,
        maxLines = if (singleLine) 1 else 3, textStyle = TextStyle(fontFamily = InterFontFamily, fontSize = 15.spotSp), shape = RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(capitalization = capitalization, keyboardType = KeyboardType.Text,
            imeAction = imeAction, autoCorrectEnabled = capitalization != KeyboardCapitalization.None),
        keyboardActions = KeyboardActions(onNext = { onDone() }, onDone = { onDone() }),
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = SignupGoldDark, unfocusedBorderColor = Color(0xFFDDDCD4),
            focusedLabelColor = SignupGoldDark, unfocusedLabelColor = SignupMuted, cursorColor = SignupGoldDark,
            focusedTextColor = SignupInk, unfocusedTextColor = SignupInk, unfocusedContainerColor = Color(0xFFFDFDFA)))
}

@Composable
private fun CourseSelector(selected: String, enabled: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().testTag("profile-course"),
        shape = RoundedCornerShape(14.dp), color = Color(0xFFFDFDFA), border = BorderStroke(1.dp, Color(0xFFDDDCD4))) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Course", color = SignupGoldDark, fontFamily = InterFontFamily,
                    fontSize = 12.spotSp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(3.dp))
                Text(selected.replace("Bachelor of Science in ", "BS ").ifBlank { "Choose your course" },
                    color = if (selected.isBlank()) SignupMuted else SignupInk, fontFamily = InterFontFamily,
                    fontSize = 14.spotSp, lineHeight = 20.sp)
            }
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Default.ExpandMore, null, Modifier.size(20.dp), tint = SignupGoldDark)
        }
    }
}

@Composable
private fun CoursePicker(selected: String, onSelect: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, containerColor = Color.White,
        title = { Text("Choose your course", color = SignupInk, fontFamily = InterFontFamily,
            fontWeight = FontWeight.Bold) },
        text = {
            // The separate picker can scroll on smaller screens; setup itself stays fixed.
            LazyColumn(Modifier.heightIn(max = 400.dp).selectableGroup().testTag("profile-course-options"),
                verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(ProfileCourseOptions) { option ->
                    val active = option == selected
                    Surface(shape = RoundedCornerShape(12.dp),
                        color = if (active) Color(0xFFFFF6D9) else Color(0xFFFDFDFA)) {
                        Row(Modifier.fillMaxWidth().heightIn(min = 56.dp)
                            .selectable(active, role = Role.RadioButton) { onSelect(option) }
                            .padding(horizontal = 8.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(active, onClick = null, modifier = Modifier.padding(end = 8.dp),
                                colors = RadioButtonDefaults.colors(selectedColor = SignupGoldDark))
                            Text(option, Modifier.weight(1f), color = SignupInk, fontFamily = InterFontFamily,
                                fontSize = 14.spotSp, lineHeight = 20.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) {
            Text("Cancel", color = SignupGoldDark, fontFamily = InterFontFamily)
        } })
}

@Composable
private fun TalentSelector(title: String, selected: List<String>, enabled: Boolean, onClick: () -> Unit) {
    Surface(onClick = onClick, enabled = enabled, modifier = Modifier.fillMaxWidth().testTag("profile-talents"),
        shape = RoundedCornerShape(14.dp), color = Color(0xFFFDFDFA), border = BorderStroke(1.dp, Color(0xFFDDDCD4))) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = SignupGoldDark, fontSize = 12.spotSp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(3.dp))
                Text(selected.joinToString(", ").ifBlank { "Choose talents" }, color = SignupInk,
                    fontSize = 14.spotSp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.AutoMirrored.Filled.ArrowForward, "Choose talents", Modifier.size(20.dp), tint = SignupGoldDark)
        }
    }
}

@Composable
private fun TalentPicker(title: String, selected: List<String>, onToggle: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            LazyColumn(Modifier.heightIn(max = 360.dp)) {
                items(ProfileTalentOptions) { talent ->
                    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp)
                        .toggleable(talent in selected, role = Role.Checkbox, onValueChange = { onToggle(talent) }),
                        verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(talent in selected, onCheckedChange = null, modifier = Modifier.padding(end = 12.dp),
                            colors = CheckboxDefaults.colors(checkedColor = SignupGoldDark))
                        Text(talent, color = SignupInk)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done", color = SignupGoldDark) } })
}

@Preview(name = "Profile - role", widthDp = 393, heightDp = 780)
@Preview(name = "Profile - small phone", widthDp = 320, heightDp = 568)
@Composable
private fun ProfileSetupPreview() {
    SPOTAppTheme { ProfileSetupFlow(onExit = {}, onSave = { _, _ -> }) }
}
