package com.example.spotapp.data.ai

/** FUTURE AI INTEGRATION — PREPARE ONLY, DO NOT IMPLEMENT.
 * No implementation is installed. The composer never invokes this interface today.
 * A future integration must request user acceptance before applying any suggestion.
 */
interface PostAiService {
    suspend fun analyzeMedia(input: PostAiInput): MediaAnalysis
    suspend fun predictTalentCategory(input: PostAiInput): List<String>
    suspend fun generateCaption(input: PostAiInput): String
    suspend fun suggestTags(input: PostAiInput): List<String>
}

data class PostAiInput(val mediaUris: List<String>, val caption: String, val categories: List<String>, val tags: List<String>)
data class MediaAnalysis(val suggestedCategories: List<String>, val suggestedCaption: String?, val suggestedTags: List<String>)

/** Null means unavailable, not an implementation that fabricates empty or canned predictions. */
data class PostAiDependencies(val service: PostAiService? = null)
