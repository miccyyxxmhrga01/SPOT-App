package com.example.spotapp

import android.graphics.Bitmap
import android.net.Uri
import androidx.test.platform.app.InstrumentationRegistry
import com.example.spotapp.data.*
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.util.UUID
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Uses named Firebase apps connected ONLY to localhost emulators, never the phone's signed-in account. */
class MessagesFirebaseIntegrationTest {
    private val context get() = InstrumentationRegistry.getInstrumentation().targetContext
    private suspend fun connect(uid: String): Pair<FirebaseApp, FirebaseMessagesStore> {
        val app = FirebaseApp.initializeApp(context, FirebaseOptions.Builder().setProjectId("demo-spot-auth")
            .setApplicationId("1:123456789:android:messagestest").setApiKey("fake-emulator-key")
            .setStorageBucket("demo-spot-auth.appspot.com").build(), "messages-test-${UUID.randomUUID()}")
        val auth = FirebaseAuth.getInstance(app).apply { useEmulator("127.0.0.1", 9095) }
        val db = FirebaseFirestore.getInstance(app).apply {
            firestoreSettings = FirebaseFirestoreSettings.Builder().setPersistenceEnabled(false).build()
            useEmulator("127.0.0.1", 8185)
        }
        val storage = FirebaseStorage.getInstance(app).apply { useEmulator("127.0.0.1", 9199) }
        auth.signInWithEmailAndPassword("$uid@example.test", "emulator-password-123").await()
        assertTrue(auth.currentUser?.isEmailVerified == true)
        return app to FirebaseMessagesStore(uid, db, auth, storage)
    }
    @Test fun realAndroidRepositoryInvitesSendsRestoresPreferencesAndTransfersPrivateMedia() = runBlocking<Unit> {
        withTimeout(90_000) {
            val (aliceApp, alice) = connect("android-alice")
            val (bobApp, bob) = connect("android-bob")
            try {
                alice.syncProfile(); bob.syncProfile()
                val person = alice.people("Bob").single { it.uid == "android-bob" }
                val id = UUID.randomUUID().toString()
                alice.create(listOf(person), "", "Campus rehearsal", false, id)
                val request = bob.inbox().first { !it.loading }.requests.single { it.id == id }
                assertEquals("Campus rehearsal", request.inviteNote)
                bob.respond(id, true)
                val draft = ChatDraft(text = "Hello from the Android Firebase SDK")
                alice.send(id, draft); alice.send(id, draft)
                val messages = bob.messages(id).first { it.isNotEmpty() }
                assertEquals(1, messages.size)
                assertEquals(draft.id, messages.single().id)
                bob.preferences(id, mapOf("nickname" to "Campus partner", "muted" to true, "readAt" to true))
                val prefs = bob.inbox().first { !it.loading }.preferences.getValue(id)
                assertEquals("Campus partner", prefs.nickname); assertTrue(prefs.muted); assertTrue(prefs.readAt > 0)
                val file = File.createTempFile("message-fixture-", ".jpg", context.cacheDir)
                val bitmap = Bitmap.createBitmap(12, 12, Bitmap.Config.ARGB_8888)
                file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 80, it) }; bitmap.recycle()
                val mediaId = UUID.randomUUID().toString()
                val attachment = alice.upload(context, id, mediaId, Uri.fromFile(file), "image/jpeg") {}
                alice.send(id, ChatDraft(mediaId, attachment = attachment))
                val opened = bob.mediaFile(context, attachment)
                assertEquals(file.length(), File(opened.path!!).length())
                bob.block(alice.uid, true)
                var denied = false
                try { alice.send(id, ChatDraft(text = "Should be blocked")) } catch (_: Exception) { denied = true }
                assertTrue("Blocking must reject SDK sends", denied)
                bob.block(alice.uid, false)
                file.delete()
            } finally { aliceApp.delete(); bobApp.delete() }
        }
    }
    @Test fun unsendClearsMessagesForEveryoneAndDeleteForMeStaysPrivate() = runBlocking<Unit> {
        withTimeout(90_000) {
            val (aliceApp, alice) = connect("android-alice")
            val (bobApp, bob) = connect("android-bob")
            try {
                alice.syncProfile(); bob.syncProfile()
                val person = alice.people("Bob").single { it.uid == "android-bob" }
                val id = UUID.randomUUID().toString()
                alice.create(listOf(person), "", "Unsend check", false, id)
                bob.respond(id, true)
                val first = ChatDraft(text = "First note"); val oops = ChatDraft(text = "Oops, wrong chat")
                alice.send(id, first); alice.send(id, oops)
                fun message(app: FirebaseApp, messageId: String) = FirebaseFirestore.getInstance(app)
                    .collection("conversations").document(id).collection("messages").document(messageId)
                suspend fun denied(write: suspend () -> Unit) = try { write(); false } catch (_: Exception) { true }
                assertTrue("Only the sender may unsend", denied {
                    message(bobApp, oops.id).update(mapOf("text" to "", "attachment" to null, "unsentAt" to FieldValue.serverTimestamp())).await()
                })
                assertTrue("Unsend can't be used to edit text", denied {
                    message(aliceApp, first.id).update(mapOf("text" to "Edited", "unsentAt" to FieldValue.serverTimestamp())).await()
                })
                alice.unsend(id, first.id)
                assertEquals("Oops, wrong chat", alice.inbox().first { !it.loading }.conversations.single { it.id == id }.preview)
                alice.unsend(id, oops.id); alice.unsend(id, oops.id)
                assertEquals(UNSENT_MESSAGE_PREVIEW, bob.inbox().first { !it.loading }.conversations.single { it.id == id }.preview)
                val seen = bob.messages(id).first { list -> list.size == 2 && list.all { it.unsent && !it.pending } }
                assertTrue(seen.all { it.text.isEmpty() && it.attachment == null })
                bob.deleteForMe(id, first.id)
                assertEquals(setOf(first.id), bob.hiddenMessages(id).first { it.isNotEmpty() })
                assertTrue("Delete for you must not hide it for others", alice.hiddenMessages(id).first().isEmpty())
            } finally { aliceApp.delete(); bobApp.delete() }
        }
    }
    @Test fun privateSamplesSeedOnceAndCanBeRestoredWithoutDuplicateMessages() = runBlocking<Unit> {
        withTimeout(60_000) {
            val (app, store) = connect("android-alice")
            try {
                store.addSamples(); store.addSamples()
                val inbox = store.inbox().first { !it.loading }
                assertEquals(2, inbox.conversations.count { it.demo })
                val sample = inbox.conversations.first { it.demo && it.kind == "direct" }
                assertEquals(listOf(store.uid), sample.memberIds)
                assertEquals(2, store.messages(sample.id).first { it.isNotEmpty() }.size)
                store.preferences(sample.id, mapOf("hiddenAt" to true))
                store.addSamples()
                assertEquals(0L, store.inbox().first { !it.loading }.preferences[sample.id]?.hiddenAt ?: 0L)
            } finally { app.delete() }
        }
    }
}

private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { c ->
    addOnSuccessListener { if (c.isActive) c.resume(it) }.addOnFailureListener { if (c.isActive) c.resumeWithException(it) }
}
