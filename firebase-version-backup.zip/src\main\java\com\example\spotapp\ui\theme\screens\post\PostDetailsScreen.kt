package com.example.spotapp.ui.theme.screens.post

import com.example.spotapp.ui.theme.components.spotAmbientBackground
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.spotapp.data.*
import com.example.spotapp.ui.theme.models.SpotUiProfile

@Composable
internal fun PostDetailsScreen(profile: SpotUiProfile, draft: PostDraft, update: (PostDraft) -> Unit, error: String,
    busy: Boolean, back: () -> Unit, edit: () -> Unit, save: () -> Unit, publish: () -> Unit) {
    var sheet by remember { mutableStateOf<PostSheet?>(null) }
    val focus = LocalFocusManager.current
    fun open(value: PostSheet) { focus.clearFocus(); sheet = value }
    Scaffold(containerColor = Color.Transparent, contentWindowInsets = WindowInsets(0, 0, 0, 0), modifier = Modifier.spotAmbientBackground(PostIvory).imePadding().testTag("post-details"),
        topBar = { PostTopBar("New post", back) }, bottomBar = {
            Surface(color = Color.White, shadowElevation = 4.dp) {
                Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(border = BorderStroke(1.dp, PostLine), onClick = save, enabled = !busy, modifier = Modifier.weight(1f).heightIn(min = 48.dp).testTag("save-draft"), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = PostInk)) {
                        Icon(Icons.Default.Drafts, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Draft")
                    }
                    Button(onClick = publish, enabled = !busy && (draft.caption.isNotBlank() || draft.mediaUris.isNotEmpty()), modifier = Modifier.weight(1.5f).heightIn(min = 48.dp).testTag("publish-post"),
                        shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = PostGold, contentColor = PostInk)) { Text("Post") }
                }
            }
        }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 20.dp)) {
            Text("@${profile.username.removePrefix("@")}", style = MaterialTheme.typography.labelMedium, color = PostMuted, modifier = Modifier.padding(vertical = 8.dp))
            if (draft.mediaUris.isNotEmpty()) {
                PostDraftMediaPreview(draft, edit)
                Spacer(Modifier.height(14.dp))
            }
            OutlinedTextField(draft.caption, { update(draft.copy(caption = it.take(2000))) }, Modifier.fillMaxWidth().testTag("post-caption"),
                placeholder = { Text("Share the story behind your talent…") }, minLines = 2, maxLines = 6, enabled = !busy, textStyle = MaterialTheme.typography.bodyMedium,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color.Transparent, focusedBorderColor = PostLine, cursorColor = PostGold),
                supportingText = { if (draft.caption.length > 1800) Text("${draft.caption.length}/2,000") })
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 14.dp)) {
                OutlinedButton(border = BorderStroke(1.dp, PostLine), onClick = { open(PostSheet.TAGS) }, modifier = Modifier.testTag("post-tags"), shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = PostInk)) { Icon(Icons.Default.Tag, null, Modifier.size(17.dp)); Spacer(Modifier.width(5.dp)); Text("Tags${if (draft.tags.isEmpty()) "" else " · ${draft.tags.size}"}") }
                OutlinedButton(border = BorderStroke(1.dp, PostLine), onClick = { open(PostSheet.PEOPLE) }, shape = RoundedCornerShape(10.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = PostInk)) { Text("@ Mention${if (draft.taggedPeople.isEmpty()) "" else " · ${draft.taggedPeople.size}"}") }
            }
            if (draft.tags.isNotEmpty()) Text(draft.tags.joinToString(" ") { "#$it" }, style = MaterialTheme.typography.bodySmall, color = PostGold, modifier = Modifier.padding(bottom = 16.dp).clickable { open(PostSheet.TAGS) })
            HorizontalDivider(color = PostLine)
            DetailsRow(Icons.Default.AutoAwesome, "Talent category", draft.categories.joinToString(", ").ifBlank { "Select" }, "post-category") { open(PostSheet.CATEGORY) }
            TalentAiCard(draft, update, enabled = !busy, modifier = Modifier.padding(bottom = 12.dp))
            DetailsRow(Icons.Default.LocationOn, "Location", draft.location.ifBlank { "Add a place" }, "post-location-row") { open(PostSheet.LOCATION) }
            DetailsRow(Icons.Default.Visibility, "Who can view", audienceLabel(draft.audience), "post-visibility") { open(PostSheet.VISIBILITY) }
            HorizontalDivider(color = PostLine)
            DetailsRow(Icons.Default.Tune, "More options", "", "post-options") { open(PostSheet.OPTIONS) }
            PostError(error, Modifier.padding(top = 12.dp))
        }
    }
    sheet?.let { value -> PostDetailsSheet(value, profile.uid, draft, update) { sheet = null } }
}

@Composable
private fun DetailsRow(icon: ImageVector, title: String, value: String, tag: String, click: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 62.dp).clickable(onClick = click).testTag(tag).padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(icon, null, Modifier.size(21.dp), tint = PostInk)
        Text(title, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        if (value.isNotBlank()) Text(value, style = MaterialTheme.typography.bodySmall, color = PostMuted, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 120.dp))
        Icon(Icons.Default.ChevronRight, null, Modifier.size(18.dp), tint = PostMuted)
    }
}
