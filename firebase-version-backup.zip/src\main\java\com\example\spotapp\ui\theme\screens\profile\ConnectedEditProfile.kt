package com.example.spotapp.ui.theme.screens.profile

import com.example.spotapp.ui.theme.components.spotAmbientBackground
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.spotapp.ProfileCourseOptions
import com.example.spotapp.data.*
import com.example.spotapp.data.cloudinary.uploadCommunityImage
import com.example.spotapp.ui.theme.components.SpotAvatar
import com.example.spotapp.ui.theme.models.SpotUiProfile
import kotlinx.coroutines.*
import java.util.Locale
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun ConnectedEditProfile(profile: SpotUiProfile, onBack: () -> Unit, onSaved: () -> Unit) {
    val context = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    var name by rememberSaveable(profile.uid) { mutableStateOf(profile.displayName) }
    var username by rememberSaveable(profile.uid) { mutableStateOf(profile.username) }
    var bio by rememberSaveable(profile.uid) { mutableStateOf(profile.bio) }
    var course by rememberSaveable(profile.uid) { mutableStateOf(profile.course) }
    var organization by rememberSaveable(profile.uid) { mutableStateOf(profile.organization) }
    var talents by rememberSaveable(profile.uid) { mutableStateOf(profile.talentCategories.ifEmpty { listOfNotNull(profile.talent.takeIf(String::isNotBlank)) }) }
    var seeking by rememberSaveable(profile.uid) { mutableStateOf(profile.seekingTalents) }
    var pronouns by rememberSaveable(profile.uid) { mutableStateOf(profile.pronouns) }
    var links by rememberSaveable(profile.uid) { mutableStateOf(profile.links) }
    var gender by rememberSaveable(profile.uid) { mutableStateOf(profile.gender) }
    var photo by rememberSaveable(profile.uid) { mutableStateOf(profile.profileImageUrl) }
    var localPhoto by rememberSaveable(profile.uid) { mutableStateOf<String?>(null) }
    var uploadedFor by rememberSaveable(profile.uid) { mutableStateOf("") }
    var uploadedUrl by rememberSaveable(profile.uid) { mutableStateOf("") }
    var more by rememberSaveable { mutableStateOf(false) }
    var chooseCourse by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var error by remember { mutableStateOf("") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { if (it != null) { localPhoto = it.toString(); error = "" } }
    BackHandler { if (!busy) onBack() }
    fun save() {
        if (busy) return
        val role = profile.accountType
        if (role == null) { error = "Your profile is still loading. Reopen Edit profile and retry."; return }
        val value = ProfileDetails(role, name.trim(), username.trim().lowercase(Locale.ROOT).removePrefix("@"), course, talents, organization, seeking, bio)
        value.validationError()?.let { error = it; return }
        focus.clearFocus(); busy = true; error = ""; progress = 0f
        scope.launch {
            try {
                withTimeout(180_000) {
                    val selected = localPhoto
                    val url = if (selected == null) photo else if (selected == uploadedFor) uploadedUrl else {
                        uploadCommunityImage(context, selected, "spot/profiles/${profile.uid}/${UUID.randomUUID()}") { progress = it }
                            .also { uploadedFor = selected; uploadedUrl = it }
                    }
                    ProfileRepository.shared.save(value, url, pronouns, links, gender)
                }
                onSaved()
            } catch (_: TimeoutCancellationException) { error = "Save timed out. Your changes are kept; retry." }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { error = if (e is IllegalArgumentException || e is IllegalStateException) e.message.orEmpty() else "Couldn't save your profile. Retry." }
            finally { busy = false }
        }
    }
    Surface(Modifier.fillMaxSize().spotAmbientBackground(Color.White), color = Color.Transparent) {
        Column(Modifier.fillMaxSize().statusBarsPadding().imePadding().navigationBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack, enabled = !busy) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", Modifier.size(22.dp)) }
                Text("Edit profile", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                TextButton(::save, enabled = !busy, modifier = Modifier.testTag("profile-save")) {
                    if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Text("Save", color = Color(0xFF8A5C10))
                }
            }
            HorizontalDivider(color = Color(0xFFE5E5E5))
            if (busy && localPhoto != null) LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth(), color = Color(0xFFE8B84B))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    SpotAvatar(localPhoto ?: photo, "Profile photo", Modifier.size(88.dp).clickable(enabled = !busy) { picker.launch("image/*") })
                    Row { TextButton({ picker.launch("image/*") }, enabled = !busy) { Text("Change photo", color = Color(0xFF8A5C10)) }
                        if (localPhoto != null || photo.isNotBlank()) TextButton({ localPhoto = null; photo = "" }, enabled = !busy) { Text("Remove") } }
                }
                if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                ProfileField("Name", name, { name = it.take(60) }, busy)
                ProfileField("Username", username, { username = it.take(30) }, busy)
                ProfileField("Bio", bio, { bio = it.take(160) }, busy, singleLine = false)
                if (profile.accountType == AccountType.STUDENT) OutlinedCard(onClick = { if (!busy) chooseCourse = true }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text("Course", style = MaterialTheme.typography.labelSmall); Text(course, style = MaterialTheme.typography.bodyMedium) }
                        Icon(Icons.Default.ExpandMore, null, Modifier.size(20.dp))
                    }
                } else ProfileField("Organization", organization, { organization = it.take(80) }, busy)
                Text(if (profile.accountType == AccountType.STUDENT) "Talents" else "Talents you seek", style = MaterialTheme.typography.titleSmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val selection = if (profile.accountType == AccountType.STUDENT) talents else seeking
                    (SpotTalentCategories + selection).distinct().forEach { talent ->
                        FilterChip(talent in selection, {
                            val next = if (talent in selection) selection - talent else (selection + talent).take(8)
                            if (profile.accountType == AccountType.STUDENT) talents = next else seeking = next
                        }, enabled = !busy, label = { Text(talent) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFFFF6DA)))
                    }
                }
                TextButton({ more = !more }) { Text("More details"); Icon(if (more) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, Modifier.size(18.dp)) }
                AnimatedVisibility(more) { Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ProfileField("Pronouns", pronouns, { pronouns = it.take(40) }, busy)
                    ProfileField("Link", links, { links = it.take(300) }, busy)
                    ProfileField("Gender", gender, { gender = it.take(40) }, busy)
                } }
            }
        }
    }
    if (chooseCourse) AlertDialog(onDismissRequest = { chooseCourse = false }, title = { Text("Course") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState())) { ProfileCourseOptions.forEach { option ->
            Row(Modifier.fillMaxWidth().clickable { course = option; chooseCourse = false }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(course == option, { course = option; chooseCourse = false }); Text(option, style = MaterialTheme.typography.bodyMedium)
            }
        } }
    }, confirmButton = { TextButton({ chooseCourse = false }) { Text("Close") } })
}

@Composable
private fun ProfileField(label: String, value: String, change: (String) -> Unit, busy: Boolean, singleLine: Boolean = true) {
    OutlinedTextField(value, change, Modifier.fillMaxWidth(), label = { Text(label) }, enabled = !busy,
        singleLine = singleLine, maxLines = if (singleLine) 1 else 4, shape = RoundedCornerShape(14.dp),
        textStyle = MaterialTheme.typography.bodyMedium,
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF8A5C10), unfocusedBorderColor = Color(0xFFE5E5E5)))
}
