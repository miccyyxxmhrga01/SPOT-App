package com.example.spotapp.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot

data class SocialComment(
    val id: String, val postId: String, val userId: String, val username: String,
    val displayName: String, val profileImageUrl: String, val text: String,
    val createdAt: Long, val likesCount: Long = 0
) {
    companion object {
        fun from(doc: DocumentSnapshot): SocialComment? {
            val d = doc.data ?: return null
            if (d["deleted"] == true) return null
            val uid = d["userId"] as? String ?: return null
            return SocialComment(doc.id, d["postId"] as? String ?: "", uid,
                d["username"] as? String ?: "", d["displayName"] as? String ?: "",
                d["profileImageUrl"] as? String ?: "", d["text"] as? String ?: "",
                (d["createdAt"] as? Timestamp)?.toDate()?.time ?: System.currentTimeMillis(),
                (d["likesCount"] as? Number)?.toLong()?.coerceAtLeast(0) ?: 0)
        }
    }
}

data class SocialNotification(
    val id: String, val type: String, val senderId: String, val senderName: String,
    val senderProfileImageUrl: String, val postId: String, val message: String,
    val createdAt: Long, val isRead: Boolean
) {
    companion object {
        fun from(doc: DocumentSnapshot): SocialNotification? {
            val d = doc.data ?: return null
            return SocialNotification(doc.id, d["type"] as? String ?: return null,
                d["senderId"] as? String ?: return null, d["senderName"] as? String ?: "SPOT member",
                d["senderProfileImageUrl"] as? String ?: "", d["postId"] as? String ?: "",
                d["message"] as? String ?: "", (d["createdAt"] as? Timestamp)?.toDate()?.time ?: 0,
                d["isRead"] == true)
        }
    }
}

data class SocialPage<T>(val items: List<T>, val cursor: DocumentSnapshot?, val hasMore: Boolean)
