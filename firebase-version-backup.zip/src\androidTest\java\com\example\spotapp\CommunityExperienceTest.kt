package com.example.spotapp

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.activity.ComponentActivity
import android.view.WindowManager
import org.junit.Before
import android.graphics.Bitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import java.io.File
import androidx.test.platform.app.InstrumentationRegistry
import com.example.spotapp.data.PostDraftStore
import com.example.spotapp.ui.theme.SPOTAppTheme
import com.example.spotapp.ui.theme.models.SpotUiProfile
import com.example.spotapp.ui.theme.screens.post.FutureAiControls
import com.example.spotapp.ui.theme.screens.post.NewPostScreen
import com.example.spotapp.ui.theme.screens.discover.CommunityEditor
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

class CommunityExperienceTest {
    @get:Rule val compose = createAndroidComposeRule<ComponentActivity>()
    @Before fun awake() { compose.activityRule.scenario.onActivity { it.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) } }
    private val profile = SpotUiProfile("composer-ui-test", "Campus creator", "creator", "Guitar", "BSCS")
    private fun capture(name: String, node: SemanticsNodeInteraction = compose.onRoot()) {
        val directory = File(InstrumentationRegistry.getInstrumentation().targetContext.cacheDir, "social-review").apply { mkdirs() }
        File(directory, "$name.png").outputStream().use { node.captureToImage().asAndroidBitmap().compress(Bitmap.CompressFormat.PNG, 100, it) }
    }
    @Test fun futureAiControlsCannotGenerate() {
        compose.setContent { SPOTAppTheme { FutureAiControls() } }
        listOf("Generate Caption", "Suggest Tags").forEach { compose.onNodeWithText(it).assertIsNotEnabled() }
        compose.onNodeWithText("AI Assist").assertIsDisplayed()
    }
    @Test fun manualComposerSavesCaptionCategoryAndEditableTags() {
        val store = PostDraftStore(InstrumentationRegistry.getInstrumentation().targetContext, profile.uid)
        store.clear()
        var saved = false
        compose.setContent { SPOTAppTheme { NewPostScreen(profile, { saved = true }, {}) } }
        compose.onNodeWithText("Write a text post").performClick()
        capture("manual-composer")
        compose.onNodeWithTag("post-caption").performScrollTo().performTextInput("An acoustic set after class")
        compose.onNodeWithTag("post-category").performScrollTo().performClick()
        compose.onNodeWithText("Guitar", useUnmergedTree = true).performScrollTo().performClick()
        compose.onNodeWithText("Done").performClick()
        compose.onNodeWithTag("post-tags").performScrollTo().performClick()
        compose.onNodeWithTag("post-tag-input").performTextInput("CampusTalent")
        compose.onNodeWithContentDescription("Add tag").performClick()
        compose.onNode(hasText("#CampusTalent") and hasAnyAncestor(isDialog())).assertExists()
        capture("manual-tags", compose.onNode(isDialog()))
        compose.onNodeWithText("Done").performClick()
        compose.onNodeWithTag("save-draft").performClick()
        compose.waitUntil(5000) { saved }
        val draft = store.load()!!
        assertEquals("An acoustic set after class", draft.caption)
        assertEquals(listOf("Guitar"), draft.categories); assertEquals(listOf("CampusTalent"), draft.tags)
        assertFalse(draft.aiCaption || draft.aiTagged || draft.aiCategorySuggested)
        store.clear()
    }
    @Test fun privateGroupExplainsOwnerApprovalWithoutCreatingData() {
        compose.setContent { SPOTAppTheme { CommunityEditor(false, profile, {}, {}) } }
        compose.onNodeWithText("Private").performScrollTo().performClick()
        compose.onNodeWithText("People can discover your group and request to join. You approve requests; only members see the member list.").performScrollTo().assertIsDisplayed()
        capture("private-group", compose.onNode(isDialog()))
    }
}
