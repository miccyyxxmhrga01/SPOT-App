package com.example.spotapp.ui.theme.screens.home

import com.example.spotapp.ui.theme.components.*
import androidx.compose.material.icons.filled.DeleteOutline

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage

data class SpotUiComment(val id: String, val username: String, val avatarUrl: String? = null,
    val text: String, val timeLabel: String = "now", val likes: Int = 0, val liked: Boolean = false,
    val userId: String = "", val pending: Boolean = false)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeCommentsSheet(sheetState: SheetState, comments: List<SpotUiComment>, currentUserAvatarUrl: String?,
    onDismiss: () -> Unit, onSendComment: (String) -> Unit, onToggleLike: (String) -> Unit,
    loading: Boolean = false, sending: Boolean = false, error: String = "", sendRevision: Int = 0,
    managedSend: Boolean = false, onRetry: () -> Unit = {}, onLoadMore: (() -> Unit)? = null,
    onProfileClick: (String) -> Unit = {}, currentUserId: String = "", onDelete: ((String) -> Unit)? = null) {
    var draft by rememberSaveable { mutableStateOf("") }
    LaunchedEffect(sendRevision) { if (sendRevision > 0) draft = "" }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState, containerColor = Color.White,
        contentWindowInsets = { WindowInsets(0, 0, 0, 0) }) {
        Column(Modifier.fillMaxWidth().imePadding().navigationBarsPadding().fillMaxHeight(0.78f).testTag("connected-comments")) {
            Text("Comments", style = MaterialTheme.typography.titleMedium, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 14.dp))
            HorizontalDivider(color = Color(0xFFE5E5E5))
            if (loading && comments.isNotEmpty()) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(0xFFAD8420))
            if (error.isNotBlank()) Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(error, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, modifier = Modifier.weight(1f))
                TextButton(onClick = onRetry) { Text("Retry") }
            }
            if (comments.isEmpty()) Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                SpotLoading(loading, SkeletonKind.ROWS) { Text("Start the conversation", style = MaterialTheme.typography.bodyMedium, color = Color(0xFF74746C)) }
            } else LazyColumn(Modifier.fillMaxWidth().weight(1f), contentPadding = PaddingValues(vertical = 10.dp)) {
                items(comments, key = { it.id }) { c ->
                    Row(Modifier.fillMaxWidth().animateItem().padding(start = 16.dp, end = 6.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.Top) {
                        SocialAvatar(c.avatarUrl, "${c.username} profile", Modifier.size(34.dp).clickable(enabled = c.userId.isNotBlank()) { onProfileClick(c.userId) }, c.userId)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(c.username, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.clickable(enabled = c.userId.isNotBlank()) { onProfileClick(c.userId) })
                            Text(c.text, style = MaterialTheme.typography.bodyMedium)
                            Text(if (c.pending) "Sending…" else c.timeLabel, style = MaterialTheme.typography.labelSmall, color = Color(0xFF74746C), modifier = Modifier.padding(top = 4.dp))
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            IconButton(onClick = { onToggleLike(c.id) }, enabled = !c.pending) {
                                Icon(if (c.liked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Like comment",
                                    Modifier.size(18.dp), tint = if (c.liked) Color(0xFFE5484D) else Color(0xFF74746C))
                            }
                            if (c.likes > 0) Text(c.likes.toString(), style = MaterialTheme.typography.labelSmall)
                            if (onDelete != null && currentUserId.isNotBlank() && c.userId == currentUserId && !c.pending)
                                IconButton({ onDelete(c.id) }, Modifier.size(36.dp)) { Icon(Icons.Default.DeleteOutline, "Delete comment", Modifier.size(16.dp), tint = Color(0xFF74746C)) }
                        }
                    }
                }
                if (onLoadMore != null) item { TextButton(onClick = onLoadMore, modifier = Modifier.fillMaxWidth()) { Text("Load older comments") } }
            }
            HorizontalDivider(color = Color(0xFFE5E5E5))
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                SocialAvatar(currentUserAvatarUrl, "Your profile", Modifier.size(32.dp), currentUserId)
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(draft, { if (it.length <= 2000) draft = it }, Modifier.weight(1f),
                    enabled = !sending, placeholder = { Text("Add a comment…", style = MaterialTheme.typography.bodyMedium) },
                    textStyle = MaterialTheme.typography.bodyMedium, maxLines = 4, shape = RoundedCornerShape(22.dp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFFAD8420), unfocusedBorderColor = Color(0xFFE5E5E5)))
                IconButton(onClick = { onSendComment(draft.trim()); if (!managedSend) draft = "" }, enabled = draft.isNotBlank() && !sending) {
                    if (sending) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                    else Icon(Icons.AutoMirrored.Filled.Send, "Post comment", tint = Color(0xFFAD8420))
                }
            }
        }
    }
}

@Composable
internal fun SocialAvatar(url: String?, description: String, modifier: Modifier = Modifier, uid: String = "") { SpotAvatar(url, description, modifier, uid) }
