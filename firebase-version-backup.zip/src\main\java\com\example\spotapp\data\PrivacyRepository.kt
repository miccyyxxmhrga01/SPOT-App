package com.example.spotapp.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import kotlinx.coroutines.CancellationException

data class SpotPreferences(val storyAudience: String = "followers", val postAudience: String = "followers",
    val likes: Boolean = true, val comments: Boolean = true, val follows: Boolean = true)

class PrivacyRepository(private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()) {
    companion object { val shared by lazy { PrivacyRepository() } }
    private fun me() = checkNotNull(auth.currentUser?.uid) { "Sign in to continue." }
    private fun user(id: String = me()) = db.collection("users").document(id)
    fun listenPreferences(result: (SpotPreferences) -> Unit, error: (String) -> Unit = {}): ListenerRegistration =
        user().collection("settings").document("experience").addSnapshotListener { s, e ->
            if (e != null) error("Settings couldn't load.") else result(SpotPreferences(
                s?.getString("storyAudience") ?: "followers", s?.getString("postAudience") ?: "followers",
                s?.getBoolean("likes") != false, s?.getBoolean("comments") != false, s?.getBoolean("follows") != false))
        }
    suspend fun savePreferences(p: SpotPreferences) = user().collection("settings").document("experience")
        .set(mapOf("storyAudience" to p.storyAudience, "postAudience" to p.postAudience,
            "likes" to p.likes, "comments" to p.comments, "follows" to p.follows)).awaitSocial()

    /** Resumable migration: don't claim a private account until every public item is protected. */
    suspend fun setPrivate(private: Boolean) {
        val id = me()
        val account = user(id)
        suspend fun state(updating: Boolean, value: Boolean? = null) {
            db.runTransaction { tx ->
                val old = tx.get(account)
                val changes = mutableMapOf<String, Any>("privacyUpdating" to updating)
                if (value != null) changes["isPrivate"] = value
                tx.update(account, changes)
                tx.set(db.collection("publicProfiles").document(id), publicProfileFields(old.data.orEmpty() + changes))
            }.awaitSocial()
        }
        if (!private) { state(false, false); return }
        state(true)
        // A interrupted migration leaves the account in a truthful, resumable "Finishing privacy" state.
        val collections = listOf(db.collection("posts").whereEqualTo("userId", id),
            db.collection("stories").whereEqualTo("userId", id), user(id).collection("highlights"))
        collections.forEach { source ->
            while (true) {
                val page = source.whereEqualTo("audience", "public").limit(30).get(Source.SERVER).awaitSocial()
                if (page.isEmpty) break
                val batch = db.batch()
                page.documents.forEach { batch.update(it.reference, "audience", "followers") }
                batch.commit().awaitSocial()
            }
        }
        state(false, true)
    }

    fun listenRequested(target: String, result: (Boolean) -> Unit): ListenerRegistration = user(target).collection("followRequests").document(me())
        .addSnapshotListener { s, e -> if (e == null) result(s?.exists() == true) }

    suspend fun requestFollow(target: String, request: Boolean) {
        require(target != me())
        val ref = user(target).collection("followRequests").document(me())
        if (request) ref.set(mapOf("uid" to me(), "createdAt" to FieldValue.serverTimestamp())).awaitSocial()
        else ref.delete().awaitSocial()
    }
    fun listenRequests(result: (List<String>) -> Unit, error: (String) -> Unit): ListenerRegistration =
        user().collection("followRequests").orderBy("createdAt", Query.Direction.DESCENDING).limit(50).addSnapshotListener { s, e ->
            if (e != null) error("Requests couldn't load.") else result(s?.documents.orEmpty().map { it.id })
        }
    suspend fun reviewRequest(requester: String, accept: Boolean) {
        val target = me()
        val request = user(target).collection("followRequests").document(requester)
        db.runTransaction { tx ->
            if (!tx.get(request).exists()) return@runTransaction
            if (accept) {
                tx.set(user(target).collection("followers").document(requester), mapOf("uid" to requester, "createdAt" to FieldValue.serverTimestamp()))
                tx.set(user(requester).collection("following").document(target), mapOf("uid" to target, "createdAt" to FieldValue.serverTimestamp()))
            }
            tx.delete(request)
        }.awaitSocial()
    }
    fun listenConnections(target: String, followers: Boolean, result: (List<String>) -> Unit, error: (String) -> Unit): ListenerRegistration =
        user(target).collection(if (followers) "followers" else "following").orderBy("createdAt", Query.Direction.DESCENDING).limit(100).addSnapshotListener { s, e ->
            if (e != null) error("Connections couldn't load.") else result(s?.documents.orEmpty().map { it.id })
        }
    fun listenBlocked(result: (List<String>) -> Unit, error: (String) -> Unit): ListenerRegistration =
        user().collection("blockedUsers").addSnapshotListener { s, e ->
            if (e != null) error("Blocked accounts couldn't load.") else result(s?.documents.orEmpty().map { it.id })
        }
    suspend fun unblock(id: String) = user().collection("blockedUsers").document(id).delete().awaitSocial()
    fun listenSaved(result: (List<String>) -> Unit, error: (String) -> Unit): ListenerRegistration =
        user().collection("savedPosts").orderBy("createdAt", Query.Direction.DESCENDING).limit(50).addSnapshotListener { s, e ->
            if (e != null) error("Saved posts couldn't load.") else result(s?.documents.orEmpty().map { it.id })
        }
}
