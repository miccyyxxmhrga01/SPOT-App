package com.example.spotapp.ui.theme.screens.post

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.spotapp.data.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay

internal enum class PostSheet { CATEGORY, TAGS, PEOPLE, LOCATION, VISIBILITY, OPTIONS }
private class SheetCloseAction { var flush: () -> Boolean = { true } }

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
internal fun PostDetailsSheet(sheet: PostSheet, uid: String, draft: PostDraft, update: (PostDraft) -> Unit, close: () -> Unit) {
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val closeAction = remember { SheetCloseAction() }
    val finish = { if (closeAction.flush()) close() }
    ModalBottomSheet(onDismissRequest = finish, sheetState = state, containerColor = PostIvory) {
        Column(Modifier.fillMaxWidth().imePadding().padding(horizontal = 20.dp).padding(bottom = 16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Text(when (sheet) { PostSheet.CATEGORY -> "Talent categories"; PostSheet.TAGS -> "Hashtags"; PostSheet.PEOPLE -> "Mention people"; PostSheet.LOCATION -> "Location"; PostSheet.VISIBILITY -> "Who can view this post?"; PostSheet.OPTIONS -> "More options" }, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                TextButton(onClick = finish) { Text("Done", color = PostGold) }
            }
            when (sheet) {
                PostSheet.CATEGORY -> Column(Modifier.heightIn(max = 430.dp).verticalScroll(rememberScrollState())) {
                    Text("${draft.categories.size} / 8 selected", style = MaterialTheme.typography.bodySmall, color = PostMuted)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        (SpotTalentCategories + draft.categories).distinct().forEach { category ->
                            FilterChip(category in draft.categories, onClick = { update(draft.copy(categories = if (category in draft.categories) draft.categories - category else (draft.categories + category).take(8))) },
                                label = { Text(category) }, enabled = category in draft.categories || draft.categories.size < 8,
                                colors = FilterChipDefaults.filterChipColors(containerColor = Color.White, selectedContainerColor = Color(0xFFFAF2DF), selectedLabelColor = PostGold), border = BorderStroke(1.dp, PostLine))
                        }
                    }
                }
                PostSheet.TAGS -> TagsEditor(draft.tags, closeAction) { update(draft.copy(tags = it)) }
                PostSheet.PEOPLE -> PeopleEditor(uid, draft.taggedPeople) { update(draft.copy(taggedPeople = it)) }
                PostSheet.LOCATION -> OutlinedTextField(draft.location, { update(draft.copy(location = it.take(160))) }, Modifier.fillMaxWidth().testTag("post-location"),
                    placeholder = { Text("Add a place · optional") }, singleLine = true, shape = RoundedCornerShape(14.dp), leadingIcon = { Icon(Icons.Default.LocationOn, null) })
                PostSheet.VISIBILITY -> listOf("public" to "Anyone on SPOT", "followers" to "Your followers", "private" to "Only you").forEach { (value, description) ->
                    Row(Modifier.fillMaxWidth().clickable { update(draft.copy(audience = value)) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(draft.audience == value, { update(draft.copy(audience = value)) }, colors = RadioButtonDefaults.colors(selectedColor = PostGold))
                        Column { Text(audienceLabel(value), style = MaterialTheme.typography.bodyMedium); Text(description, style = MaterialTheme.typography.bodySmall, color = PostMuted) }
                    }
                }
                PostSheet.OPTIONS -> FutureAiControls()
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun TagsEditor(tags: List<String>, closeAction: SheetCloseAction, update: (List<String>) -> Unit) {
    var input by rememberSaveable { mutableStateOf("") }
    var editing by rememberSaveable { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf("") }
    fun addTag(): Boolean {
        if (input.isBlank()) return true
        val clean = input.trim().removePrefix("#").replace(Regex("\\s+"), "")
        if (clean.isBlank() || clean.length > 60 || (tags.size >= 20 && editing == null)) {
            error = "Use up to 20 tags, each under 60 characters."; return false
        }
        update((tags.filterNot { it == editing } + clean).distinctBy { it.lowercase() })
        input = ""; editing = null; error = ""; return true
    }
    SideEffect { closeAction.flush = ::addTag }
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it.take(61); error = "" }, Modifier.weight(1f).testTag("post-tag-input"), label = { Text(if (editing == null) "Add a tag" else "Edit tag") }, prefix = { Text("#") }, singleLine = true, shape = RoundedCornerShape(14.dp))
            IconButton(onClick = { addTag() }, enabled = input.isNotBlank()) { Icon(Icons.Default.Check, "Add tag", tint = PostGold) }
        }
        PostError(error)
        FlowRow(Modifier.heightIn(max = 240.dp).verticalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            tags.forEach { tag -> InputChip(editing == tag, { input = tag; editing = tag }, label = { Text("#$tag") }, trailingIcon = {
                IconButton(onClick = { update(tags - tag); if (editing == tag) { input = ""; editing = null } }, Modifier.size(28.dp)) { Icon(Icons.Default.Close, "Remove $tag", Modifier.size(14.dp)) }
            }, colors = InputChipDefaults.inputChipColors(selectedContainerColor = Color(0xFFFAF2DF)), border = BorderStroke(1.dp, PostLine)) }
        }
        Text("${tags.size} / 20 tags", style = MaterialTheme.typography.bodySmall, color = PostMuted, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun PeopleEditor(uid: String, selected: List<String>, update: (List<String>) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var people by remember { mutableStateOf(emptyList<ChatPerson>()) }
    var error by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    val directory = remember(uid) { FirebaseMessagesStore(uid) }
    LaunchedEffect(query) {
        loading = true; error = ""; delay(250)
        try { people = directory.people(query) }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { error = "People couldn't load. Try another search." }
        finally { loading = false }
    }
    OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search name or username") }, singleLine = true, shape = RoundedCornerShape(14.dp))
    if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = PostGold)
    PostError(error)
    LazyColumn(Modifier.heightIn(max = 300.dp)) {
        if (!loading && people.isEmpty() && error.isBlank()) item { Text("No people found", Modifier.padding(vertical = 20.dp), style = MaterialTheme.typography.bodySmall, color = PostMuted) }
        items(people, key = { it.uid }) { person ->
            Row(Modifier.fillMaxWidth().clickable(enabled = person.uid in selected || selected.size < 20) { update(if (person.uid in selected) selected - person.uid else selected + person.uid) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(person.uid in selected, { checked -> if (!checked || selected.size < 20) update(if (checked) (selected + person.uid).distinct() else selected - person.uid) }, colors = CheckboxDefaults.colors(checkedColor = PostGold))
                Column { Text(person.name, style = MaterialTheme.typography.bodyMedium); Text("@${person.username}", style = MaterialTheme.typography.bodySmall, color = PostMuted) }
            }
        }
    }
    TextButton(onClick = { update(emptyList()) }, enabled = selected.isNotEmpty()) { Text("Clear mentions · ${selected.size}/20", color = PostGold) }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun FutureAiControls() {
    Surface(color = Color(0xFFF5F1E8), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().testTag("future-ai")) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.AutoAwesome, null, Modifier.size(18.dp), tint = PostGold); Spacer(Modifier.width(8.dp)); Text("AI Assist", style = MaterialTheme.typography.titleSmall) }
            Text("Category suggestions from SPOT AI are under Talent category. Captions and tags aren't available yet.", style = MaterialTheme.typography.bodySmall, color = PostMuted)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Generate Caption", "Suggest Tags").forEach { label ->
                    OutlinedButton(onClick = {}, enabled = false, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) { Text(label, style = MaterialTheme.typography.labelSmall) }
                }
            }
        }
    }
}
