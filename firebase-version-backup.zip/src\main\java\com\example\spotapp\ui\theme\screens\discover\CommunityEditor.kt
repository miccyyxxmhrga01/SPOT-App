package com.example.spotapp.ui.theme.screens.discover

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.spotapp.data.*
import com.example.spotapp.ui.theme.models.SpotUiProfile
import kotlinx.coroutines.*
import java.util.Calendar
import java.util.UUID

@Composable
internal fun CommunityEditor(isEvent: Boolean, profile: SpotUiProfile, close: () -> Unit, created: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    val id = rememberSaveable { UUID.randomUUID().toString() }
    var name by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var image by rememberSaveable { mutableStateOf("") }
    var category by rememberSaveable { mutableStateOf("") }
    var privacy by rememberSaveable { mutableStateOf("public") }
    var location by rememberSaveable { mutableStateOf("") }
    var organizer by rememberSaveable { mutableStateOf(profile.organization.ifBlank { profile.displayName }) }
    var limit by rememberSaveable { mutableStateOf("") }
    var startsAt by rememberSaveable { mutableLongStateOf(Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 18); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var error by remember { mutableStateOf("") }
    var discard by remember { mutableStateOf(false) }
    fun back() { if (name.isNotBlank() || description.isNotBlank() || image.isNotBlank()) discard = true else close() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) { runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }; image = uri.toString() }
    }
    CommunityWindow(if (isEvent) "Create event" else "Create group", ::back, busy) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).navigationBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(Modifier.animateContentSize()) {
                CommunityCover(image, isEvent, Modifier.fillMaxWidth().height(if (image.isBlank()) 130.dp else 200.dp).clip(RoundedCornerShape(20.dp)))
                Row {
                    TextButton(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }, enabled = !busy) { Icon(Icons.Default.AddPhotoAlternate, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(if (image.isBlank()) "Add ${if (isEvent) "poster" else "cover"} · optional" else "Change image") }
                    if (image.isNotBlank()) TextButton(onClick = { image = "" }, enabled = !busy) { Text("Remove") }
                }
            }
            OutlinedTextField(name, { name = it.take(if (isEvent) 100 else 80) }, Modifier.fillMaxWidth(), label = { Text(if (isEvent) "Event title" else "Group name") }, enabled = !busy, singleLine = true, shape = RoundedCornerShape(16.dp))
            OutlinedTextField(description, { description = it.take(if (isEvent) 3000 else 2000) }, Modifier.fillMaxWidth(), label = { Text("Description") }, minLines = 3, maxLines = 6, enabled = !busy, shape = RoundedCornerShape(16.dp))
            Text(if (isEvent) "Talent needed" else "Talent category", style = MaterialTheme.typography.titleSmall)
            CommunityCategories(category, { if (!busy) category = it })
            if (isEvent) {
                OutlinedButton(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = startsAt }
                    DatePickerDialog(context, { _, y, m, d -> startsAt = Calendar.getInstance().apply { timeInMillis = startsAt; set(y, m, d) }.timeInMillis }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
                        .apply { datePicker.minDate = System.currentTimeMillis(); show() }
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.CalendarMonth, null); Spacer(Modifier.width(8.dp)); Text(eventDate(startsAt, "EEEE, MMM d, yyyy")) }
                OutlinedButton(onClick = {
                    val c = Calendar.getInstance().apply { timeInMillis = startsAt }
                    TimePickerDialog(context, { _, h, m -> startsAt = Calendar.getInstance().apply { timeInMillis = startsAt; set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, m) }.timeInMillis }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
                }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Schedule, null); Spacer(Modifier.width(8.dp)); Text(eventDate(startsAt, "h:mm a z")) }
                OutlinedTextField(location, { location = it.take(160) }, Modifier.fillMaxWidth(), label = { Text("Location") }, singleLine = true, enabled = !busy, shape = RoundedCornerShape(16.dp))
                OutlinedTextField(organizer, { organizer = it.take(100) }, Modifier.fillMaxWidth(), label = { Text("Organizer") }, singleLine = true, enabled = !busy, shape = RoundedCornerShape(16.dp))
                OutlinedTextField(limit, { if (it.all(Char::isDigit)) limit = it.take(6) }, Modifier.fillMaxWidth(), label = { Text("Participant limit · optional") },
                    supportingText = { Text("Leave empty for unlimited places. Joining reserves one place.") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true, enabled = !busy, shape = RoundedCornerShape(16.dp))
            } else {
                Text("Group privacy", style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("public", "private").forEach { value -> FilterChip(privacy == value, { privacy = value }, label = { Text(value.replaceFirstChar { it.uppercase() }) }, enabled = !busy, colors = communityChipColors(), border = androidx.compose.foundation.BorderStroke(1.dp, CommunityLine)) } }
                Text(if (privacy == "public") "Anyone on SPOT can join and see the member list." else "People can discover your group and request to join. You approve requests; only members see the member list.", style = MaterialTheme.typography.bodySmall)
            }
            CommunityError(error)
            if (busy) { LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth(), color = CommunityGold); Text(if (progress < .9f) "Uploading image · ${(progress * 100).toInt()}%" else "Saving…", style = MaterialTheme.typography.bodySmall) }
            Button(onClick = {
                if (!busy) {
                    val g = GroupDraft(id, name, description, image, category, privacy)
                    val e = EventDraft(id, name, description, image, category, startsAt, location, organizer, limit.toLongOrNull())
                    val issue = if (isEvent) e.error() else g.error()
                    if (issue != null) error = issue else {
                        focus.clearFocus(); busy = true; error = ""; progress = 0f
                        scope.launch {
                            try {
                                val savedId = withTimeout(180_000) {
                                    if (isEvent) DiscoverRepository.shared.createEvent(context.applicationContext, e) { progress = it }
                                    else DiscoverRepository.shared.createGroup(context.applicationContext, g) { progress = it }
                                }
                                created(savedId)
                            } catch (_: TimeoutCancellationException) { error = "Saving took too long. Please retry; the same draft won't be created twice." }
                            catch (e: CancellationException) { throw e }
                            catch (e: Exception) { error = if (e is IllegalStateException || e is IllegalArgumentException) e.message.orEmpty() else "Couldn't save. Check your connection and retry." }
                            finally { busy = false }
                        }
                    }
                }
            }, enabled = !busy, colors = ButtonDefaults.buttonColors(containerColor = CommunityGold), modifier = Modifier.fillMaxWidth()) { Text(if (isEvent) "Publish event" else "Create group") }
            Spacer(Modifier.height(12.dp))
        }
    }
    if (discard) AlertDialog(onDismissRequest = { discard = false }, title = { Text("Discard this ${if (isEvent) "event" else "group"}?") }, text = { Text("Your unsaved changes will be lost.") },
        confirmButton = { TextButton(onClick = close) { Text("Discard") } }, dismissButton = { TextButton(onClick = { discard = false }) { Text("Keep editing") } })
}
