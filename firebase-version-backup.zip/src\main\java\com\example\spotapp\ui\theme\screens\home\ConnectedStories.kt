package com.example.spotapp.ui.theme.screens.home

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import coil3.compose.AsyncImage
import com.example.spotapp.data.*
import com.example.spotapp.ui.theme.components.*
import com.example.spotapp.ui.theme.models.SpotUiProfile
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import java.util.UUID

@Composable
internal fun ConnectedStories(profile: SpotUiProfile, onOverlay: (Boolean) -> Unit, onProfile: (SpotUiProfile) -> Unit) {
    val repo = remember { StoryRepository.shared }
    var own by remember(profile.uid) { mutableStateOf(emptyList<StoryItem>()) }
    var public by remember(profile.uid) { mutableStateOf(emptyList<StoryItem>()) }
    var followed by remember(profile.uid) { mutableStateOf(emptyList<String>()) }
    val connections = remember(profile.uid) { mutableStateMapOf<String, List<StoryItem>>() }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var retry by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<String?>(null) }
    var creating by remember { mutableStateOf(false) }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var seen by rememberSaveable(profile.uid) { mutableStateOf(emptyList<String>()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }
    LifecycleDisposableEffect(profile.uid, retry) {
        loading = own.isEmpty(); error = ""
        val a = repo.listenStories(profile.uid, { own = it; loading = false }, { error = it; loading = false })
        val b = repo.listenStories(result = { public = it }, error = { error = it })
        val c = PrivacyRepository.shared.listenConnections(profile.uid, false, { followed = it.take(30) }, { error = it })
        onDispose { a.remove(); b.remove(); c.remove() }
    }
    LifecycleDisposableEffect(followed, retry) {
        connections.keys.toList().filterNot { it in followed }.forEach { connections.remove(it) }
        val registrations = followed.map { uid -> repo.listenStories(uid, { connections[uid] = it }, { connections.remove(uid) }) }
        onDispose { registrations.forEach { it.remove() } }
    }
    val all = (own + public + connections.values.flatten()).distinctBy { it.id }.filter { it.active(now) }
    val owners = all.groupBy { it.userId }
    val opened = owners[selected].orEmpty().sortedBy { it.createdAt }
    SideEffect { onOverlay(creating || selected != null) }
    DisposableEffect(Unit) { onDispose { onOverlay(false) } }
    Column {
        LazyRow(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                StoryCircle(profile.uid, profile.profileImageUrl, "Your Story", owners[profile.uid].orEmpty().any { it.id !in seen }, true,
                    { if (!loading) { if (owners[profile.uid].isNullOrEmpty()) creating = true else selected = profile.uid } }, { creating = true })
            }
            items(owners.keys.filter { it != profile.uid }, key = { it }) { uid ->
                val items = owners.getValue(uid)
                StoryCircle(uid, items.first().profileImageUrl, items.first().username.ifBlank { "Story" }, items.any { it.id !in seen }, false, { selected = uid }, {})
            }
        }
        if (loading) SpotLoading(true, SkeletonKind.STORIES)
        if (error.isNotBlank()) TextButton({ retry++ }) { Text("Stories unavailable · Retry", style = MaterialTheme.typography.labelSmall) }
    }
    if (creating) StoryCreator(profile, { creating = false }, { moment ->
        own = (own + moment).distinctBy { it.id }
        creating = false; selected = profile.uid
    })
    if (selected != null && opened.isNotEmpty()) StoryViewer(opened, profile.uid, close = { selected = null },
        onSeen = { seen = (seen + it).distinct().takeLast(300) }, onProfile = { uid -> selected = null; onProfile(SpotUiProfile(uid, "", "", "", "")) },
        onDelete = { repo.removeStory(it) })
    else if (selected != null && !creating) LaunchedEffect(selected, opened) { selected = null }
}

@Composable
private fun StoryCircle(uid: String, photo: String, label: String, unseen: Boolean, own: Boolean, open: () -> Unit, add: () -> Unit) {
    Column(Modifier.width(if (own) 88.dp else 72.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(58.dp)) {
            SpotAvatar(photo, label, Modifier.fillMaxSize().border(if (unseen) 2.dp else 1.dp,
                if (unseen) Color(0xFFE8B84B) else Color(0xFFE5E5E5), CircleShape).padding(4.dp).clickable(onClick = open), uid)
            if (own) IconButton(add, Modifier.align(Alignment.BottomEnd).offset(8.dp, 8.dp).size(32.dp).testTag("add-story")) {
                Icon(Icons.Default.AddCircle, "Add story", Modifier.size(22.dp).background(Color.White, CircleShape), tint = Color(0xFFAD8420))
            }
        }
        Spacer(Modifier.height(6.dp)); Text(label, style = MaterialTheme.typography.labelSmall, maxLines = 1, softWrap = false, overflow = TextOverflow.Ellipsis)
    }
}

