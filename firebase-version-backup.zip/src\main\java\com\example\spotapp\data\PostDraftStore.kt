package com.example.spotapp.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** One private local draft per account. Media uses persisted Photo Picker URI grants. */
class PostDraftStore(context: Context, uid: String) {
    private val prefs = context.getSharedPreferences("post_draft_$uid", Context.MODE_PRIVATE)
    fun load(): PostDraft? = prefs.getString("draft", null)?.let(PostDraftCodec::decode)
    fun save(draft: PostDraft) {
        check(prefs.edit().putString("draft", PostDraftCodec.encode(draft)).commit()) { "Your draft couldn't be saved. Please retry." }
    }
    fun clear() { prefs.edit().remove("draft").apply() }
}

/** Shared by persistent drafts and Compose's saved-state restoration. */
object PostDraftCodec {
    fun decode(value: String): PostDraft? = runCatching {
        val j = JSONObject(value)
        fun strings(key: String): List<String> = j.optJSONArray(key)?.let { a -> (0 until a.length()).map { a.getString(it) } }.orEmpty()
        val edits = j.optJSONObject("mediaEdits")
        val instructions = edits?.keys()?.asSequence()?.associateWith { uri ->
            val e = edits.getJSONObject(uri)
            PostMediaEdit(e.optInt("quarterTurns"), e.optString("crop", "original"), e.optBoolean("muted", false))
        }.orEmpty()
        PostDraft(j.getString("id"), j.optString("caption"), strings("categories"), strings("tags"), strings("mediaUris"),
            j.optString("audience", "followers"), j.optString("location"), strings("taggedPeople"),
            j.optBoolean("aiCaption", false), j.optBoolean("aiTagged", false), j.optBoolean("aiCategorySuggested", false), instructions)
    }.getOrNull()
    fun encode(draft: PostDraft): String {
        val edits = JSONObject()
        draft.mediaEdits.forEach { (uri, edit) -> edits.put(uri, JSONObject().put("quarterTurns", edit.rotation).put("crop", edit.crop).put("muted", edit.muted)) }
        val j = JSONObject().put("id", draft.id).put("caption", draft.caption).put("categories", JSONArray(draft.categories))
            .put("tags", JSONArray(draft.tags)).put("mediaUris", JSONArray(draft.mediaUris)).put("audience", draft.audience)
            .put("location", draft.location).put("taggedPeople", JSONArray(draft.taggedPeople))
            .put("mediaEdits", edits).put("aiCaption", draft.aiCaption).put("aiTagged", draft.aiTagged).put("aiCategorySuggested", draft.aiCategorySuggested)
        return j.toString()
    }
}
