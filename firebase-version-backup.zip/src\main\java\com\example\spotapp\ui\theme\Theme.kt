package com.example.spotapp.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// The SPOT interface is designed as a light white/gold theme. Keeping this
// self-contained prevents the theme from becoming unresolved when template
// Color.kt or Type.kt files are moved or renamed.
private val SpotLightColorScheme = lightColorScheme(
    primary = Color(0xFFD4AF37),
    onPrimary = Color(0xFF171717),
    secondary = Color(0xFFB58E22),
    onSecondary = Color.White,
    background = Color(0xFFF8F8F8),
    onBackground = Color(0xFF171717),
    surface = Color.White,
    onSurface = Color(0xFF171717),
    error = Color(0xFFD84A4A),
    onError = Color.White
)

@Composable
fun SPOTAppTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = SpotLightColorScheme,
        typography = Typography,
        content = { com.example.spotapp.ui.theme.components.ProvideSpotAmbientMotion(content) }
    )
}
