package com.example.spotapp.ui.theme.models

import com.example.spotapp.R
object SpotMockData {

    val fallbackCurrentUser = SpotUiProfile(
        uid = "frontend-current-user",
        displayName = "Your Name",
        username = "username",
        talent = "Talent",
        course = "Course"
    )

    val mika = SpotUiProfile(
        uid = "mika",
        displayName = "Mika Suarez",
        username = "mikasuarez",
        talent = "Dancer",
        course = "Bachelor of Science in Computer Science"
    )

    val john = SpotUiProfile(
        uid = "john",
        displayName = "John Michael Pastoril",
        username = "johnpastoril",
        talent = "Guitarist",
        course = "Bachelor of Science in Information Technology"
    )

    val deandra = SpotUiProfile(
        uid = "deandra",
        displayName = "Deandra Pasquin",
        username = "deandrapasquin",
        talent = "Dancer",
        course = "Bachelor of Science in Computer Science"
    )

    val jay = SpotUiProfile(
        uid = "jay",
        displayName = "Jay",
        username = "jay",
        talent = "Drummer",
        course = "Bachelor of Science in Information Technology"
    )

    val searchableProfiles = listOf(
        mika,
        john,
        deandra,
        jay
    )

    fun homePostFor(
        user: SpotUiProfile
    ): SpotUiPost {

        return SpotUiPost(
            id = "home-sample",
            user = user,

            caption = "A new talent moment I’ve been working on this week. Still improving it, but I’m happy with the progress so far.",

            category = user.talent.ifBlank {
                "Talent"
            },

            tags = listOf(
                "SPOT",
                "CampusTalent"
            ),
            postedTime = "1 min ago",

            localImageResources = listOf(
                R.drawable.image1,
                R.drawable.image2,
                R.drawable.image3
            ),

            likes = 2000,
            comments = 1000,
            shares = 100,

            aiCaption = true,
            aiTagged = true
        )
    }

    val discoverPost = SpotUiPost(
        id = "discover-sample",
        user = deandra,

        caption = "A new dance routine I’ve been working on this week. Trying something different with this one.",

        category = "Dance",

        tags = listOf(
            "Hiphop",
            "Freestyle"
        ),
        postedTime = "5 min ago",

        localVideoRes = R.raw.dance,

        likes = 2000,
        comments = 1000,
        shares = 100,

        aiCaption = true,
        aiTagged = true
    )
    val notifications = listOf(
        SpotUiNotification(
            id = "n1",
            actorName = "John Michael Pastoril",
            text = "started following you.",
            section = "Today",
            read = false
        ),
        SpotUiNotification(
            id = "n2",
            actorName = "Mika Suarez",
            text = "liked your post.",
            section = "Earlier",
            read = false
        ),
        SpotUiNotification(
            id = "n3",
            actorName = "Deandra Pasquin",
            text = "commented on your post.",
            section = "Earlier",
            read = true
        ),
        SpotUiNotification(
            id = "n4",
            actorName = "John Michael Pastoril",
            text = "started following you.",
            section = "Earlier",
            read = false
        ),
        SpotUiNotification(
            id = "n5",
            actorName = "Mika Suarez",
            text = "shared your post.",
            section = "Earlier",
            read = true
        ),
        SpotUiNotification(
            id = "n6",
            actorName = "Jay",
            text = "mentioned you in a comment.",
            section = "Earlier",
            read = false
        )
    )

    val conversations = listOf(
        SpotUiConversation(
            id = "c1",
            name = "Mika Suarez",
            preview = "Loved your last post 🎤",
            time = "1hr"
        ),
        SpotUiConversation(
            id = "c2",
            name = "John Michael Pastoril",
            preview = "Hey! Saw you need a guitarist for...",
            time = "2hrs"
        ),
        SpotUiConversation(
            id = "c3",
            name = "Deandra Pasquin",
            preview = "That dance was amazing!",
            time = "3hrs"
        )
    )

    val groups = listOf(
        SpotUiGroup(
            id = "g1",
            name = "Dance Club Officers",
            preview = "Practice moved to Friday 6pm",
            time = "1hr"
        ),
        SpotUiGroup(
            id = "g2",
            name = "Singers Club",
            preview = "Practice moved to Friday 6pm",
            time = "2hrs"
        ),
        SpotUiGroup(
            id = "g3",
            name = "Campus Creatives",
            preview = "New project ideas are posted.",
            time = "4hrs"
        )
    )

    val collabRequests = listOf(
        SpotUiCollabRequest(
            id = "r1",
            name = "John Michael Pastoril",
            request = "Hey! Saw you need a guitarist for...",
            time = "2hrs"
        ),
        SpotUiCollabRequest(
            id = "r2",
            name = "Jay",
            request = "Hey! Saw you need a drummer for...",
            time = "2hrs"
        ),
        SpotUiCollabRequest(
            id = "r3",
            name = "Mika Suarez",
            request = "Want to collaborate on a campus reel?",
            time = "3hrs"
        )
    )

    val events = listOf(
        SpotUiEvent(
            id = "e1",
            title = "Campus Talent Night",
            subtitle = "Friday · 6:00 PM · University Gym"
        ),
        SpotUiEvent(
            id = "e2",
            title = "Acoustic Open Mic",
            subtitle = "Saturday · 4:00 PM · Student Center"
        )
    )
}