package com.example.spotapp.ui.theme.screens.onboarding

import com.example.spotapp.ui.theme.spotSp

import androidx.annotation.DrawableRes

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import com.example.spotapp.ui.theme.components.spotAmbientBackground
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn

import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star

import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

import androidx.compose.ui.layout.ContentScale

import androidx.compose.ui.res.painterResource

import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign

import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import com.example.spotapp.R
import com.example.spotapp.ui.theme.InterFontFamily

import kotlinx.coroutines.launch


// ---------- Colors ----------

private val OnboardingWhite =
    Color.White

private val OnboardingBlack =
    Color(0xFF111111)

private val OnboardingSecondary =
    Color(0xFF707070)

private val OnboardingMuted =
    Color(0xFFA1A1A1)

private val OnboardingLine =
    Color(0xFFE8E8E8)

private val OnboardingGold =
    Color(0xFFFDD87A)

private val OnboardingGoldDeep =
    Color(0xFFE8B84B)

private val OnboardingAmber =
    Color(0xFF8A5C10)

private val OnboardingSoftGold =
    Color(0xFFFFF6DA)

private val OnboardingCanvas =
    Color(0xFFFFFCF6)


private val OnboardingButtonGradient =
    Brush.horizontalGradient(
        colors =
            listOf(
                OnboardingGold,
                Color(0xFFF3C85B)
            )
    )


// ---------- Data ----------

data class OnboardingPage(
    val title: String,
    val description: String,

    @DrawableRes
    val imageRes: Int,

    val imageDescription: String,
    val badge: String,
    val icon: ImageVector
)


private val onboardingPages =
    listOf(

        OnboardingPage(
            title =
                "Showcase your talent",

            description =
                "Share your performances, artwork, photography, coding projects, and other skills with your campus community.",

            imageRes =
                R.drawable.onboarding_showcase,

            imageDescription =
                "Student showcasing a talent",

            badge =
                "Show what you can do",

            icon =
                Icons.Filled.Star
        ),


        OnboardingPage(
            title =
                "Get discovered",

            description =
                "Post your best moments and let the right students discover your talent across the SPOT community.",

            imageRes =
                R.drawable.onboarding_discover,

            imageDescription =
                "Student being discovered through SPOT",

            badge =
                "Find your audience",

            icon =
                Icons.Filled.Search
        ),


        OnboardingPage(
            title =
                "Connect and grow",

            description =
                "Follow talented students, collaborate, receive feedback, and grow your campus network.",

            imageRes =
                R.drawable.onboarding_connect,

            imageDescription =
                "Students connecting through SPOT",

            badge =
                "Create together",

            icon =
                Icons.Filled.Groups
        )
    )


// ---------- Screen ----------

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun OnboardingScreen(
    onFinished: () -> Unit
) {

    val pagerState =
        rememberPagerState(
            pageCount = {
                onboardingPages.size
            }
        )


    val coroutineScope =
        rememberCoroutineScope()


    val currentPage =
        pagerState.currentPage


    val isLastPage =
        currentPage ==
                onboardingPages.lastIndex


    Column(
        modifier =
            Modifier
                .fillMaxSize()
                .spotAmbientBackground(
                    OnboardingCanvas
                )
    ) {

        OnboardingTopBar(
            currentPage =
                currentPage,

            pageCount =
                onboardingPages.size,

            isLastPage =
                isLastPage,

            onSkipClick =
                onFinished
        )


        HorizontalPager(
            state =
                pagerState,

            modifier =
                Modifier
                    .fillMaxWidth()
                    .weight(1f),

            contentPadding =
                PaddingValues(
                    horizontal = 18.dp
                ),

            pageSpacing =
                12.dp
        ) { page ->

            val selected =
                currentPage == page


            val scale by
            animateFloatAsState(
                targetValue =
                    if (selected) {
                        1f
                    } else {
                        0.96f
                    },

                animationSpec =
                    tween(
                        durationMillis = 230
                    ),

                label =
                    "onboarding_page_scale"
            )


            val alpha by
            animateFloatAsState(
                targetValue =
                    if (selected) {
                        1f
                    } else {
                        0.62f
                    },

                animationSpec =
                    tween(
                        durationMillis = 200
                    ),

                label =
                    "onboarding_page_alpha"
            )


            OnboardingPageContent(
                page =
                    onboardingPages[page],

                modifier =
                    Modifier
                        .scale(scale)
                        .alpha(alpha)
            )
        }


        OnboardingBottomSection(
            currentPage =
                currentPage,

            pageCount =
                onboardingPages.size,

            isLastPage =
                isLastPage,

            onButtonClick = {

                if (isLastPage) {

                    onFinished()

                } else {

                    coroutineScope.launch {

                        pagerState.animateScrollToPage(
                            page =
                                currentPage + 1,

                            animationSpec =
                                tween(
                                    durationMillis = 320
                                )
                        )
                    }
                }
            }
        )
    }
}


// ---------- Top Bar ----------

@Composable
private fun OnboardingTopBar(
    currentPage: Int,
    pageCount: Int,
    isLastPage: Boolean,
    onSkipClick: () -> Unit
) {

    Row(
        modifier =
            Modifier
                .fillMaxWidth()

                // Only top bar receives status bar spacing.
                .statusBarsPadding()

                .height(
                    54.dp
                )
                .padding(
                    start = 16.dp,
                    end = 14.dp
                ),

        verticalAlignment =
            Alignment.CenterVertically
    ) {

        Image(
            painter =
                painterResource(
                    id =
                        R.drawable.spotlogo
                ),

            contentDescription =
                "SPOT logo",

            contentScale =
                ContentScale.Fit,

            modifier =
                Modifier.size(
                    32.dp
                )
        )


        Spacer(
            modifier =
                Modifier.width(
                    8.dp
                )
        )


        Column(
            modifier =
                Modifier.weight(
                    1f
                )
        ) {

            Text(
                text =
                    "SPOT",

                color =
                    OnboardingBlack,

                fontFamily =
                    InterFontFamily,

                fontSize =
                    13.spotSp,

                fontWeight =
                    FontWeight.Bold,

                letterSpacing =
                    0.8.sp
            )


            Text(
                text =
                    "${currentPage + 1} of $pageCount",

                color =
                    OnboardingMuted,

                fontFamily =
                    InterFontFamily,

                fontSize =
                    7.5.spotSp,

                fontWeight =
                    FontWeight.Medium
            )
        }


        if (!isLastPage) {

            Surface(
                shape =
                    RoundedCornerShape(
                        50
                    ),

                color =
                    OnboardingWhite,

                border =
                    BorderStroke(
                        width =
                            1.dp,

                        color =
                            OnboardingLine
                    ),

                modifier =
                    Modifier.clickable(
                        onClick =
                            onSkipClick
                    )
            ) {

                Text(
                    text =
                        "Skip",

                    color =
                        OnboardingSecondary,

                    fontFamily =
                        InterFontFamily,

                    fontSize =
                        9.spotSp,

                    fontWeight =
                        FontWeight.SemiBold,

                    modifier =
                        Modifier.padding(
                            horizontal = 13.dp,
                            vertical = 7.dp
                        )
                )
            }

        } else {

            Spacer(
                modifier =
                    Modifier.width(
                        52.dp
                    )
            )
        }
    }
}


// ---------- Page ----------

@Composable
private fun OnboardingPageContent(
    page: OnboardingPage,
    modifier: Modifier = Modifier
) {

    Column(
        modifier =
            modifier
                .fillMaxSize()
                .padding(
                    horizontal = 2.dp
                ),

        horizontalAlignment =
            Alignment.CenterHorizontally
    ) {

        Spacer(
            modifier =
                Modifier.height(
                    12.dp
                )
        )


        OnboardingImageCard(
            imageRes =
                page.imageRes,

            imageDescription =
                page.imageDescription
        )


        Spacer(
            modifier =
                Modifier.height(
                    18.dp
                )
        )


        OnboardingBadge(
            icon =
                page.icon,

            text =
                page.badge
        )


        Spacer(
            modifier =
                Modifier.height(
                    13.dp
                )
        )


        Text(
            text =
                page.title,

            color =
                OnboardingBlack,

            fontFamily =
                InterFontFamily,

            fontSize =
                21.spotSp,

            fontWeight =
                FontWeight.Bold,

            lineHeight =
                26.sp,

            letterSpacing =
                (-0.35).sp,

            textAlign =
                TextAlign.Center
        )


        Spacer(
            modifier =
                Modifier.height(
                    8.dp
                )
        )


        Text(
            text =
                page.description,

            color =
                OnboardingSecondary,

            fontFamily =
                InterFontFamily,

            fontSize =
                10.spotSp,

            lineHeight =
                15.sp,

            textAlign =
                TextAlign.Center,

            modifier =
                Modifier
                    .widthIn(
                        max = 310.dp
                    )
                    .padding(
                        horizontal = 8.dp
                    )
        )
    }
}


// ---------- Illustration ----------

@Composable
private fun OnboardingImageCard(
    @DrawableRes
    imageRes: Int,

    imageDescription: String
) {

    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .height(
                    310.dp
                ),

        contentAlignment =
            Alignment.Center
    ) {

        Box(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .height(
                        280.dp
                    )
                    .clip(
                        RoundedCornerShape(
                            30.dp
                        )
                    )
                    .background(
                        brush =
                            Brush.verticalGradient(
                                colors =
                                    listOf(
                                        OnboardingSoftGold,
                                        OnboardingWhite
                                    )
                            )
                    )
                    .border(
                        width =
                            1.dp,

                        color =
                            OnboardingGold.copy(
                                alpha = 0.50f
                            ),

                        shape =
                            RoundedCornerShape(
                                30.dp
                            )
                    )
        )


        // Gold circle behind the artwork
        Box(
            modifier =
                Modifier
                    .size(
                        190.dp
                    )
                    .background(
                        color =
                            OnboardingGold.copy(
                                alpha = 0.14f
                            ),

                        shape =
                            CircleShape
                    )
        )


        Box(
            modifier =
                Modifier
                    .size(
                        135.dp
                    )
                    .background(
                        color =
                            OnboardingGold.copy(
                                alpha = 0.10f
                            ),

                        shape =
                            CircleShape
                    )
        )


        Image(
            painter =
                painterResource(
                    id =
                        imageRes
                ),

            contentDescription =
                imageDescription,

            contentScale =
                ContentScale.Fit,

            modifier =
                Modifier
                    .fillMaxSize()
                    .padding(
                        horizontal = 20.dp,
                        vertical = 15.dp
                    )
        )
    }
}


// ---------- Badge ----------

@Composable
private fun OnboardingBadge(
    icon: ImageVector,
    text: String
) {

    Surface(
        shape =
            RoundedCornerShape(
                50
            ),

        color =
            OnboardingSoftGold,

        border =
            BorderStroke(
                width =
                    1.dp,

                color =
                    OnboardingGold.copy(
                        alpha = 0.70f
                    )
            )
    ) {

        Row(
            modifier =
                Modifier.padding(
                    horizontal = 11.dp,
                    vertical = 6.dp
                ),

            verticalAlignment =
                Alignment.CenterVertically
        ) {

            Icon(
                imageVector =
                    icon,

                contentDescription =
                    null,

                tint =
                    OnboardingGoldDeep,

                modifier =
                    Modifier.size(
                        13.dp
                    )
            )


            Spacer(
                modifier =
                    Modifier.width(
                        5.dp
                    )
            )


            Text(
                text =
                    text,

                color =
                    OnboardingAmber,

                fontFamily =
                    InterFontFamily,

                fontSize =
                    8.spotSp,

                fontWeight =
                    FontWeight.SemiBold
            )
        }
    }
}


// ---------- Bottom ----------

@Composable
private fun OnboardingBottomSection(
    currentPage: Int,
    pageCount: Int,
    isLastPage: Boolean,
    onButtonClick: () -> Unit
) {

    Surface(
        modifier =
            Modifier.fillMaxWidth(),

        color =
            OnboardingWhite,

        shadowElevation =
            5.dp
    ) {

        Column(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .padding(
                        start = 18.dp,
                        end = 18.dp,
                        top = 12.dp,
                        bottom = 13.dp
                    ),

            horizontalAlignment =
                Alignment.CenterHorizontally
        ) {

            OnboardingPageIndicator(
                currentPage =
                    currentPage,

                pageCount =
                    pageCount
            )


            Spacer(
                modifier =
                    Modifier.height(
                        12.dp
                    )
            )


            OnboardingActionButton(
                text =
                    if (isLastPage) {

                        "Enter SPOT"

                    } else {

                        "Continue"
                    },

                onClick =
                    onButtonClick
            )
        }
    }
}


// ---------- Indicator ----------

@Composable
private fun OnboardingPageIndicator(
    currentPage: Int,
    pageCount: Int
) {

    Row(
        horizontalArrangement =
            Arrangement.Center,

        verticalAlignment =
            Alignment.CenterVertically
    ) {

        repeat(
            pageCount
        ) { index ->

            val selected =
                currentPage == index


            val indicatorWidth by
            animateDpAsState(
                targetValue =
                    if (selected) {

                        25.dp

                    } else {

                        7.dp
                    },

                animationSpec =
                    tween(
                        durationMillis = 200
                    ),

                label =
                    "onboarding_indicator_width"
            )


            val indicatorColor =
                if (selected) {

                    OnboardingGoldDeep

                } else {

                    OnboardingLine
                }


            Box(
                modifier =
                    Modifier
                        .padding(
                            horizontal = 3.dp
                        )
                        .width(
                            indicatorWidth
                        )
                        .height(
                            7.dp
                        )
                        .clip(
                            CircleShape
                        )
                        .background(
                            indicatorColor
                        )
            )
        }
    }
}


// ---------- Main Button ----------

@Composable
private fun OnboardingActionButton(
    text: String,
    onClick: () -> Unit
) {

    Box(
        modifier =
            Modifier
                .fillMaxWidth()
                .height(
                    48.dp
                )
                .clip(
                    RoundedCornerShape(
                        14.dp
                    )
                )
                .background(
                    OnboardingButtonGradient
                )
                .clickable(
                    onClick =
                        onClick
                ),

        contentAlignment =
            Alignment.Center
    ) {

        Row(
            verticalAlignment =
                Alignment.CenterVertically,

            horizontalArrangement =
                Arrangement.Center
        ) {

            Text(
                text =
                    text,

                color =
                    OnboardingBlack,

                fontFamily =
                    InterFontFamily,

                fontSize =
                    11.spotSp,

                fontWeight =
                    FontWeight.Bold
            )


            Spacer(
                modifier =
                    Modifier.width(
                        7.dp
                    )
            )


            Icon(
                imageVector =
                    Icons.AutoMirrored.Filled.ArrowForward,

                contentDescription =
                    null,

                tint =
                    OnboardingBlack,

                modifier =
                    Modifier.size(
                        17.dp
                    )
            )
        }
    }
}