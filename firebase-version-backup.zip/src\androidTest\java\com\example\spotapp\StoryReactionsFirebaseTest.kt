package com.example.spotapp

import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.platform.app.InstrumentationRegistry
import com.example.spotapp.data.*
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import java.util.UUID

class StoryReactionsFirebaseTest {
    @get:Rule val activity = ActivityScenarioRule(ComponentActivity::class.java)
    private data class Client(val app: FirebaseApp, val db: FirebaseFirestore, val auth: FirebaseAuth) { val stories = StoryRepository(db, auth) }
    private suspend fun connect(uid: String): Client {
        val app = FirebaseApp.initializeApp(InstrumentationRegistry.getInstrumentation().targetContext,
            FirebaseOptions.Builder().setProjectId("demo-spot-stories").setApplicationId("1:123456789:android:storytest").setApiKey("fake-emulator-key").build(), "stories-${UUID.randomUUID()}")
        val auth = FirebaseAuth.getInstance(app).apply { useEmulator("127.0.0.1", 9095) }
        val db = FirebaseFirestore.getInstance(app).apply { firestoreSettings = FirebaseFirestoreSettings.Builder().setLocalCacheSettings(MemoryCacheSettings.newBuilder().build()).build(); useEmulator("127.0.0.1", 8185) }
        auth.signInWithEmailAndPassword("$uid@example.test", "emulator-password-123").awaitSocial()
        return Client(app, db, auth)
    }
    @Test fun editedStoriesHighlightsAndHeartsPersistAcrossClients() = runBlocking<Unit> {
        activity.scenario.onActivity { it.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        withTimeout(90_000) {
            val owner = connect("sdk_owner"); val viewer = connect("sdk_viewer"); val clients = mutableListOf(owner, viewer)
            val id = "sdk-edit-${UUID.randomUUID()}"
            val url = "https://res.cloudinary.com/jcuzzxsz/image/upload/v1/spot/stories/sdk_owner/$id/photo.jpg"
            val edits = StoryComposition(scale = 1.5, offsetX = .1, overlays = listOf(StoryOverlay("title", "Campus talent", y = .3)))
            val liked = Channel<Boolean>(Channel.CONFLATED)
            try {
                owner.stories.createStory(id, url, false, "public", edits)
                owner.stories.createStory(id, url, false, "public", edits)
                val saved = owner.db.document("stories/$id").get(Source.SERVER).awaitSocial()
                assertEquals(edits, StoryComposition.from(saved.get("composition")))
                val listener = viewer.stories.listenLiked(id, { liked.trySend(it) }, { liked.close(IllegalStateException(it)) })
                try {
                    assertFalse(withTimeout(20_000) { liked.receive() })
                    viewer.stories.setLiked(id, true)
                    while (!withTimeout(20_000) { liked.receive() }) { }
                    viewer.stories.setLiked(id, true)
                    assertEquals(1L, owner.db.document("stories/$id").get(Source.SERVER).awaitSocial().getLong("likesCount"))
                    val restored = connect("sdk_viewer"); clients.add(restored)
                    assertTrue(restored.db.document("stories/$id/reactions/sdk_viewer").get(Source.SERVER).awaitSocial().getBoolean("liked") == true)
                    restored.stories.setLiked(id, false)
                    assertEquals(0L, owner.db.document("stories/$id").get(Source.SERVER).awaitSocial().getLong("likesCount"))
                } finally { listener.remove() }
                val source = owner.stories.highlightSources().single { it.sourceId == id }
                assertEquals(edits, source.composition)
                owner.stories.saveHighlight(id, "Campus", listOf(source), 0, "public")
                owner.stories.removeStory(id)
                assertEquals(edits, StoryComposition.from((owner.db.document("users/sdk_owner/highlights/$id").get(Source.SERVER).awaitSocial().get("media") as List<*>).let { (it.single() as Map<*, *>)["composition"] }))
            } finally { clients.forEach { it.db.terminate().awaitSocial(); it.app.delete() } }
        }
    }
}
