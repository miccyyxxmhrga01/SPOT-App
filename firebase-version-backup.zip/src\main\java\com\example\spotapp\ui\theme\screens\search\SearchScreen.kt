package com.example.spotapp

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.example.spotapp.data.*
import com.example.spotapp.ui.theme.components.*
import com.example.spotapp.ui.theme.models.SpotUiProfile
import kotlinx.coroutines.*

@Composable
fun SearchScreen(currentProfile: SpotUiProfile, onBack: () -> Unit, onProfileClick: (SpotUiProfile) -> Unit) {
    var query by rememberSaveable { mutableStateOf("") }
    var people by remember { mutableStateOf(emptyList<SpotUser>()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var retry by remember { mutableIntStateOf(0) }
    LaunchedEffect(currentProfile.uid, query, retry) {
        loading = true; error = ""
        try { delay(250); people = ProfileRepository.shared.search(query) }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { people = emptyList(); error = "Search couldn't load." }
        finally { loading = false }
    }
    Surface(Modifier.fillMaxSize().spotAmbientBackground(Color.White), color = Color.Transparent) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(end = 16.dp, top = 8.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", Modifier.size(22.dp)) }
                SpotSearchField(query, { query = it.take(100) }, Modifier.weight(1f), "Name or username", loading)
            }
            SpotLoading(loading, SkeletonKind.ROWS, Modifier.fillMaxWidth()) {
                if (error.isNotBlank()) TextButton({ retry++ }, Modifier.padding(16.dp)) { Text("$error Retry") }
                else if (people.isEmpty()) Text(if (query.isBlank()) "No profiles yet" else "No results", Modifier.padding(24.dp), style = MaterialTheme.typography.bodyMedium)
            }
            if (!loading && error.isBlank()) LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
                items(people, key = { it.uid }) { person ->
                    Row(Modifier.fillMaxWidth().animateItem().clickable { onProfileClick(person.asProfileUi()) }.padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        SpotAvatar(person.profileImageUrl, person.displayName, Modifier.size(42.dp), person.uid)
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(person.displayName, style = MaterialTheme.typography.titleSmall)
                            Text("@${person.username}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF707070))
                        }
                        if (person.isPrivate) Icon(Icons.Default.Lock, "Private account", Modifier.size(16.dp), tint = Color(0xFF707070))
                    }
                }
            }
        }
    }
}
