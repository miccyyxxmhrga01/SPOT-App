package com.example.spotapp.ui.theme.navigation

import com.example.spotapp.ui.theme.spotSp

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import com.example.spotapp.ui.theme.components.SpotGlassBackdrop
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.compose.AsyncImage
import com.example.spotapp.ui.theme.InterFontFamily
import com.example.spotapp.ui.theme.components.SpotMessageBubbleIcon
import com.example.spotapp.ui.theme.models.SpotRoute
import com.example.spotapp.ui.theme.models.SpotUiProfile

private val NavInk = Color(0xFF26251F)
private val NavMuted = Color(0xFF77756D)
val LocalSpotBottomNavigationSuppressed = staticCompositionLocalOf { false }

// 0f = fully expanded, 1f = fully compact. Changes every animation frame, so it uses
// compositionLocalOf (not staticCompositionLocalOf) to only recompose readers.
private val LocalSpotNavCompactFraction = compositionLocalOf { 0f }

private fun selectedTab(route: SpotRoute): Int = when (route) {
    SpotRoute.DISCOVER -> 1
    SpotRoute.MESSAGES_CHATS, SpotRoute.MESSAGES_GROUPS, SpotRoute.COLLAB_REQUESTS -> 2
    SpotRoute.NOTIFICATIONS -> 3
    SpotRoute.PROFILE -> 4
    else -> 0
}

@Composable
fun SpotMainBottomNavigation(
    selectedRoute: SpotRoute, profile: SpotUiProfile, onNavigate: (SpotRoute) -> Unit,
    visible: Boolean = true, hidden: Boolean = false, notificationCount: Int = 0, unreadMessagesCount: Int = 0
) {
    if (LocalSpotBottomNavigationSuppressed.current) return
    val selected = selectedTab(selectedRoute)
    // hidden -> fully removed (e.g. a chat thread is open and owns the bottom area).
    // visible (when not hidden) -> true = full size, false = compact pill (e.g. scrolling down).
    AnimatedVisibility(!hidden,
        enter = slideInVertically(spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn(tween(180)),
        exit = slideOutVertically(tween(180)) { it } + fadeOut(tween(140))) {
        GlassNavigation(compact = !visible, selected, 5) {
            NavigationItem("Home", selected == 0, { onNavigate(SpotRoute.HOME) }, Modifier.weight(1f)) { tint ->
                Icon(if (selected == 0) Icons.Filled.Home else Icons.Outlined.Home, null, Modifier.size(25.dp), tint)
            }
            NavigationItem("Discover", selected == 1, { onNavigate(SpotRoute.DISCOVER) }, Modifier.weight(1f)) { tint ->
                Icon(if (selected == 1) Icons.Filled.Explore else Icons.Outlined.Explore, null, Modifier.size(25.dp), tint)
            }
            NavigationItem("Messages", selected == 2, { onNavigate(SpotRoute.MESSAGES_CHATS) },
                Modifier.weight(1f), unreadMessagesCount) { tint -> SpotMessageBubbleIcon(Modifier.size(26.dp), tint) }
            NavigationItem("Notifications", selected == 3, { onNavigate(SpotRoute.NOTIFICATIONS) },
                Modifier.weight(1f), notificationCount) { tint ->
                Icon(if (selected == 3) Icons.Filled.Notifications else Icons.Outlined.Notifications, null, Modifier.size(25.dp), tint)
            }
            NavigationItem("Profile", selected == 4, { onNavigate(SpotRoute.PROFILE) }, Modifier.weight(1f)) { tint ->
                Box(Modifier.size(31.dp).border(1.5.dp, tint.copy(alpha = 0.7f), CircleShape)
                    .padding(3.dp).clip(CircleShape).background(Color(0xFFEDEBE4)), contentAlignment = Alignment.Center) {
                    // Keep a normal profile icon beneath Coil while loading or on an invalid URL.
                    Icon(Icons.Filled.Person, null, Modifier.size(20.dp).testTag("profile-avatar-fallback"), tint)
                    if (profile.profileImageUrl.isNotBlank()) {
                        AsyncImage(profile.profileImageUrl, null, Modifier.fillMaxSize().testTag("profile-avatar-photo"), contentScale = ContentScale.Crop)
                    }
                }
            }
        }
    }
}

@Composable
private fun GlassNavigation(compact: Boolean, selected: Int, count: Int, content: @Composable RowScope.() -> Unit) {
    val compactFraction by animateFloatAsState(
        if (compact) 1f else 0f,
        spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMediumLow),
        label = "Navigation compact fraction"
    )
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center) {
        val shape = RoundedCornerShape(34.dp)
        val barHeight = 66.dp - (18.dp * compactFraction) // 66dp expanded -> 48dp compact
        // Capture is separate from this foreground, so icons and badges stay crisp.
        BoxWithConstraints(Modifier.widthIn(max = 520.dp).fillMaxWidth().height(barHeight)
            .shadow(8.dp, shape, clip = false, ambientColor = Color(0xFF554519), spotColor = Color(0xFF554519))
            .clip(shape)
            .border(1.dp, Brush.verticalGradient(listOf(Color.White.copy(alpha = .95f), Color(0xFFDBD4C2).copy(alpha = .55f))), shape)
            .testTag("spot-navigation")) {
            SpotGlassBackdrop(Modifier.matchParentSize())
            Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(
                Color.White.copy(alpha = .76f), Color(0xFFF5F1E7).copy(alpha = .66f)))))
            val slotWidth = (maxWidth - 16.dp) / count
            val indicatorWidth = minOf(54.dp, slotWidth - 4.dp) * (1f - 0.12f * compactFraction)
            val indicatorHeight = 48.dp - (12.dp * compactFraction) // 48dp expanded -> 36dp compact
            val indicatorTopInset = 9.dp - (3.dp * compactFraction) // 9dp expanded -> 6dp compact
            val position by animateDpAsState(8.dp + slotWidth * selected + (slotWidth - indicatorWidth) / 2,
                spring(dampingRatio = 0.82f, stiffness = 420f), label = "Navigation selection")
            Box(Modifier.offset(x = position, y = indicatorTopInset).width(indicatorWidth).height(indicatorHeight)
                .shadow(2.dp, RoundedCornerShape(22.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFFFFF6D9).copy(alpha = .92f), Color(0xFFEEDBA0).copy(alpha = .8f))), RoundedCornerShape(22.dp))
                .border(1.dp, Color.White.copy(alpha = 0.9f), RoundedCornerShape(22.dp)))
            CompositionLocalProvider(LocalSpotNavCompactFraction provides compactFraction) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp).selectableGroup(),
                    verticalAlignment = Alignment.CenterVertically, content = content)
            }
        }
    }
}

@Composable
private fun NavigationItem(label: String, selected: Boolean, onClick: () -> Unit,
                           modifier: Modifier = Modifier, badgeCount: Int = 0, icon: @Composable (Color) -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val compactFraction = LocalSpotNavCompactFraction.current
    val pressScale = if (pressed) 0.94f else if (selected) 1.02f else 1f
    val compactScale = 1f - 0.15f * compactFraction // icons render ~85% size when compact
    val scale by animateFloatAsState(pressScale * compactScale,
        spring(dampingRatio = 0.65f, stiffness = 700f), label = "$label press")
    val lift by animateDpAsState(if (selected) (-1).dp else 0.dp, spring(stiffness = 450f), label = "$label lift")
    val tint by animateColorAsState(if (selected) NavInk else NavMuted, tween(180), label = "$label color")
    Box(modifier.height(54.dp - (10.dp * compactFraction)).clip(RoundedCornerShape(24.dp))
        .selectable(selected, interactionSource = interaction, indication = null, role = Role.Tab,
            onClick = onClick)
        .semantics { contentDescription = label }.testTag("nav-${label.lowercase()}"), contentAlignment = Alignment.Center) {
        Box(Modifier.offset(y = lift).graphicsLayer { scaleX = scale; scaleY = scale }, contentAlignment = Alignment.Center) {
            icon(tint)
            if (badgeCount > 0) {
                Box(Modifier.align(Alignment.TopEnd).offset(10.dp, (-7).dp)
                    .defaultMinSize(19.dp, 19.dp).background(Color(0xFFB63839), CircleShape)
                    .border(1.5.dp, Color.White, CircleShape).padding(horizontal = 4.dp, vertical = 1.dp),
                    contentAlignment = Alignment.Center) {
                    Text(if (badgeCount > 99) "99+" else badgeCount.toString(), color = Color.White,
                        fontFamily = InterFontFamily, fontSize = 10.spotSp, lineHeight = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun SpotMessagesBottomNavigation(
    selectedRoute: SpotRoute, onNavigate: (SpotRoute) -> Unit,
    visible: Boolean = true, hidden: Boolean = false
) {
    if (LocalSpotBottomNavigationSuppressed.current) return
    val routes = listOf(SpotRoute.MESSAGES_CHATS, SpotRoute.MESSAGES_GROUPS, SpotRoute.COLLAB_REQUESTS)
    val selected = routes.indexOf(selectedRoute).coerceAtLeast(0)
    AnimatedVisibility(!hidden,
        enter = slideInVertically(spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMediumLow)) { it } + fadeIn(tween(180)),
        exit = slideOutVertically(tween(180)) { it } + fadeOut(tween(140))) {
        GlassNavigation(compact = !visible, selected, 3) {
            NavigationItem("Chats", selected == 0, { onNavigate(routes[0]) }, Modifier.weight(1f)) { tint ->
                SpotMessageBubbleIcon(Modifier.size(26.dp), tint)
            }
            NavigationItem("Groups", selected == 1, { onNavigate(routes[1]) }, Modifier.weight(1f)) { tint ->
                Icon(Icons.Filled.Groups, null, Modifier.size(25.dp), tint)
            }
            NavigationItem("Collaboration requests", selected == 2, { onNavigate(routes[2]) }, Modifier.weight(1f)) { tint ->
                Icon(Icons.Filled.Handshake, null, Modifier.size(25.dp), tint)
            }
        }
    }
}