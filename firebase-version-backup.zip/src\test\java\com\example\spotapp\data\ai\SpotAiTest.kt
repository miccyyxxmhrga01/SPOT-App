package com.example.spotapp.data.ai

import okhttp3.ResponseBody.Companion.toResponseBody
import org.junit.Assert.*
import org.junit.Test
import retrofit2.HttpException
import retrofit2.Response
import java.net.SocketTimeoutException
import java.net.UnknownHostException

class SpotAiTest {
    @Test fun modelClassesMapOntoComposerCategories() {
        assertEquals("Guitar", TalentSuggestion(rawClass = "guitar").composerCategory())
        assertEquals("Dancing", TalentSuggestion(rawClass = "dancing").composerCategory())
        assertEquals("Piano", TalentSuggestion(rawClass = "keyboard").composerCategory())
        assertNull(TalentSuggestion(rawClass = "other").composerCategory())
        assertNull(TalentSuggestion(rawClass = "juggling").composerCategory())
    }

    @Test fun failuresBecomeReadableMessages() {
        val missingModel = HttpException(Response.error<Any>(503, "{}".toResponseBody()))
        assertTrue(spotAiError(missingModel).contains("isn't ready"))
        assertTrue(spotAiError(SocketTimeoutException()).contains("waking up"))
        assertTrue(spotAiError(UnknownHostException()).contains("connection"))
    }
}
