package com.example.spotapp.data

import com.google.firebase.Timestamp
import org.junit.Assert.*
import org.junit.Test

class PostDocumentMapperTest {
    private val image = "https://res.cloudinary.com/jcuzzxsz/image/upload/v1/spot/posts/creator/photo.jpg"
    private val video = "https://res.cloudinary.com/jcuzzxsz/video/upload/v1/spot/posts/creator/video.mp4"
    private fun flat() = mapOf<String, Any?>("userId" to "creator", "username" to "sam", "displayName" to "Sam Cruz",
        "userProfileImageUrl" to image, "caption" to "Campus performance", "talentCategory" to "Dancing",
        "mediaUrl" to image, "mediaType" to "image", "likesCount" to 12L, "commentsCount" to 4L,
        "createdAt" to Timestamp(1000, 0), "audience" to "public")

    @Test fun flatDocumentNeedsNeitherNestedAuthorNorStoragePath() {
        val post = requireNotNull(PostDocumentMapper.published("actual-document-id", flat()))
        assertEquals("actual-document-id", post.id)
        assertEquals("creator", post.author.uid)
        assertEquals("Sam Cruz", post.author.displayName)
        assertEquals("sam", post.author.username)
        assertEquals(image, post.author.profileImageUrl)
        assertEquals(image, post.media.single().url)
        assertEquals("Campus performance", post.caption)
        assertEquals(listOf("Dancing"), post.categories)
        assertEquals(12, post.asUiPost().likes)
        assertEquals(4, post.asUiPost().comments)
        assertEquals(1_000_000L, post.createdAt)
        assertFalse(post.asUiPost().aiCaption)
        assertEquals(image, PostDocumentMapper.spotPost("id", flat())?.mediaUrls?.single())
    }

    @Test fun videoCaseAndCloudinaryPostersAreHandledWithoutChangingPlaybackUrl() {
        val post = requireNotNull(PostDocumentMapper.published("video", flat() + mapOf("mediaUrl" to video, "mediaType" to "VIDEO")))
        assertTrue(post.media.single().isVideo)
        assertEquals(video, post.media.single().url)
        assertEquals("https://res.cloudinary.com/jcuzzxsz/video/upload/so_0,w_960,c_limit,q_auto/v1/spot/posts/creator/video.jpg", post.media.single().previewUrl)
        assertTrue(isPostVideoUrl(video + "?download=1"))
        assertEquals("", cloudinaryVideoThumbnail("https://example.test/video.mp4"))
    }

    @Test fun legacyMixedAlbumAndItsMetadataArePreserved() {
        val data = mapOf("userId" to "old", "author" to mapOf("displayName" to "Old User", "username" to "old", "profileImageUrl" to image),
            "media" to listOf(mapOf("url" to image, "contentType" to "image/jpeg", "storagePath" to "old/path"),
                mapOf("url" to video, "contentType" to "video/mp4", "thumbnailUrl" to image)),
            "caption" to "Album", "categories" to listOf("Music"), "tags" to listOf("campus"), "audience" to "followers")
        val post = requireNotNull(PostDocumentMapper.published("album", data))
        assertEquals("Old User", post.author.displayName)
        assertEquals(2, post.media.size)
        assertEquals("old/path", post.media.first().storagePath)
        assertEquals(image, post.media.last().previewUrl)
        assertEquals("followers", post.audience)
    }

    @Test fun missingOptionalFieldsAndBadCountersDoNotBreakTheFeed() {
        val post = requireNotNull(PostDocumentMapper.published("minimal", mapOf("userId" to "uid", "caption" to "Text only", "likesCount" to -5, "commentsCount" to "invalid")))
        assertTrue(post.media.isEmpty())
        assertEquals(0L, post.likes)
        assertEquals(0L, post.comments)
        assertNull(PostDocumentMapper.published("invalid", emptyMap()))
        assertTrue(requireNotNull(PostDocumentMapper.published("bad", flat() + ("mediaUrl" to "javascript:alert(1)"))).media.isEmpty())
    }

    @Test fun flatIdentityWinsAndLegacyProfileImageFieldStillWorks() {
        val post = requireNotNull(PostDocumentMapper.published("id", flat() + mapOf("author" to mapOf("displayName" to "Old name"),
            "userProfileImageUrl" to "", "profileImageUrl" to image)))
        assertEquals("Sam Cruz", post.author.displayName)
        assertEquals(image, post.author.profileImageUrl)
    }

    @Test fun feedSortingAndRelativeTimesUseCreatedAt() {
        val first = requireNotNull(PostDocumentMapper.published("older", flat()))
        val second = requireNotNull(PostDocumentMapper.published("newer", flat() + ("createdAt" to Timestamp(2000, 0))))
        assertEquals(listOf("newer", "older"), listOf(first, second).sortedByDescending { it.createdAt }.map { it.id })
        assertEquals("5m ago", postTimeLabel(1_000_000, 1_300_000))
        assertEquals("Just now", postTimeLabel(1_000_000, 900_000))
    }
}
