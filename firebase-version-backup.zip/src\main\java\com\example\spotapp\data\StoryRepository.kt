package com.example.spotapp.data

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.cloudinary.android.MediaManager
import com.example.spotapp.data.cloudinary.CloudinaryUploader
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

const val STORY_LIFETIME = 24L * 60 * 60 * 1000
data class StoryItem(val id: String, val userId: String, val mediaUrl: String, val mediaType: String,
    val createdAt: Long = 0, val audience: String = "followers", val deleted: Boolean = false,
    val username: String = "", val profileImageUrl: String = "",
    val composition: StoryComposition = StoryComposition(), val likesCount: Long = 0) {
    val video get() = mediaType == "video"
    val preview get() = if (video) cloudinaryVideoThumbnail(mediaUrl) else mediaUrl
    fun active(now: Long = System.currentTimeMillis()) = !deleted && createdAt > 0 && now < createdAt + STORY_LIFETIME
}
data class HighlightMedia(val source: String, val sourceId: String, val index: Int, val url: String, val type: String,
    val composition: StoryComposition = StoryComposition()) {
    val key get() = "$source/$sourceId/$index"
    val preview get() = if (type == "video") cloudinaryVideoThumbnail(url) else url
    fun fields(): Map<String, Any?> = mapOf("source" to source, "sourceId" to sourceId, "index" to index, "url" to url, "type" to type) +
        if (composition == StoryComposition()) emptyMap() else mapOf("composition" to composition.fields())
}
data class StoryHighlight(val id: String, val userId: String, val title: String, val media: List<HighlightMedia>, val cover: Int = 0,
    val audience: String = "public")

class StoryRepository(private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()) {
    companion object { val shared by lazy { StoryRepository() } }
    private fun uid() = checkNotNull(auth.currentUser?.uid) { "Sign in to continue." }
    private val stories get() = db.collection("stories")
    private fun highlights(id: String) = db.collection("users").document(id).collection("highlights")
    fun listenStories(owner: String? = null, result: (List<StoryItem>) -> Unit, error: (String) -> Unit): ListenerRegistration {
        val source = if (owner == null) stories.whereEqualTo("audience", "public") else stories.whereEqualTo("userId", owner)
        val query = if (owner != null && owner != auth.currentUser?.uid) source.whereIn("audience", listOf("public", "followers")) else source
        return query.orderBy("createdAt", Query.Direction.DESCENDING).limit(50).addSnapshotListener { s, e ->
            if (e != null) error("Stories couldn't load.") else result(s?.documents.orEmpty().mapNotNull(::storyFrom))
        }
    }
    fun listenHighlights(owner: String, canReadFollowers: Boolean, result: (List<StoryHighlight>) -> Unit,
        error: (String) -> Unit): ListenerRegistration {
        val all = highlights(owner)
        val query = if (owner == auth.currentUser?.uid) all else if (canReadFollowers) all.whereIn("audience", listOf("public", "followers")) else all.whereEqualTo("audience", "public")
        return query.orderBy("updatedAt", Query.Direction.DESCENDING).limit(30).addSnapshotListener { s, e ->
            if (e != null) error("Highlights couldn't load.") else result(s?.documents.orEmpty().mapNotNull { d ->
                val items = (d.get("media") as? List<*>).orEmpty().mapNotNull { it as? Map<*, *> }.mapNotNull { m ->
                    val url = m["url"] as? String ?: return@mapNotNull null
                    HighlightMedia(m["source"] as? String ?: "", m["sourceId"] as? String ?: "", (m["index"] as? Number)?.toInt() ?: 0, url, m["type"] as? String ?: "image", StoryComposition.from(m["composition"]))
                }
                if (items.isEmpty()) null else StoryHighlight(d.id, owner, d.getString("title").orEmpty(), items,
                    (d.getLong("cover") ?: 0).toInt().coerceIn(items.indices), d.getString("audience") ?: "public")
            })
        }
    }
    suspend fun createStory(id: String, mediaUrl: String, video: Boolean, audience: String, composition: StoryComposition = StoryComposition()) {
        composition.validate()
        require(audience in listOf("public", "followers", "private"))
        val me = uid()
        val ref = stories.document(id)
        db.runTransaction { tx ->
            val existing = tx.get(ref)
            if (existing.exists()) {
                check(existing.getString("userId") == me)
                check(existing.getBoolean("deleted") != true && existing.getString("mediaUrl") == mediaUrl && StoryComposition.from(existing.get("composition")) == composition) {
                    "This story was already shared. Close the editor to view it, or choose media for a new story."
                }
                return@runTransaction
            }
            val account = tx.get(db.collection("users").document(me))
            val actualAudience = if (account.getBoolean("isPrivate") == true || account.getBoolean("privacyUpdating") == true) {
                if (audience == "public") "followers" else audience
            } else audience
            tx.set(ref, mapOf("userId" to me, "mediaUrl" to mediaUrl, "mediaType" to if (video) "video" else "image",
                "audience" to actualAudience, "createdAt" to FieldValue.serverTimestamp(), "deleted" to false,
                "username" to account.getString("username").orEmpty(), "profileImageUrl" to account.getString("profileImageUrl").orEmpty()) +
                if (composition == StoryComposition()) emptyMap() else mapOf("composition" to composition.fields()))
        }.awaitSocial()
    }
    fun listenLiked(id: String, result: (Boolean) -> Unit, error: (String) -> Unit): ListenerRegistration =
        stories.document(id).collection("reactions").document(uid()).addSnapshotListener { doc, failure ->
            if (failure != null) error("Your reaction couldn't load. Retry.") else result(doc?.getBoolean("liked") == true)
        }

    suspend fun setLiked(id: String, liked: Boolean) {
        val me = uid(); val ref = stories.document(id); val reaction = ref.collection("reactions").document(me)
        socialTransaction(db) { tx ->
            val moment = tx.get(ref); val previous = tx.get(reaction).getBoolean("liked") == true
            val story = storyFrom(moment)
            check(story != null && story.active()) { "This story is no longer available." }
            check(story.userId != me) { "You can't react to your own story." }
            if (previous != liked) {
                tx.set(reaction, mapOf("liked" to liked))
                tx.update(ref, "likesCount", (moment.getLong("likesCount") ?: 0) + if (liked) 1L else -1L)
            }
        }
    }

    suspend fun removeStory(id: String) = stories.document(id).update("deleted", true).awaitSocial()
    suspend fun saveHighlight(id: String, title: String, media: List<HighlightMedia>, cover: Int, audience: String) {
        require(title.trim().length in 1..32) { "Add a title (up to 32 characters)." }
        require(media.size in 1..8 && media.distinctBy { it.key }.size == media.size && cover in media.indices) { "Choose 1–8 moments and a cover." }
        val me = uid()
        db.runTransaction { tx ->
            val account = tx.get(db.collection("users").document(me))
            val private = account.getBoolean("isPrivate") == true || account.getBoolean("privacyUpdating") == true
            tx.set(highlights(me).document(id), mapOf("userId" to me, "title" to title.trim(), "media" to media.map { it.fields() }, "cover" to cover,
                "audience" to if (private && audience == "public") "followers" else audience, "updatedAt" to FieldValue.serverTimestamp()))
        }.awaitSocial()
    }
    suspend fun removeHighlight(id: String) = highlights(uid()).document(id).delete().awaitSocial()
    suspend fun highlightSources(): List<HighlightMedia> {
        val ownStories = stories.whereEqualTo("userId", uid()).orderBy("createdAt", Query.Direction.DESCENDING).limit(50).get(Source.SERVER).awaitSocial()
        val posts = db.collection("posts").whereEqualTo("userId", uid()).orderBy("createdAt", Query.Direction.DESCENDING).limit(30).get(Source.SERVER).awaitSocial()
        return ownStories.documents.mapNotNull(::storyFrom).filterNot { it.deleted }.map { HighlightMedia("story", it.id, 0, it.mediaUrl, it.mediaType, it.composition) } +
            posts.documents.flatMap { doc -> PostDocumentMapper.published(doc.id, doc.data.orEmpty())?.media.orEmpty().mapIndexed { index, media ->
                HighlightMedia("post", doc.id, index, media.url, if (media.isVideo) "video" else "image")
            } }
    }
}

internal fun storyFrom(d: DocumentSnapshot): StoryItem? {
    val url = d.getString("mediaUrl") ?: return null
    return StoryItem(d.id, d.getString("userId") ?: return null, url, d.getString("mediaType") ?: "image",
        d.getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)?.toDate()?.time ?: 0,
        d.getString("audience") ?: "followers", d.getBoolean("deleted") == true, d.getString("username").orEmpty(), d.getString("profileImageUrl").orEmpty(), StoryComposition.from(d.get("composition")),
        (d.getLong("likesCount") ?: 0).coerceAtLeast(0))
}

suspend fun uploadStoryMedia(context: Context, value: String, folder: String, maxDurationMs: Long = 60_000, progress: (Float) -> Unit): Pair<String, Boolean> {
    val uri = Uri.parse(value)
    val video = withContext(Dispatchers.IO) {
        val type = context.contentResolver.getType(uri).orEmpty()
        require(type.startsWith("image/") || type.startsWith("video/")) { "Choose a photo or video." }
        val bytes = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
            if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else -1
        } ?: -1
        require(bytes in 1..(if (type.startsWith("video/")) 100L else 10L) * 1024 * 1024) { "Choose a photo under 10 MB or video under 100 MB." }
        if (type.startsWith("video/")) {
            val length = storyVideoDuration(context, value)
            require(length in 1..maxDurationMs) { "This video is too long. Choose a shorter clip." }
            true
        } else false
    }
    val url = suspendCancellableCoroutine { c ->
        val requestId = CloudinaryUploader.uploadMedia(uri, folder,
            onSuccess = { if (c.isActive) c.resume(it) },
            onError = { if (c.isActive) c.resumeWithException(IllegalStateException("Upload failed. Retry.")) },
            onProgress = { bytes, total -> if (total > 0) progress((bytes.toFloat() / total).coerceIn(0f, 1f)) })
        c.invokeOnCancellation { MediaManager.get().cancelRequest(requestId) }
    }
    return url to video
}
