package com.example.spotapp.ui.theme.screens.messages

import com.example.spotapp.ui.theme.components.*

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import com.example.spotapp.data.*
import com.example.spotapp.ui.theme.models.SpotRoute
import com.example.spotapp.ui.theme.models.SpotUiProfile
import com.example.spotapp.ui.theme.navigation.SpotMainBottomNavigation
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.onEach
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Canvas = Color(0xFFFFFCF5)
private val Ink = Color(0xFF26251F)
private val Muted = Color(0xFF77736A)
private val Line = Color(0xFFE9E4D9)
private val Gold = Color(0xFFD1AD32)
private val GoldSoft = Color(0xFFFFF1CB)
private val GoldInk = Color(0xFF785B13)
private val Danger = Color(0xFFB63D3D)

enum class MessagesTab { CHATS, COLLABS, GROUPS }

@Composable
fun MessagesScreen(
    profile: SpotUiProfile, onNavigate: (SpotRoute) -> Unit, onBack: () -> Unit,
    initialTab: MessagesTab = MessagesTab.CHATS, startConversationWithName: String? = null,
    onStartConversationConsumed: () -> Unit = {}, startConversationWithUid: String? = null,
    onThreadVisibilityChanged: (Boolean) -> Unit = {}, onUnreadCountChanged: (Int) -> Unit = {},
    store: MessagesStore = remember(profile.uid) { FirebaseMessagesStore(profile.uid) }
) {
    var retry by remember { mutableIntStateOf(0) }
    val inbox by remember(store, retry) { store.inbox() }.collectAsStateWithLifecycle(MessagesInbox())
    var tab by rememberSaveable { mutableStateOf(initialTab) }
    var search by rememberSaveable { mutableStateOf("") }
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    var compose by remember { mutableStateOf(false) }
    var preselected by remember { mutableStateOf<ChatPerson?>(null) }
    var busy by remember { mutableStateOf(false) }
    var failure by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val all = inbox.conversations + inbox.requests
    val visible = inbox.conversations.filter { it.visible(inbox.preferences[it.id] ?: ChatPreferences()) }
    val unreadCount = visible.count { it.unread(store.uid, inbox.preferences[it.id] ?: ChatPreferences()) }
    // Read selectedId here, not inside SideEffect: SideEffect reads aren't tracked, so opening or
    // closing a chat would otherwise never recompose this scope and the main navigation would stay visible.
    val threadOpen = selectedId != null
    SideEffect {
        onThreadVisibilityChanged(threadOpen)
        onUnreadCountChanged(unreadCount)
    }
    DisposableEffect(Unit) { onDispose { onThreadVisibilityChanged(false) } }
    fun act(action: suspend () -> Unit) {
        if (busy) return
        scope.launch {
            busy = true
            try { withTimeout(60_000) { action() } }
            catch (_: TimeoutCancellationException) { failure = "That action took too long. Please reconnect and retry." }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { failure = messagesError(e) }
            finally { busy = false }
        }
    }
    LaunchedEffect(store, retry) {
        try { store.syncProfile() } catch (e: CancellationException) { throw e } catch (_: Exception) { /* Inbox renders the retry state. */ }
    }
    LaunchedEffect(startConversationWithUid, startConversationWithName) {
        if (startConversationWithUid != null || startConversationWithName != null) {
            try {
                val person = startConversationWithUid?.let { store.person(it) }
                if (person == null) {
                    compose = true
                    // A display name is not an identity. Let the user select a verified directory record.
                } else {
                    val existing = inbox.conversations.firstOrNull { !it.demo && it.kind == "direct" && person.uid in it.partyIds && (it.invitedIds.isNotEmpty() || it.memberIds.size >= 2) }
                    if (existing != null) selectedId = existing.id else { preselected = person; compose = true }
                }
            } catch (e: CancellationException) { throw e } catch (e: Exception) { failure = messagesError(e) }
            onStartConversationConsumed()
        }
    }
    var previousUpdates by remember(store) { mutableStateOf<Map<String, Long>?>(null) }
    LaunchedEffect(inbox.conversations) {
        if (!inbox.loading && inbox.error.isBlank()) {
            val old = previousUpdates
            previousUpdates = inbox.conversations.associate { it.id to it.updatedAt }
            if (old != null) inbox.conversations.firstOrNull { chat ->
                val prefs = inbox.preferences[chat.id] ?: ChatPreferences()
                chat.id != selectedId && !prefs.muted && !chat.demo && chat.lastSenderId != store.uid &&
                    chat.lastSenderId !in inbox.blockedIds && chat.preview.isNotBlank() && chat.updatedAt > (old[chat.id] ?: 0)
            }?.let { snackbar.showSnackbar("${it.nameFor(store.uid)}: ${it.preview.take(80)}") }
        }
    }
    if (failure.isNotBlank()) AlertDialog(onDismissRequest = { failure = "" }, title = { Text("Couldn't finish that action") },
        text = { Text(failure) }, confirmButton = { TextButton(onClick = { failure = "" }) { Text("OK") } })

    Scaffold(containerColor = Canvas, snackbarHost = { SnackbarHost(snackbar) }, bottomBar = {
        if (selectedId == null) SpotMainBottomNavigation(
            selectedRoute = SpotRoute.MESSAGES_CHATS, profile = profile, onNavigate = onNavigate,
            unreadMessagesCount = unreadCount, notificationCount = 0)
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).consumeWindowInsets(padding)) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().testTag("messages-progress"), color = Gold, trackColor = GoldSoft)
            AnimatedContent(targetState = selectedId, modifier = Modifier.weight(1f), transitionSpec = {
                val direction = if (targetState != null) 1 else -1
                (fadeIn(tween(180)) + slideInHorizontally(tween(260, easing = FastOutSlowInEasing)) { it / 8 * direction }) togetherWith
                    (fadeOut(tween(120)) + slideOutHorizontally(tween(220)) { -it / 10 * direction })
            }, label = "messages-screen") { id ->
                val chat = all.firstOrNull { it.id == id }
                when {
                    id == null -> MessagesList(inbox, visible, store.uid, tab, { tab = it }, search, { search = it },
                        { preselected = null; compose = true }, { selectedId = it.id }, { retry++ },
                        { act { store.addSamples() } }, busy)
                    chat == null -> Column(Modifier.fillMaxSize().spotAmbientBackground(Canvas)) { TextButton({ selectedId = null }) { Text("Back to Messages") }; MessageEmpty(Icons.Filled.Forum, "Opening conversation", inbox.error.ifBlank { "Waiting for your conversation to sync." }, "Retry", { retry++ }, loading = inbox.error.isBlank()) }
                    store.uid in chat.invitedIds -> InvitationPage(chat, store.uid, busy, { selectedId = null },
                        { act { store.respond(chat.id, true) } }, { act { store.respond(chat.id, false); selectedId = null } })
                    else -> key(chat.id) {
                        ConversationPage(chat, inbox.preferences[chat.id] ?: ChatPreferences(), inbox.blockedIds, store,
                            { selectedId = null }, { message -> scope.launch { snackbar.showSnackbar(message) } }, { selectedId = null })
                    }
                }
            }
        }
    }
    if (compose) NewConversationDialog(store, preselected, inbox.blockedIds, onDismiss = { compose = false }, onCreated = {
        compose = false; selectedId = it; tab = MessagesTab.CHATS
    }, existing = inbox.conversations)
}

@Composable
private fun MessagesList(inbox: MessagesInbox, conversations: List<CampusConversation>, uid: String,
    tab: MessagesTab, onTab: (MessagesTab) -> Unit, search: String, onSearch: (String) -> Unit,
    onCompose: () -> Unit, onOpen: (CampusConversation) -> Unit, onRetry: () -> Unit,
    onSamples: () -> Unit, busy: Boolean) {
    val requests = inbox.requests.filter { it.creatorId !in inbox.blockedIds }
    val current = when (tab) { MessagesTab.CHATS -> conversations.filter { it.kind == "direct" }; MessagesTab.COLLABS -> conversations.filter { it.kind == "group" }; MessagesTab.GROUPS -> requests }
    val filtered = current.filter { search.isBlank() || it.nameFor(uid, inbox.preferences[it.id] ?: ChatPreferences()).contains(search, true) || it.preview.contains(search, true) }
    Column(Modifier.fillMaxSize().spotAmbientBackground(Canvas)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                Text("Messages", style = MaterialTheme.typography.headlineSmall, color = Ink, fontWeight = FontWeight.Bold)

            }
            CircleAction(Icons.Filled.Edit, "New conversation", onCompose, gold = true, tag = "messages-compose")
        }
        SpotSearchField(search, onSearch, Modifier.padding(horizontal = 16.dp, vertical = 6.dp).testTag("messages-search"), "Search conversations")

        MessagesTabs(tab, onTab, requests.size)
        val recent = conversations.filter { it.kind == "direct" }.take(8)
        if (recent.isNotEmpty() && search.isBlank()) {
            Text("Recent", style = MaterialTheme.typography.labelMedium, color = Muted,
                modifier = Modifier.padding(start = 20.dp, top = 18.dp, bottom = 10.dp))
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                items(recent, key = { it.id }) { chat ->
                    Column(Modifier.width(66.dp).clip(RoundedCornerShape(14.dp)).clickable { onOpen(chat) }.padding(vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        ChatAvatar(chat.nameFor(uid), chat.people[chat.otherUid(uid)]?.photo.orEmpty(), chat.demo, size = 52, uid = chat.otherUid(uid))
                        Spacer(Modifier.height(6.dp))
                        Text(chat.nameFor(uid).substringBefore(' '), style = MaterialTheme.typography.labelMedium, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(when (tab) { MessagesTab.CHATS -> "Chats"; MessagesTab.COLLABS -> "Your collaborations"; MessagesTab.GROUPS -> "Invitations" },
                style = MaterialTheme.typography.titleSmall, color = Ink, modifier = Modifier.weight(1f))
            Text(filtered.size.toString(), style = MaterialTheme.typography.labelMedium, color = Muted)
        }
        AnimatedContent(tab, modifier = Modifier.weight(1f), transitionSpec = {
            (fadeIn(tween(170)) + slideInHorizontally(tween(240)) { it / 12 }) togetherWith fadeOut(tween(100))
        }, label = "message-tabs-content") { shownTab ->
            val rows = when (shownTab) { MessagesTab.CHATS -> conversations.filter { it.kind == "direct" }; MessagesTab.COLLABS -> conversations.filter { it.kind == "group" }; MessagesTab.GROUPS -> requests }
                .filter { search.isBlank() || it.nameFor(uid, inbox.preferences[it.id] ?: ChatPreferences()).contains(search, true) || it.preview.contains(search, true) }
            LazyColumn(Modifier.fillMaxSize().testTag("messages-list"), contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 18.dp + LocalSpotBottomContentPadding.current), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (inbox.loading) item { SpotLoading(true, SkeletonKind.ROWS) }
                else if (inbox.error.isNotBlank()) item { MessageEmpty(Icons.Filled.CloudOff, "Messages couldn't load", inbox.error, "Retry", onRetry) }
                else if (rows.isEmpty()) item {
                    MessageEmpty(if (search.isNotBlank()) Icons.Filled.Search else Icons.Filled.Forum,
                        if (search.isNotBlank()) "No conversations found" else when (shownTab) { MessagesTab.CHATS -> "Start a conversation"; MessagesTab.COLLABS -> "Create something together"; MessagesTab.GROUPS -> "You're all caught up" },
                        if (search.isNotBlank()) "" else when (shownTab) { MessagesTab.GROUPS -> "New chat and collaboration invitations will appear here."; else -> "" },
                        if (shownTab == MessagesTab.GROUPS || search.isNotBlank()) null else "New conversation", onCompose)
                }
                else items(rows, key = { it.id }) { chat ->
                    ConversationRow(chat, inbox.preferences[chat.id] ?: ChatPreferences(), uid, shownTab == MessagesTab.GROUPS,
                        onClick = { onOpen(chat) }, modifier = Modifier.animateItem(fadeInSpec = tween(180), placementSpec = spring(stiffness = Spring.StiffnessMediumLow)))
                }
                if (!inbox.loading && inbox.error.isBlank() && search.isBlank()) item {
                    TextButton(onClick = onSamples, enabled = !busy, modifier = Modifier.fillMaxWidth().testTag("messages-samples")) {
                        Icon(Icons.Filled.Science, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp))
                        Text(if (conversations.any { it.demo }) "Restore sample chats" else "Try private sample chats", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }
}

@Composable
private fun MessagesTabs(tab: MessagesTab, onTab: (MessagesTab) -> Unit, requests: Int) {
    BoxWithConstraints(Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0xFFF1EEE5)).padding(4.dp)) {
        val width = maxWidth / 3
        val offset by animateDpAsState(width * tab.ordinal, spring(dampingRatio = .88f, stiffness = 380f), label = "messages-tab-pill")
        Box(Modifier.offset(x = offset).width(width).height(46.dp).clip(RoundedCornerShape(14.dp)).background(Color.White).border(1.dp, Line, RoundedCornerShape(14.dp)))
        Row {
            MessagesTab.entries.forEach { item ->
                val color by animateColorAsState(if (item == tab) Ink else Muted, tween(180), label = "messages-tab-color")
                Box(Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(14.dp)).semantics { role = Role.Tab; selected = item == tab }
                    .clickable { onTab(item) }.testTag("messages-tab-${item.name}"), contentAlignment = Alignment.Center) {
                    Text(when (item) { MessagesTab.CHATS -> "Chats"; MessagesTab.COLLABS -> "Collabs"; MessagesTab.GROUPS -> "Requests" },
                        style = MaterialTheme.typography.labelLarge, color = color, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun ConversationRow(chat: CampusConversation, preferences: ChatPreferences, uid: String, invitation: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val unread = invitation || chat.unread(uid, preferences)
    val name = chat.nameFor(uid, preferences)
    Surface(onClick = onClick, modifier = modifier.fillMaxWidth().testTag("conversation-${chat.id}"), shape = RoundedCornerShape(20.dp),
        color = if (unread) Color(0xFFFFF7DF) else Color.White, border = BorderStroke(1.dp, if (unread) Color(0xFFE8D7A5) else Line), shadowElevation = 0.dp) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            ChatAvatar(name, chat.people[chat.otherUid(uid)]?.photo.orEmpty(), chat.demo, chat.kind == "group", uid = chat.otherUid(uid))
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(name, style = MaterialTheme.typography.titleSmall, fontWeight = if (unread) FontWeight.Bold else FontWeight.SemiBold,
                        color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                    if (preferences.muted) Icon(Icons.Filled.NotificationsOff, "Muted", tint = Muted, modifier = Modifier.size(15.dp))
                }
                Spacer(Modifier.height(4.dp))
                Text(if (invitation) chat.inviteNote.ifBlank { "Invited you to connect" } else chat.preview.ifBlank { if (chat.invitedIds.isEmpty() && chat.memberIds.size < 2) "Invitation closed" else "Invitation sent" },
                    style = MaterialTheme.typography.bodyMedium, color = if (unread) GoldInk else Muted, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Column(Modifier.padding(start = 8.dp), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(shortTime(chat.updatedAt), style = MaterialTheme.typography.labelSmall, color = Muted)
                if (unread) Box(Modifier.size(8.dp).background(Gold, CircleShape))
            }
        }
    }
}

@Composable
private fun ChatAvatar(name: String, photo: String = "", demo: Boolean = false, group: Boolean = false, size: Int = 48, uid: String = "") {
    if (!group && !demo) SpotAvatar(photo, name, Modifier.size(size.dp), uid)
    else Box(Modifier.size(size.dp).clip(CircleShape).background(GoldSoft), contentAlignment = Alignment.Center) {
        Icon(if (group) Icons.Filled.Groups else Icons.Filled.Science, null, tint = GoldInk, modifier = Modifier.size((size * .42f).dp))
    }
}

@Composable
private fun CircleAction(icon: ImageVector, label: String, onClick: () -> Unit, gold: Boolean = false, tag: String = "", enabled: Boolean = true) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .92f else 1f, spring(stiffness = 550f), label = "message-action-press")
    IconButton(onClick, enabled = enabled, interactionSource = interaction, modifier = Modifier.size(48.dp).graphicsLayer { scaleX = scale; scaleY = scale }
        .clip(CircleShape).background(if (gold) GoldSoft else Color.White.copy(alpha = .8f)).border(1.dp, Line, CircleShape).testTag(tag)) {
        Icon(icon, label, tint = if (enabled) if (gold) GoldInk else Ink else Muted.copy(alpha = .5f), modifier = Modifier.size(21.dp))
    }
}

@Composable
private fun MessageEmpty(icon: ImageVector, title: String, message: String, action: String? = null, onAction: () -> Unit = {}, loading: Boolean = false) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(60.dp).background(GoldSoft, RoundedCornerShape(20.dp)), contentAlignment = Alignment.Center) {
            if (loading) CircularProgressIndicator(Modifier.size(24.dp), color = Gold, strokeWidth = 2.dp) else Icon(icon, null, tint = GoldInk, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(14.dp)); Text(title, style = MaterialTheme.typography.titleMedium, color = Ink)
        Spacer(Modifier.height(7.dp)); if (message.isNotBlank()) Text(message, style = MaterialTheme.typography.bodyMedium, color = Muted, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        if (action != null) TextButton(onClick = onAction, modifier = Modifier.padding(top = 8.dp)) { Text(action) }
    }
}

@Composable
private fun fieldColors() = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, unfocusedBorderColor = Line,
    focusedContainerColor = Color.White, unfocusedContainerColor = Color.White, cursorColor = GoldInk)

@Composable
private fun NewConversationDialog(store: MessagesStore, initial: ChatPerson?, blocked: Set<String>, onDismiss: () -> Unit,
    onCreated: (String) -> Unit, existing: List<CampusConversation>) {
    var query by rememberSaveable { mutableStateOf("") }
    var people by remember { mutableStateOf<List<ChatPerson>>(emptyList()) }
    var chosen by remember { mutableStateOf(listOfNotNull(initial)) }
    var group by rememberSaveable { mutableStateOf(false) }
    var title by rememberSaveable { mutableStateOf("") }
    var note by rememberSaveable { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var retry by remember { mutableIntStateOf(0) }
    var saving by remember { mutableStateOf(false) }
    val id = rememberSaveable { UUID.randomUUID().toString() }
    val scope = rememberCoroutineScope()
    LaunchedEffect(query, retry) {
        loading = true; error = ""
        try { delay(250); people = store.people(query).filter { it.uid !in blocked } }
        catch (e: CancellationException) { throw e } catch (e: Exception) { error = messagesError(e) }
        finally { loading = false }
    }
    Dialog(onDismissRequest = { if (!saving) onDismiss() }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth().fillMaxHeight(.92f).padding(14.dp), shape = RoundedCornerShape(26.dp), color = Canvas) {
            Column(Modifier.padding(18.dp).imePadding()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("New conversation", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                    IconButton(onClick = onDismiss, enabled = !saving) { Icon(Icons.Filled.Close, "Close") }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(!group, { group = false; chosen = chosen.take(1) }, { Text("Chat") }, enabled = !saving)
                    FilterChip(group, { group = true }, { Text("Collaboration") }, enabled = !saving)
                }
                if (group) OutlinedTextField(title, { title = it.take(60) }, label = { Text("Collaboration name") },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), singleLine = true, textStyle = MaterialTheme.typography.bodyMedium, colors = fieldColors(), enabled = !saving)
                OutlinedTextField(query, { query = it }, label = { Text("Find a name or username") }, leadingIcon = { Icon(Icons.Filled.Search, null) },
                    modifier = Modifier.fillMaxWidth().testTag("people-search"), singleLine = true, textStyle = MaterialTheme.typography.bodyMedium, colors = fieldColors(), enabled = !saving)
                if (chosen.isNotEmpty()) Text("To: ${chosen.joinToString { it.name }}", style = MaterialTheme.typography.bodySmall, color = GoldInk, modifier = Modifier.padding(vertical = 8.dp))
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
                    if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth(), color = Gold) }
                    else if (error.isNotBlank()) item { Text(error, color = Danger, style = MaterialTheme.typography.bodySmall); TextButton({ retry++ }) { Text("Retry") } }
                    else if (people.isEmpty()) item { Text("No matching connections yet. People appear here after opening Messages on SPOT.", style = MaterialTheme.typography.bodyMedium, color = Muted, modifier = Modifier.padding(vertical = 18.dp)) }
                    items(people, key = { it.uid }) { person ->
                        val checked = person.uid in chosen.map { it.uid }
                        Surface(onClick = {
                            if (checked) chosen = chosen.filter { it.uid != person.uid }
                            else if (!group) chosen = listOf(person)
                            else if (chosen.size < 7) chosen = chosen + person
                        }, enabled = !saving, shape = RoundedCornerShape(14.dp), color = if (checked) GoldSoft else Color.White) {
                            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                ChatAvatar(person.name, person.photo, size = 40, uid = person.uid)
                                Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                                    Text(person.name, style = MaterialTheme.typography.titleSmall)
                                    Text("@${person.username.removePrefix("@")}", style = MaterialTheme.typography.bodySmall, color = Muted)
                                }
                                Icon(if (checked) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked, if (checked) "Selected" else "Select", tint = if (checked) GoldInk else Muted)
                            }
                        }
                    }
                }
                OutlinedTextField(note, { note = it.take(500) }, label = { Text("Invitation message (optional)") }, minLines = 2, maxLines = 3,
                    modifier = Modifier.fillMaxWidth(), textStyle = MaterialTheme.typography.bodyMedium, colors = fieldColors(), enabled = !saving)
                Text("They choose whether to accept before joining the conversation.", style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(vertical = 10.dp))
                Button(onClick = {
                    scope.launch {
                        saving = true; error = ""
                        try {
                            val found = if (!group) existing.firstOrNull { !it.demo && it.kind == "direct" && chosen.single().uid in it.partyIds && (it.invitedIds.isNotEmpty() || it.memberIds.size >= 2) } else null
                            val created = found?.id ?: withTimeout(45_000) { store.create(chosen, title, note, group, id) }
                            onCreated(created)
                        } catch (_: TimeoutCancellationException) { error = "Couldn't connect. Retry with the same invitation." }
                        catch (e: CancellationException) { throw e } catch (e: Exception) { error = messagesError(e) }
                        finally { saving = false }
                    }
                }, enabled = !saving && chosen.isNotEmpty() && (!group || title.isNotBlank()), modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).testTag("create-conversation"),
                    colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) {
                    if (saving) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Ink) else Text("Start conversation")
                }
            }
        }
    }
}

@Composable
private fun InvitationPage(chat: CampusConversation, uid: String, busy: Boolean, onBack: () -> Unit, onAccept: () -> Unit, onDecline: () -> Unit) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().spotAmbientBackground(Canvas).verticalScroll(rememberScrollState())) {
        ThreadHeader(chat.nameFor(uid), "Invitation to ${if (chat.kind == "group") "collaborate" else "connect"}", chat, uid, onBack)
        Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("${chat.people[chat.creatorId]?.name ?: "A campus connection"} invited you", style = MaterialTheme.typography.titleLarge, color = Ink)
            Surface(shape = RoundedCornerShape(20.dp), color = Color.White, border = BorderStroke(1.dp, Line)) {
                Text(chat.inviteNote.ifBlank { "Let's connect on SPOT." }, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.fillMaxWidth().padding(20.dp))
            }
            Text("Accept to see this conversation and exchange messages. Decline to remove the invitation.", style = MaterialTheme.typography.bodyMedium, color = Muted)
            Button(onClick = onAccept, enabled = !busy, modifier = Modifier.fillMaxWidth().heightIn(min = 50.dp), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) { Text("Accept invitation") }
            OutlinedButton(onClick = onDecline, enabled = !busy, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) { Text("Decline") }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ConversationPage(chat: CampusConversation, prefs: ChatPreferences, blockedIds: Set<String>, store: MessagesStore,
    onBack: () -> Unit, notice: (String) -> Unit, onRemoved: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var page by rememberSaveable { mutableStateOf("chat") }
    var retry by remember { mutableIntStateOf(0) }
    var loadError by remember { mutableStateOf("") }
    var messagesLoading by remember { mutableStateOf(true) }
    val live by remember(chat.id, retry) {
        store.messages(chat.id).onEach { messagesLoading = false; loadError = "" }.catch { loadError = messagesError(it); messagesLoading = false; emit(emptyList()) }
    }.collectAsStateWithLifecycle(emptyList())
    var earlier by remember { mutableStateOf<List<CampusMessage>>(emptyList()) }
    var more by remember { mutableStateOf(true) }
    var loadingOlder by remember { mutableStateOf(false) }
    val hidden by remember(chat.id) { store.hiddenMessages(chat.id).catch { emit(emptySet()) } }.collectAsStateWithLifecycle(emptySet())
    // "loaded" keeps hidden messages so paging still starts from the oldest one fetched.
    val loaded = (earlier + live).distinctBy { it.id }.sortedWith(compareBy<CampusMessage> { it.createdAt }.thenBy { it.id })
    val messages = loaded.filter { it.id !in hidden }
    var options by remember { mutableStateOf<CampusMessage?>(null) }
    var unsendTarget by remember { mutableStateOf<CampusMessage?>(null) }
    val clipboard = LocalClipboardManager.current
    val haptics = LocalHapticFeedback.current
    var draft by rememberSaveable(chat.id) { mutableStateOf("") }
    var draftId by rememberSaveable(chat.id) { mutableStateOf(UUID.randomUUID().toString()) }
    var mediaUri by rememberSaveable(chat.id) { mutableStateOf<String?>(null) }
    var mediaMime by rememberSaveable(chat.id) { mutableStateOf<String?>(null) }
    var uploaded by remember { mutableStateOf<ChatAttachment?>(null) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var actionError by remember { mutableStateOf("") }
    var search by rememberSaveable { mutableStateOf<String?>(null) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var mediaPreview by remember { mutableStateOf<CampusMessage?>(null) }
    var attachmentMenu by remember { mutableStateOf(false) }
    val blocked = chat.otherUid(store.uid) in blockedIds
    val canSend = !blocked && (chat.demo || chat.memberIds.size >= 2)
    val list = rememberLazyListState()
    val name = chat.nameFor(store.uid, prefs)
    fun act(action: suspend () -> Unit) {
        if (busy) return
        scope.launch {
            busy = true; actionError = ""
            try { withTimeout(45_000) { action() } }
            catch (_: TimeoutCancellationException) { actionError = "Couldn't connect. Please retry." }
            catch (e: CancellationException) { throw e } catch (e: Exception) { actionError = messagesError(e) }
            finally { busy = false }
        }
    }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            mediaUri = uri.toString(); mediaMime = context.contentResolver.getType(uri); uploaded = null; draftId = UUID.randomUUID().toString()
        }
    }
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) scope.launch {
            try {
                val file = withContext(Dispatchers.IO) { File.createTempFile("chat-camera-", ".jpg", context.cacheDir).also { file -> file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) } } }
                mediaUri = Uri.fromFile(file).toString(); mediaMime = "image/jpeg"; uploaded = null; draftId = UUID.randomUUID().toString()
            } catch (e: Exception) { actionError = "Couldn't prepare that photo. Please try again." }
        }
    }
    val owner = LocalLifecycleOwner.current
    val lifecycle by owner.lifecycle.currentStateFlow.collectAsStateWithLifecycle()
    LaunchedEffect(chat.updatedAt, lifecycle, page, loadError, live) {
        if (lifecycle.isAtLeast(Lifecycle.State.RESUMED) && page == "chat" && loadError.isBlank() && live.isNotEmpty() && chat.updatedAt > prefs.readAt) {
            try { store.preferences(chat.id, mapOf("readAt" to true)) } catch (e: CancellationException) { throw e } catch (_: Exception) { }
        }
        if (live.isNotEmpty()) messagesLoading = false
    }
    LaunchedEffect(live.lastOrNull()?.id) {
        if (messages.isNotEmpty() && search == null && (live.lastOrNull()?.senderId == store.uid || list.firstVisibleItemIndex >= (messages.size - 8).coerceAtLeast(0)))
            list.animateScrollToItem((messages.size - 1).coerceAtLeast(0) + 1)
    }
    BackHandler { if (busy) notice("Please wait for this action to finish.") else if (search != null) search = null else if (page != "chat") page = "chat" else onBack() }
    if (attachmentMenu) ModalBottomSheet(onDismissRequest = { attachmentMenu = false }, containerColor = Canvas) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp)) {
            InfoRow(Icons.Filled.CameraAlt, "Camera", "Take a photo", onClick = { attachmentMenu = false; try { camera.launch(null) } catch (_: Exception) { actionError = "No camera app is available." } })
            InfoRow(Icons.Filled.PhotoLibrary, "Photos & videos", "Up to 25 MB", onClick = { attachmentMenu = false; gallery.launch(arrayOf("image/*", "video/*")) })
        }
    }
    if (actionError.isNotBlank()) AlertDialog(onDismissRequest = { actionError = "" }, title = { Text("Action not completed") },
        text = { Text(actionError) }, confirmButton = { TextButton({ actionError = "" }) { Text("Keep editing") } })
    if (dialog != null) {
        val current = dialog!!
        var text by remember(current) { mutableStateOf(if (current == "nickname") prefs.nickname else "") }
        AlertDialog(onDismissRequest = { if (!busy) dialog = null }, title = { Text(when (current) {
            "nickname" -> "Nickname"; "report" -> "Report conversation"; "block" -> if (blocked) "Unblock $name?" else "Block $name?"; "leave" -> "Leave collaboration?"; else -> "Remove from inbox?"
        }) }, text = {
            when (current) {
                "nickname", "report" -> Column {
                    Text(if (current == "nickname") "Only you see this nickname. Leave it blank to restore the original name." else "Describe the content or behavior you're reporting.", style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(text, { text = it.take(if (current == "nickname") 60 else 1000) }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp).testTag("conversation-dialog-input"), minLines = if (current == "report") 3 else 1, maxLines = 5, colors = fieldColors())
                }
                "block" -> Text(if (blocked) "You can exchange messages again after unblocking." else "This person won't be able to send you direct messages or new direct invitations. Previous messages remain available.")
                "leave" -> Text("You will lose access to this collaboration and its shared media.")
                else -> Text("This hides the conversation for you. It returns when a new message arrives; other members keep their history.")
            }
        }, confirmButton = { TextButton(enabled = !busy && (current != "report" || text.trim().length >= 5), onClick = {
            act {
                when (current) {
                    "nickname" -> store.preferences(chat.id, mapOf("nickname" to text.trim()))
                    "report" -> { store.report(chat.id, text); notice("Report submitted.") }
                    "block" -> store.block(chat.otherUid(store.uid), !blocked)
                    "leave" -> { store.leave(chat.id); onRemoved() }
                    else -> { store.preferences(chat.id, mapOf("hiddenAt" to true)); onRemoved() }
                }
                dialog = null
            }
        }) { Text(if (current in listOf("nickname", "report")) "Save" else "Confirm") } }, dismissButton = { TextButton({ dialog = null }, enabled = !busy) { Text("Cancel") } })
    }
    fun messageAction(action: suspend () -> Unit) {
        scope.launch {
            try { withTimeout(30_000) { action() } }
            catch (_: TimeoutCancellationException) { actionError = "Couldn't connect. Please retry." }
            catch (e: CancellationException) { throw e } catch (e: Exception) { actionError = messagesError(e) }
        }
    }
    options?.let { message ->
        ModalBottomSheet(onDismissRequest = { options = null }, containerColor = Canvas) {
            Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp).testTag("message-options")) {
                if (message.text.isNotBlank()) InfoRow(Icons.Filled.ContentCopy, "Copy", "Copy the message text", onClick = {
                    clipboard.setText(AnnotatedString(message.text)); options = null; notice("Message copied.")
                })
                if (message.canUnsend(store.uid)) InfoRow(Icons.AutoMirrored.Filled.Undo, "Unsend", "Remove this message for everyone", danger = true, onClick = {
                    options = null; unsendTarget = message
                })
                InfoRow(Icons.Filled.DeleteOutline, "Delete for you", "Others in this chat can still see it", danger = true, onClick = {
                    options = null; messageAction { store.deleteForMe(chat.id, message.id); notice("Message deleted for you.") }
                })
            }
        }
    }
    unsendTarget?.let { message ->
        AlertDialog(onDismissRequest = { unsendTarget = null }, title = { Text("Unsend message?") },
            text = { Text("It will be removed for everyone in this chat. People may have already seen it.") },
            confirmButton = { TextButton({ unsendTarget = null; messageAction { store.unsend(chat.id, message.id) } }, Modifier.testTag("confirm-unsend")) { Text("Unsend", color = Danger) } },
            dismissButton = { TextButton({ unsendTarget = null }) { Text("Cancel") } })
    }
    if (mediaPreview != null) MediaDialog(mediaPreview!!, store, onDismiss = { mediaPreview = null })
    AnimatedContent(page, transitionSpec = {
        val order = listOf("chat", "info", "media")
        val direction = if (order.indexOf(targetState) > order.indexOf(initialState)) 1 else -1
        (fadeIn(tween(180)) + slideInHorizontally(tween(230, easing = FastOutSlowInEasing)) { direction * it / 6 }) togetherWith
            (fadeOut(tween(100)) + slideOutHorizontally(tween(200)) { -direction * it / 10 })
    }, label = "conversation-details") { current ->
        when (current) {
            "info" -> ConversationInfo(chat, prefs, store.uid, blocked, busy, { page = "chat" }, { dialog = "nickname" },
                { page = "chat"; search = "" }, { page = "media" }, { act { store.preferences(chat.id, mapOf("muted" to !prefs.muted)) } },
                { dialog = "report" }, { dialog = "block" }, { dialog = "remove" }, { dialog = "leave" })
            "media" -> SharedMediaPage(messages, { page = "info" }, { mediaPreview = it }, more && live.size >= 50, loadingOlder, {
                if (loaded.isNotEmpty()) scope.launch {
                    loadingOlder = true
                    try { val older = store.olderMessages(chat.id, loaded.first()); earlier = older + earlier; more = older.size == 50 }
                    catch (e: CancellationException) { throw e } catch (e: Exception) { actionError = messagesError(e) }
                    finally { loadingOlder = false }
                }
            })
            else -> Column(Modifier.fillMaxSize().spotAmbientBackground(Canvas) .imePadding()) {
                AnimatedContent(search != null, transitionSpec = { fadeIn(tween(160)) togetherWith fadeOut(tween(100)) }, label = "message search") { searching ->
                if (!searching) ThreadHeader(name, when { chat.demo -> "Private sample conversation"; blocked -> "Blocked"; chat.memberIds.size < 2 -> if (chat.invitedIds.isEmpty()) "Invitation closed" else "Invitation pending"; chat.kind == "group" -> "${chat.memberIds.size} members"; else -> "Campus connection" }, chat, store.uid,
                    { if (busy) notice("Please wait for your message to finish.") else onBack() }, { page = "info" })
                else Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ search = null }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Close search") }
                    SpotSearchField(search.orEmpty(), { search = it }, Modifier.weight(1f).testTag("thread-search"), "Search messages")
                }
                }
                if (chat.demo) Text("DEMO · Only you can access this sample chat", style = MaterialTheme.typography.labelSmall, color = GoldInk,
                    modifier = Modifier.fillMaxWidth().background(GoldSoft.copy(alpha = .5f)).padding(horizontal = 16.dp, vertical = 7.dp))
                val shown = messages.filter { search.isNullOrBlank() || it.text.contains(search.orEmpty(), true) }
                LazyColumn(state = list, modifier = Modifier.weight(1f).fillMaxWidth().testTag("thread-messages"),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item(key = "thread-start") {
                        if (loadError.isNotBlank()) MessageEmpty(Icons.Filled.CloudOff, "Conversation unavailable", loadError, "Retry", { loadError = ""; messagesLoading = true; retry++ })
                        else if (messagesLoading) SpotLoading(true, SkeletonKind.ROWS)
                        else if (messages.isEmpty()) MessageEmpty(Icons.Filled.WavingHand, "Say hello", if (canSend) "" else "You can message once the invitation is accepted.")
                        else if (live.size >= 50 && more) TextButton(onClick = {
                            scope.launch {
                                loadingOlder = true
                                try { val older = store.olderMessages(chat.id, loaded.first()); earlier = older + earlier; more = older.size == 50 }
                                catch (e: CancellationException) { throw e } catch (e: Exception) { actionError = messagesError(e) }
                                finally { loadingOlder = false }
                            }
                        }, enabled = !loadingOlder, modifier = Modifier.fillMaxWidth()) { if (loadingOlder) CircularProgressIndicator(Modifier.size(18.dp), color = Gold, strokeWidth = 2.dp) else Text("Load earlier messages") }
                    }
                    itemsIndexed(shown, key = { _, message -> message.id }) { index, message ->
                        Column(Modifier.animateItem(fadeInSpec = tween(180), placementSpec = spring(stiffness = 450f))) {
                            if (index == 0 || dayKey(shown[index - 1].createdAt) != dayKey(message.createdAt))
                                Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) { Text(dayLabel(message.createdAt), style = MaterialTheme.typography.labelSmall, color = Muted) }
                            MessageBubble(message, message.senderId == store.uid, if (chat.kind == "group" && message.senderId != store.uid)
                                if (message.senderId == "demo") "Sample creator" else chat.people[message.senderId]?.name else null, store, { mediaPreview = message },
                                onLongPress = { haptics.performHapticFeedback(HapticFeedbackType.LongPress); options = message })
                        }
                    }
                    if (search != null && shown.isEmpty() && !messagesLoading) item { MessageEmpty(Icons.Filled.Search, "No messages found", "Try another word or load earlier messages.") }
                }
                if (search == null) {
                    when {
                        !canSend -> Text(if (blocked) "You blocked this connection. Unblock them in conversation info." else if (chat.invitedIds.isEmpty()) "This invitation is closed. You can remove it from your inbox." else "Waiting for your invitation to be accepted.",
                            style = MaterialTheme.typography.bodyMedium, color = Muted, modifier = Modifier.fillMaxWidth().background(Color.White).padding(18.dp))
                        else -> Column(Modifier.background(Color.White)) {
                            if (busy) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = Gold, trackColor = GoldSoft)
                            AnimatedVisibility(mediaUri != null, enter = expandVertically(tween(180)) + fadeIn(), exit = shrinkVertically(tween(160)) + fadeOut()) {
                            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (mediaMime?.startsWith("video/") == true) Icon(Icons.Filled.Videocam, null, tint = GoldInk)
                                else AsyncImage(mediaUri, "Selected attachment", Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                                Text(if (mediaMime?.startsWith("video/") == true) "Video ready to send" else "Photo ready to send", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
                                IconButton({ mediaUri = null; mediaMime = null; uploaded = null; draftId = UUID.randomUUID().toString() }, enabled = !busy) { Icon(Icons.Filled.Close, "Remove attachment") }
                            }
                            }
                            Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.Bottom) {
                                CircleAction(Icons.Filled.Add, "Add attachment", { attachmentMenu = true }, gold = true, enabled = !busy)
                                OutlinedTextField(draft, { draft = it.take(4000); if (uploaded == null) draftId = UUID.randomUUID().toString() }, placeholder = { Text("Message…", style = MaterialTheme.typography.bodyLarge) },
                                    enabled = !busy, maxLines = 4, textStyle = MaterialTheme.typography.bodyLarge, shape = RoundedCornerShape(22.dp), colors = fieldColors(),
                                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp).testTag("message-draft"))
                                CircleAction(Icons.AutoMirrored.Filled.Send, "Send message", {
                                    if (!busy) scope.launch {
                                        busy = true; actionError = ""; progress = 0f
                                        try {
                                            withTimeout(5 * 60_000) {
                                                if (mediaUri != null && uploaded == null) uploaded = store.upload(context, chat.id, draftId, Uri.parse(mediaUri), mediaMime) { progress = it * .85f }
                                                store.send(chat.id, ChatDraft(draftId, draft, uploaded))
                                            }
                                            draft = ""; mediaUri = null; mediaMime = null; uploaded = null; draftId = UUID.randomUUID().toString(); progress = 1f
                                        } catch (_: TimeoutCancellationException) { actionError = "Sending took too long. Your draft is still here; retry to check whether it was sent." }
                                        catch (e: CancellationException) { throw e } catch (e: Exception) { actionError = messagesError(e) }
                                        finally { busy = false }
                                    }
                                }, gold = true, tag = "send-message", enabled = !busy && (draft.isNotBlank() || mediaUri != null))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ThreadHeader(title: String, subtitle: String, chat: CampusConversation, uid: String, onBack: () -> Unit, onInfo: (() -> Unit)? = null) {
    Surface(color = Color.White.copy(alpha = .96f), shadowElevation = 1.dp) {
        Box(Modifier.fillMaxWidth().heightIn(min = 76.dp).padding(horizontal = 12.dp, vertical = 10.dp)) {
            Box(Modifier.align(Alignment.CenterStart)) { CircleAction(Icons.AutoMirrored.Filled.ArrowBack, "Back", onBack) }
            Row(Modifier.align(Alignment.Center).fillMaxWidth().padding(horizontal = 52.dp).heightIn(min = 48.dp).clip(RoundedCornerShape(16.dp))
                .then(if (onInfo != null) Modifier.clickable(onClick = onInfo).testTag("conversation-info") else Modifier),
                horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleSmall, color = Ink, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(subtitle, style = MaterialTheme.typography.labelSmall, color = Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            if (onInfo != null) IconButton(onInfo, modifier = Modifier.align(Alignment.CenterEnd)) { Icon(Icons.Filled.Info, "Conversation info", tint = Muted) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MessageBubble(message: CampusMessage, mine: Boolean, sender: String?, store: MessagesStore, onMedia: () -> Unit, onLongPress: () -> Unit) {
    val shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp, bottomStart = if (mine) 20.dp else 5.dp, bottomEnd = if (mine) 5.dp else 20.dp)
    // Long press opens the message options (copy / unsend / delete for you); haptics confirm the press.
    val press = Modifier.combinedClickable(remember { MutableInteractionSource() }, indication = null,
        onLongClickLabel = "Message options", onLongClick = onLongPress, onClick = {})
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(Modifier.widthIn(max = 285.dp).fillMaxWidth(.88f), horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
            if (sender != null) Text(sender, style = MaterialTheme.typography.labelSmall, color = GoldInk, modifier = Modifier.padding(start = 8.dp, bottom = 4.dp))
            if (message.unsent) Surface(shape = shape, color = Color.Transparent, border = BorderStroke(1.dp, Line), modifier = Modifier.testTag("message-unsent")) {
                Text(when { mine -> "You unsent a message"; sender != null -> "$sender unsent a message"; else -> "This message was unsent" },
                    style = MaterialTheme.typography.bodyMedium, fontStyle = FontStyle.Italic, color = Muted,
                    modifier = press.padding(horizontal = 14.dp, vertical = 10.dp))
            }
            else Surface(shape = shape, color = if (mine) GoldSoft else Color.White, shadowElevation = .5.dp) {
                Column(press.testTag("message-${message.id}")) {
                    message.attachment?.let { AttachmentPreview(it, store, onMedia, onLongPress) }
                    if (message.text.isNotBlank()) Text(message.text, style = MaterialTheme.typography.bodyLarge, color = Ink, modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp))
                    MessageLinks(message.text)
                }
            }
            Text("${clockTime(message.createdAt)}${if (mine && !message.unsent) if (message.pending) " · Sending" else " · Sent" else ""}",
                style = MaterialTheme.typography.labelSmall, color = Muted, modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp))
        }
    }
}

@Composable
private fun MessageLinks(text: String) {
    val links = remember(text) { Regex("https?://[^\\s<>]+").findAll(text).map { it.value.trimEnd('.', ',', ')') }.distinct().toList() }
    val handler = LocalUriHandler.current
    var error by remember { mutableStateOf(false) }
    links.forEach { link -> TextButton(onClick = { try { handler.openUri(link) } catch (_: Exception) { error = true } }, contentPadding = PaddingValues(horizontal = 14.dp)) {
        Icon(Icons.Filled.OpenInNew, null, Modifier.size(14.dp)); Spacer(Modifier.width(6.dp)); Text(Uri.parse(link).host ?: "Open link", style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    } }
    if (error) Text("No app could open this link.", style = MaterialTheme.typography.bodySmall, color = Danger, modifier = Modifier.padding(12.dp))
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AttachmentPreview(attachment: ChatAttachment, store: MessagesStore, onOpen: () -> Unit, onLongPress: () -> Unit) {
    val context = LocalContext.current
    var uri by remember(attachment.path) { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf(false) }
    var retry by remember { mutableIntStateOf(0) }
    LaunchedEffect(attachment.path, retry) {
        error = false
        try { uri = store.mediaFile(context, attachment) } catch (e: CancellationException) { throw e } catch (_: Exception) { error = true }
    }
    Box(Modifier.fillMaxWidth().height(185.dp).clip(RoundedCornerShape(16.dp)).background(if (attachment.isVideo) Ink else GoldSoft)
        .combinedClickable(onLongClick = onLongPress, onLongClickLabel = "Message options") { if (error) retry++ else if (uri != null) onOpen() },
        contentAlignment = Alignment.Center) {
        when {
            error -> Text("Tap to retry attachment", style = MaterialTheme.typography.bodySmall, color = if (attachment.isVideo) Color.White else GoldInk)
            uri == null -> CircularProgressIndicator(Modifier.size(26.dp), color = Gold)
            attachment.isVideo -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.PlayCircle, "Play video", tint = Color.White, modifier = Modifier.size(52.dp))
                Text("Video · Tap to play", style = MaterialTheme.typography.labelMedium, color = Color.White)
            }
            else -> AsyncImage(uri, "Shared photo", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        }
    }
}

@Composable
private fun MediaDialog(message: CampusMessage, store: MessagesStore, onDismiss: () -> Unit) {
    val attachment = message.attachment ?: return
    val context = LocalContext.current
    var uri by remember { mutableStateOf<Uri?>(null) }
    var error by remember { mutableStateOf("") }
    LaunchedEffect(attachment.path) { try { uri = store.mediaFile(context, attachment) } catch (e: CancellationException) { throw e } catch (e: Exception) { error = messagesError(e) } }
    Dialog(onDismiss, DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color.Black) {
            Box(Modifier.fillMaxSize().safeDrawingPadding()) {
                if (error.isNotBlank()) Text(error, color = Color.White, modifier = Modifier.align(Alignment.Center).padding(24.dp))
                else if (uri == null) CircularProgressIndicator(Modifier.align(Alignment.Center), color = Gold)
                else if (attachment.isVideo) ChatVideo(uri!!, Modifier.fillMaxSize().padding(vertical = 64.dp))
                else AsyncImage(uri, "Shared photo", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                IconButton(onDismiss, Modifier.align(Alignment.TopEnd).padding(12.dp).background(Ink.copy(alpha = .7f), CircleShape)) { Icon(Icons.Filled.Close, "Close media", tint = Color.White) }
            }
        }
    }
}

@Composable
private fun ChatVideo(uri: Uri, modifier: Modifier) {
    val owner = LocalLifecycleOwner.current
    var view by remember { mutableStateOf<VideoView?>(null) }
    var failed by remember { mutableStateOf(false) }
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, event -> if (event == Lifecycle.Event.ON_PAUSE) view?.pause() }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer); view?.stopPlayback() }
    }
    Box(modifier, contentAlignment = Alignment.Center) {
        AndroidView(factory = { context -> VideoView(context).apply {
            setMediaController(MediaController(context).also { it.setAnchorView(this) }); setVideoURI(uri)
            setOnPreparedListener { seekTo(1) }; setOnErrorListener { _, _, _ -> failed = true; true }; view = this
        } }, modifier = Modifier.fillMaxSize(), onRelease = { it.stopPlayback() })
        if (failed) Text("This video couldn't play on your device.", color = Color.White, modifier = Modifier.padding(24.dp))
    }
}

@Composable
private fun ConversationInfo(chat: CampusConversation, prefs: ChatPreferences, uid: String, blocked: Boolean, busy: Boolean,
    onBack: () -> Unit, nickname: () -> Unit, search: () -> Unit, media: () -> Unit, mute: () -> Unit,
    report: () -> Unit, block: () -> Unit, remove: () -> Unit, leave: () -> Unit) {
    Column(Modifier.fillMaxSize().spotAmbientBackground(Canvas).verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            CircleAction(Icons.AutoMirrored.Filled.ArrowBack, "Back", onBack)
            Text("Conversation info", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 14.dp))
        }
        Surface(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), shape = RoundedCornerShape(26.dp), color = Color.White, border = BorderStroke(1.dp, Line)) {
            Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                ChatAvatar(chat.nameFor(uid), chat.people[chat.otherUid(uid)]?.photo.orEmpty(), chat.demo, chat.kind == "group", size = 84, uid = chat.otherUid(uid))
                Text(chat.nameFor(uid, prefs), style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 14.dp), color = Ink)
                Text(if (chat.demo) "Private sample conversation" else "Campus connection", style = MaterialTheme.typography.bodySmall, color = GoldInk, modifier = Modifier.padding(top = 4.dp))
                Row(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(Triple(Icons.Filled.Edit, "Nickname", nickname), Triple(Icons.Filled.Search, "Search", search), Triple(Icons.Filled.PhotoLibrary, "Media", media)).forEach { (icon, label, action) ->
                        Surface(onClick = action, shape = RoundedCornerShape(16.dp), color = GoldSoft, modifier = Modifier.weight(1f).heightIn(min = 76.dp), enabled = !busy) {
                            Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Icon(icon, null, tint = GoldInk, modifier = Modifier.size(22.dp)); Spacer(Modifier.height(6.dp)); Text(label, style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }
        }
        Text("Conversation", style = MaterialTheme.typography.labelLarge, color = Muted, modifier = Modifier.padding(start = 22.dp, top = 18.dp, bottom = 8.dp))
        InfoCard {
            InfoRow(Icons.Filled.NotificationsOff, "Mute in-app alerts", "Pause new-message banners", if (prefs.muted) "On" else "Off", enabled = !busy, onClick = mute)
            HorizontalDivider(color = Line)
            InfoRow(Icons.Filled.Edit, "Nickname", "Only visible to you", enabled = !busy, onClick = nickname)
            InfoRow(Icons.Filled.Search, "Search conversation", "Find words in loaded messages", onClick = search)
            InfoRow(Icons.Filled.PhotoLibrary, "Photos, videos & links", "Open everything shared here", onClick = media)
        }
        if (chat.kind == "group" && !chat.demo) {
            Text("Members", style = MaterialTheme.typography.labelLarge, color = Muted, modifier = Modifier.padding(start = 22.dp, top = 20.dp, bottom = 8.dp))
            InfoCard { chat.partyIds.forEach { personId ->
                val person = chat.people[personId]
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    ChatAvatar(person?.name ?: "Campus connection", person?.photo.orEmpty(), size = 36, uid = personId)
                    Text(person?.name ?: "Campus connection", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f).padding(start = 10.dp))
                    Text(if (personId in chat.memberIds) "Joined" else if (personId in chat.invitedIds) "Invited" else "Left", style = MaterialTheme.typography.labelSmall, color = Muted)
                }
            } }
        }
        Text("Privacy & support", style = MaterialTheme.typography.labelLarge, color = Muted, modifier = Modifier.padding(start = 22.dp, top = 20.dp, bottom = 8.dp))
        InfoCard {
            if (!chat.demo) InfoRow(Icons.Filled.Flag, "Report", "Describe inappropriate content or behavior", danger = true, enabled = !busy, onClick = report)
            if (!chat.demo && chat.kind == "direct") InfoRow(Icons.Filled.Block, if (blocked) "Unblock" else "Block", "Control direct messages from this person", danger = true, enabled = !busy, onClick = block)
            if (!chat.demo && chat.kind == "group") InfoRow(Icons.Filled.ExitToApp, "Leave collaboration", "Stop participating in this group", danger = true, enabled = !busy, onClick = leave)
            InfoRow(Icons.Filled.Archive, "Remove from inbox", "Hide this conversation until a new message", danger = true, enabled = !busy, onClick = remove)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = Color.White, border = BorderStroke(1.dp, Line), shape = RoundedCornerShape(22.dp)) { Column(content = content) }
}

@Composable
private fun InfoRow(icon: ImageVector, title: String, subtitle: String, trailing: String? = null, danger: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).background(if (danger) Danger.copy(alpha = .07f) else GoldSoft, RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = if (danger) Danger else GoldInk, modifier = Modifier.size(20.dp)) }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = if (danger) Danger else Ink)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Muted, modifier = Modifier.padding(top = 3.dp))
        }
        if (trailing != null) Text(trailing, style = MaterialTheme.typography.labelMedium, color = GoldInk)
        else Icon(Icons.Filled.ChevronRight, null, tint = Muted, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun SharedMediaPage(messages: List<CampusMessage>, onBack: () -> Unit, onOpen: (CampusMessage) -> Unit, more: Boolean, loading: Boolean, loadMore: () -> Unit) {
    val shared = messages.filter { it.attachment != null || it.text.contains(Regex("https?://")) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            CircleAction(Icons.AutoMirrored.Filled.ArrowBack, "Back", onBack)
            Text("Photos, videos & links", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(start = 12.dp))
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (shared.isEmpty()) item { MessageEmpty(Icons.Filled.PhotoLibrary, "Nothing shared yet", "Photos, videos and links appear here after they're sent.") }
            items(shared, key = { it.id }) { message ->
                Surface(shape = RoundedCornerShape(18.dp), color = Color.White, border = BorderStroke(1.dp, Line), onClick = { if (message.attachment != null) onOpen(message) }) {
                    Column(Modifier.fillMaxWidth().padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (message.attachment?.isVideo == true) Icons.Filled.PlayCircle else if (message.attachment != null) Icons.Filled.Image else Icons.Filled.Link, null, tint = GoldInk)
                            Column(Modifier.padding(start = 12.dp)) {
                                Text(message.attachment?.name?.ifBlank { "Photo" } ?: "Shared link", style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(dayLabel(message.createdAt), style = MaterialTheme.typography.bodySmall, color = Muted)
                            }
                        }
                        MessageLinks(message.text)
                    }
                }
            }
            if (more) item { TextButton(loadMore, enabled = !loading, modifier = Modifier.fillMaxWidth()) { if (loading) CircularProgressIndicator(Modifier.size(18.dp), color = Gold, strokeWidth = 2.dp) else Text("Load earlier messages") } }
        }
    }
}

private fun clockTime(time: Long) = if (time == 0L) "Now" else SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(time))
private fun dayKey(time: Long) = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(time))
private fun dayLabel(time: Long) = if (dayKey(time) == dayKey(System.currentTimeMillis())) "Today" else SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(time))
private fun shortTime(time: Long) = if (time == 0L) "Now" else if (dayKey(time) == dayKey(System.currentTimeMillis())) clockTime(time) else SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(time))
