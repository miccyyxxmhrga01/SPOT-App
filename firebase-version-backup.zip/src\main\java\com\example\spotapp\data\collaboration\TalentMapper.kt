package com.example.spot.data.collaboration

object TalentMapper {

    fun fromPrediction(prediction: String): String? {

        return when (prediction.trim().lowercase()) {

            "guitar",
            "guitarist" -> "Guitarist"

            "singing",
            "singer",
            "vocals",
            "vocal" -> "Singer"

            "drum",
            "drums",
            "drummer" -> "Drummer"

            "bass",
            "bassist" -> "Bassist"

            "piano",
            "pianist",
            "keyboard" -> "Pianist"

            "rap",
            "rapper",
            "rapping" -> "Rapper"

            "producer",
            "music producer",
            "production" -> "Producer"

            "dance",
            "dancing",
            "dancer" -> "Dancer"

            "photography",
            "photographer" -> "Photographer"

            "videography",
            "videographer" -> "Videographer"

            "model",
            "modeling" -> "Model"

            "makeup",
            "makeup artist" -> "Makeup Artist"

            "choreography",
            "choreographer" -> "Choreographer"

            else -> null
        }
    }
}