package com.example.spotapp.ui.theme.screens.discover

import com.example.spotapp.ui.theme.components.SpotLoading
import com.example.spotapp.ui.theme.components.SkeletonKind

import com.example.spotapp.ui.theme.components.LifecycleDisposableEffect

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.spotapp.data.*
import com.example.spotapp.ui.theme.models.SpotUiProfile
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.*

@Composable
internal fun CommunityDetails(id: String, isEvent: Boolean, profile: SpotUiProfile, close: () -> Unit, onProfile: (SpotUiProfile) -> Unit) {
    val repo = remember { DiscoverRepository.shared }
    val scope = rememberCoroutineScope()
    var group by remember { mutableStateOf<CampusGroup?>(null) }
    var event by remember { mutableStateOf<CampusEvent?>(null) }
    var joined by remember { mutableStateOf<Boolean?>(null) }
    var requested by remember { mutableStateOf<Boolean?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var revision by remember { mutableIntStateOf(0) }
    var peopleMode by rememberSaveable { mutableStateOf<String?>(null) }
    var clock by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(id) { while (true) { clock = System.currentTimeMillis(); delay(15_000) } }
    LifecycleDisposableEffect(id, isEvent, revision) {
        error = ""; loading = true; joined = null; requested = null
        val registrations = mutableListOf<com.google.firebase.firestore.ListenerRegistration>()
        val failed: (String) -> Unit = { error = it; loading = false }
        if (isEvent) registrations += repo.listenEvent(id, { event = it; loading = false }, failed)
        else { registrations += repo.listenGroup(id, { group = it; loading = false }, failed); registrations += repo.listenRequest(id, { requested = it }, failed) }
        registrations += repo.listenMembership(id, isEvent, { joined = it }, failed)
        onDispose { registrations.forEach { it.remove() } }
    }
    fun act(action: suspend () -> Unit) {
        if (busy) return
        busy = true; error = ""
        scope.launch { try { withTimeout(30_000) { action() } }
        catch (_: TimeoutCancellationException) { error = "The request took too long. Reconnect and retry." }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { error = if (e is IllegalStateException) e.message.orEmpty() else "Couldn't update your membership. Please retry." }
        finally { busy = false } }
    }
    CommunityWindow(if (isEvent) "Event" else "Group", close, busy) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).navigationBarsPadding(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (loading) item { LinearProgressIndicator(Modifier.fillMaxWidth(), color = CommunityGold) }
            item { CommunityError(error) { revision++ } }
            if (!loading && error.isBlank() && group == null && event == null) item { Text("This ${if (isEvent) "event" else "group"} is no longer available.") }
            group?.let { g ->
                item { CommunityCover(g.imageUrl, false, Modifier.fillMaxWidth().height(200.dp)) }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        CommunityBadge("${g.category} · ${g.privacy.replaceFirstChar { it.uppercase() }}")
                        Text(g.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text("${g.memberCount} members", style = MaterialTheme.typography.bodySmall, color = CommunityGold)
                        Text(g.description, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                item { OwnerRow(g.ownerName, g.ownerProfileImageUrl, "Owner · Admin", g.ownerId) { onProfile(SpotUiProfile(g.ownerId, g.ownerName, "", "", "", g.ownerProfileImageUrl)) } }
                item {
                    val owner = g.ownerId == profile.uid
                    if (owner) {
                        CommunityBadge("You own this group")
                        if (g.privacy == "private") OutlinedButton(onClick = { peopleMode = "requests" }, Modifier.fillMaxWidth()) { Text("Review join requests") }
                    } else Button(onClick = {
                        act { when { joined == true -> repo.setGroupJoined(id, false); requested == true -> repo.cancelRequest(id); g.privacy == "private" -> repo.requestJoin(id); else -> repo.setGroupJoined(id, true) } }
                    }, enabled = !busy && joined != null && requested != null && error.isBlank(), colors = ButtonDefaults.buttonColors(containerColor = CommunityGold), modifier = Modifier.fillMaxWidth()) {
                        Text(when { busy -> "Updating…"; joined == true -> "Leave group"; requested == true -> "Cancel join request"; g.privacy == "private" -> "Request to join"; else -> "Join group" })
                    }
                    if (g.privacy == "public" || joined == true) OutlinedButton(onClick = { peopleMode = "members" }, Modifier.fillMaxWidth()) { Text("See members") }
                    else Text(if (requested == true) "Your request is waiting for the owner's approval." else "The member list is visible after your request is approved.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                }
            }
            event?.let { e ->
                item { CommunityCover(e.imageUrl, true, Modifier.fillMaxWidth().height(220.dp)) }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        CommunityBadge(e.category)
                        Text(e.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        Text(eventDate(e.startsAt, "EEEE, MMM d, yyyy · h:mm a z"), style = MaterialTheme.typography.titleSmall, color = CommunityGold)
                        Text(e.location, style = MaterialTheme.typography.bodyMedium)
                        Text(e.description, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                item { OwnerRow(e.organizerName, e.organizerProfileImageUrl, "Organizer · ${e.organizer}", e.organizerId) { onProfile(SpotUiProfile(e.organizerId, e.organizerName, "", "", "", e.organizerProfileImageUrl)) } }
                item {
                    val full = e.participantLimit?.let { e.participantCount >= it } == true
                    val ended = e.startsAt <= clock
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("${e.participantCount} joined" + (e.participantLimit?.let { " · ${(it - e.participantCount).coerceAtLeast(0)} places left" } ?: " · Open registration"), style = MaterialTheme.typography.bodySmall)
                        if (joined == true) CommunityBadge("Your place is reserved")
                        Button(onClick = { act { repo.setEventJoined(id, joined != true) } }, enabled = !busy && joined != null && error.isBlank() && (joined == true || (!full && !ended)),
                            colors = ButtonDefaults.buttonColors(containerColor = CommunityGold), modifier = Modifier.fillMaxWidth()) {
                            Text(when { busy -> "Updating…"; joined == true -> "Cancel reservation"; ended -> "Registration closed"; full -> "Event full"; else -> "Join event" })
                        }
                        if (profile.uid == e.organizerId || joined == true) OutlinedButton(onClick = { peopleMode = "members" }, Modifier.fillMaxWidth()) { Text("See participants") }
                    }
                }
            }
        }
    }
    peopleMode?.let { mode ->
        CommunityPeople(id, isEvent, mode == "requests", close = { peopleMode = null }, onProfile = { peopleMode = null; onProfile(it) })
    }
}

@Composable
private fun OwnerRow(name: String, image: String, role: String, uid: String = "", open: () -> Unit) {
    Surface(onClick = open, color = Color.White, shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            CommunityAvatar(image, uid)
            Column { Text(name, style = MaterialTheme.typography.titleSmall); Text(role, style = MaterialTheme.typography.bodySmall, color = Color.Gray) }
        }
    }
}

@Composable
private fun CommunityPeople(id: String, isEvent: Boolean, requests: Boolean, close: () -> Unit, onProfile: (SpotUiProfile) -> Unit) {
    var people by remember { mutableStateOf(emptyList<CommunityMember>()) }
    var cursor by remember { mutableStateOf<DocumentSnapshot?>(null) }
    var more by remember { mutableStateOf(false) }
    var page by remember { mutableIntStateOf(0) }
    var revision by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    LaunchedEffect(id, page, revision) {
        loading = true; error = ""
        try {
            val result = DiscoverRepository.shared.people(id, isEvent, requests, if (page == 0) null else cursor)
            people = (if (page == 0) result.items else people + result.items).distinctBy { it.userId }
            cursor = result.cursor; more = result.hasMore
        } catch (e: CancellationException) { throw e } catch (_: Exception) { error = "This list couldn't load. Check your access and retry."; people = emptyList() }
        finally { loading = false }
    }
    CommunityWindow(if (requests) "Join requests" else if (isEvent) "Participants" else "Members", close, busy != null) { padding ->
        LazyColumn(Modifier.fillMaxSize().padding(padding).navigationBarsPadding(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item { TextButton(onClick = { page = 0; revision++ }) { Text("Refresh list") }; CommunityError(error) { page = 0; revision++ } }
            items(people, key = { it.userId }) { person ->
                Column {
                    OwnerRow(person.displayName, person.profileImageUrl, if (requests) "Requested to join" else if (person.role == "owner") "Owner · Admin" else "Member", person.userId) {
                        onProfile(SpotUiProfile(person.userId, person.displayName, "", "", "", person.profileImageUrl))
                    }
                    if (requests) Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        listOf(true, false).forEach { approve -> TextButton(onClick = {
                            if (busy == null) { busy = person.userId; scope.launch {
                                try { withTimeout(30_000) { DiscoverRepository.shared.reviewRequest(id, person.userId, approve) }; people = people.filterNot { it.userId == person.userId } }
                                catch (_: TimeoutCancellationException) { error = "Request timed out. Refresh to check its status." }
                                catch (e: CancellationException) { throw e } catch (_: Exception) { error = "Couldn't review this request. Please retry." }
                                finally { busy = null }
                            } }
                        }, enabled = busy == null) { Text(if (approve) "Approve" else "Decline") } }
                    }
                }
            }
            item {
                if (loading) SpotLoading(true, SkeletonKind.ROWS)
                else if (error.isBlank() && people.isEmpty()) Text(if (requests) "No pending requests" else "No participants yet", style = MaterialTheme.typography.bodyMedium)
                if (more && !loading) TextButton(onClick = { page++ }) { Text("Load more") }
            }
        }
    }
}
