package com.example.spotapp.ui.theme.screens.seeker

import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.spotapp.data.AccountType
import com.example.spotapp.ui.theme.components.*
import com.example.spotapp.ui.theme.models.SpotUiProfile
import com.example.spotapp.ui.theme.screens.discover.CommunityWindow
import com.example.spotapp.ui.theme.screens.settings.SavedPostsPage

/** Both roles retain the social feed. Their work actions reflect their actual account role. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun TalentHomePanel(profile: SpotUiProfile, onOpen: (String) -> Unit) {
    val seeker = profile.accountType == AccountType.TALENT_SEEKER
    if (!seeker) return
    Surface(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp).testTag("talent-home-panel"),
        color = SeekerIvory, shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Color(0xFFEDE1BF))) {
        Column(Modifier.background(Brush.linearGradient(listOf(Color(0xFFFFF2CF), SeekerIvory))).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.WorkOutline, null, Modifier.size(18.dp), tint = SeekerGold)
                Text(AccountType.TALENT_SEEKER.label.uppercase(), Modifier.padding(start = 8.dp),
                    style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = SeekerGold)
            }
            Text("Great talent. Your next event.",
                style = MaterialTheme.typography.titleMedium, color = SeekerInk)
            Text(profile.organization.ifBlank { "Discover campus creators and build your next collaboration." }, style = MaterialTheme.typography.bodySmall, color = SeekerMuted)
            if (seeker) Button({ onOpen("talent") }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = SeekerGold)) {
                Icon(Icons.Default.Search, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text("Find creators")
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                if (seeker) {
                    AssistChip({ onOpen("saved") }, { Text("Saved work") }, leadingIcon = { Icon(Icons.Default.BookmarkBorder, null, Modifier.size(16.dp)) })
                    AssistChip({ onOpen("events") }, { Text("My events") }, leadingIcon = { Icon(Icons.Default.Event, null, Modifier.size(16.dp)) })
                }
            }
        }
    }
}

@Composable
internal fun TalentWorkHub(profile: SpotUiProfile, initialPage: String, close: () -> Unit,
    onProfile: (SpotUiProfile) -> Unit, onMessage: (String) -> Unit) {
    var page by rememberSaveable { mutableStateOf(initialPage) }
    var invitee by remember { mutableStateOf<SpotUiProfile?>(null) }
    val seeker = profile.accountType == AccountType.TALENT_SEEKER
    val title = when (page) { "talent" -> "Find creators"; "events" -> "My events"; "saved" -> "Saved work";
        "requests" -> if (seeker) "Hiring requests" else "Your requests"; else -> "Jobs & auditions" }
    fun openProfile(person: SpotUiProfile) { close(); onProfile(person) }
    fun message(uid: String) { close(); onMessage(uid) }
    CommunityWindow(title, close) { padding ->
        CompositionLocalProvider(LocalSpotBottomContentPadding provides 24.dp) {
            AnimatedContent(page, modifier = Modifier.fillMaxSize().padding(padding).navigationBarsPadding(), label = "talent workspace") { selected ->
                when (selected) {
                    "talent" -> TalentDirectoryScreen(profile, ::openProfile, if (seeker) ({ invitee = it }) else null)
                    "events" -> WorkEvents(profile, ::openProfile)
                    "saved" -> SavedPostsPage(profile, ::openProfile)
                    "requests" -> WorkRequests(profile, onProfile = ::openProfile, onMessage = ::message)
                    else -> WorkOpportunities(profile, ::openProfile, ::message)
                }
            }
        }
    }
    invitee?.let { EventInviteDialog(profile, it, { invitee = null }, ::message) }
}

@Composable
internal fun WorkNotice(text: String, retry: (() -> Unit)? = null) {
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(text, style = MaterialTheme.typography.bodyMedium, color = SeekerMuted)
        if (retry != null) TextButton(retry) { Text("Retry", color = SeekerGold) }
    }
}

internal fun workDate(time: Long): String = java.text.SimpleDateFormat("MMM d, yyyy · h:mm a", java.util.Locale.getDefault()).format(java.util.Date(time))
