package com.example.spotapp

import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.platform.app.InstrumentationRegistry
import com.example.spotapp.data.*
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import java.util.UUID

/** Uses named emulator clients so the phone's real account and production content stay untouched. */
class ProfileStoryFirebaseIntegrationTest {
    @get:Rule val activity = ActivityScenarioRule(ComponentActivity::class.java)
    private data class Client(val app: FirebaseApp, val db: FirebaseFirestore, val auth: FirebaseAuth) {
        val profile = ProfileRepository(db, auth)
        val privacy = PrivacyRepository(db, auth)
        val stories = StoryRepository(db, auth)
    }
    private suspend fun connect(uid: String): Client {
        val app = FirebaseApp.initializeApp(InstrumentationRegistry.getInstrumentation().targetContext,
            FirebaseOptions.Builder().setProjectId("demo-spot-experience").setApplicationId("1:123456789:android:experiencetest")
                .setApiKey("fake-emulator-key").build(), "experience-${UUID.randomUUID()}")
        val auth = FirebaseAuth.getInstance(app).apply { useEmulator("127.0.0.1", 9095) }
        val db = FirebaseFirestore.getInstance(app).apply {
            firestoreSettings = FirebaseFirestoreSettings.Builder().setLocalCacheSettings(MemoryCacheSettings.newBuilder().build()).build()
            useEmulator("127.0.0.1", 8185)
        }
        auth.signInWithEmailAndPassword("$uid@example.test", "emulator-password-123").awaitSocial()
        return Client(app, db, auth)
    }
    @Test fun profileStoriesHighlightsApprovalAndSettingsPersistAcrossClients() = runBlocking<Unit> {
        activity.scenario.onActivity { it.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        withTimeout(150_000) {
            val owner = connect("sdk_owner"); val viewer = connect("sdk_viewer")
            val clients = mutableListOf(owner, viewer)
            val updates = Channel<SpotUser>(Channel.CONFLATED)
            val listener = viewer.profile.listen("sdk_owner", { if (it != null) updates.trySend(it) }, { updates.close(IllegalStateException(it)) })
            try {
                val photo = "https://res.cloudinary.com/jcuzzxsz/image/upload/v1/spot/profiles/sdk_owner/test/photo.jpg"
                val details = ProfileDetails(AccountType.STUDENT, "SDK Creator", "sdk_owner_updated", ProfileCourseOptions[4], listOf("Dancing"), bio = "A saved profile")
                owner.profile.save(details, photo, "she/her", "https://example.test", "")
                var identity = withTimeout(20_000) { updates.receive() }
                while (identity.profileImageUrl != photo) identity = withTimeout(20_000) { updates.receive() }
                assertEquals("sdk_owner_updated", identity.username); assertEquals(details.course, identity.course)
                assertEquals("A saved profile", identity.bio)
                owner.profile.save(details, "", "she/her", "https://example.test", "")
                do { identity = withTimeout(20_000) { updates.receive() } } while (identity.profileImageUrl.isNotEmpty())
                assertEquals("", identity.profileImageUrl)

                val storyId = "sdk-story-${UUID.randomUUID()}"
                val url = "https://res.cloudinary.com/jcuzzxsz/image/upload/v1/spot/stories/sdk_owner/$storyId/photo.jpg"
                owner.stories.createStory(storyId, url, false, "public")
                owner.stories.createStory(storyId, url, false, "public")
                val storyDoc = owner.db.document("stories/$storyId").get(Source.SERVER).awaitSocial()
                val created = storyDoc.getTimestamp("createdAt")!!.toDate().time
                val moment = StoryItem(storyId, "sdk_owner", url, "image", created)
                assertTrue(moment.active(created + STORY_LIFETIME - 1)); assertFalse(moment.active(created + STORY_LIFETIME))
                val media = listOf(HighlightMedia("story", storyId, 0, url, "image"))
                owner.stories.saveHighlight("sdk-highlight", "Campus", media, 0, "public")
                assertTrue(owner.stories.highlightSources().any { it.sourceId == storyId })
                owner.privacy.savePreferences(SpotPreferences("private", "followers", likes = false))

                // More than two query pages exercises resumable privacy migration and batched rule limits.
                owner.privacy.setPrivate(true)
                assertTrue(owner.db.document("users/sdk_owner").get(Source.SERVER).awaitSocial().getBoolean("isPrivate") == true)
                assertTrue(owner.db.collection("posts").whereEqualTo("userId", "sdk_owner").whereEqualTo("audience", "public").limit(30).get(Source.SERVER).awaitSocial().isEmpty)
                assertNotNull(runCatching { viewer.db.document("stories/$storyId").get(Source.SERVER).awaitSocial() }.exceptionOrNull())
                viewer.privacy.requestFollow("sdk_owner", true)
                owner.privacy.reviewRequest("sdk_viewer", true)
                assertEquals("followers", viewer.db.document("stories/$storyId").get(Source.SERVER).awaitSocial().getString("audience"))
                val visible = Channel<List<StoryHighlight>>(Channel.CONFLATED)
                val highlights = viewer.stories.listenHighlights("sdk_owner", true, { visible.trySend(it) }, { visible.close(IllegalStateException(it)) })
                try { assertEquals("Campus", withTimeout(20_000) { visible.receive() }.single().title) } finally { highlights.remove() }

                val restored = connect("sdk_owner"); clients.add(restored)
                assertEquals("A saved profile", restored.db.document("users/sdk_owner").get(Source.SERVER).awaitSocial().getString("bio"))
                assertFalse(restored.db.document("users/sdk_owner/settings/experience").get(Source.SERVER).awaitSocial().getBoolean("likes")!!)
                restored.stories.removeStory(storyId)
                assertTrue(restored.db.document("stories/$storyId").get(Source.SERVER).awaitSocial().getBoolean("deleted")!!)
                assertTrue(restored.db.document("users/sdk_owner/highlights/sdk-highlight").get(Source.SERVER).awaitSocial().exists())
                restored.stories.saveHighlight("sdk-highlight", "Saved moment", media, 0, "followers")
                restored.stories.removeHighlight("sdk-highlight")
                assertTrue(restored.db.collection("users/sdk_owner/highlights").limit(30).get(Source.SERVER).awaitSocial().isEmpty)
            } finally {
                listener.remove(); clients.forEach { it.db.terminate().awaitSocial(); it.app.delete() }
            }
        }
    }
}
