import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)

    // Keep Firebase temporarily while we migrate.
    id("com.google.gms.google-services")
}

val localProperties = Properties().apply {
    val localPropertiesFile = rootProject.file("local.properties")

    if (localPropertiesFile.exists()) {
        localPropertiesFile.inputStream().use {
            load(it)
        }
    }
}

val supabaseUrl =
    localProperties.getProperty("SUPABASE_URL")
        ?: error("SUPABASE_URL is missing from local.properties")

val supabasePublishableKey =
    localProperties.getProperty("SUPABASE_PUBLISHABLE_KEY")
        ?: error("SUPABASE_PUBLISHABLE_KEY is missing from local.properties")

android {
    namespace = "com.example.spotapp"

    compileSdk {
        version = release(37) {
            minorApiLevel = 1
        }
    }

    defaultConfig {
        applicationId = "com.example.spotapp"

        minSdk = 24
        targetSdk = 36

        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner =
            "androidx.test.runner.AndroidJUnitRunner"

        buildConfigField(
            "String",
            "SUPABASE_URL",
            "\"$supabaseUrl\""
        )

        buildConfigField(
            "String",
            "SUPABASE_PUBLISHABLE_KEY",
            "\"$supabasePublishableKey\""
        )
    }

    buildTypes {
        release {
            optimization {
                enable = false
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11

        // SPOT uses minSdk 24.
        // Supabase normally targets API 26+, so enable desugaring.
        isCoreLibraryDesugaringEnabled = true
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {

    // ---------------------------------------------------------
    // Compose
    // ---------------------------------------------------------

    implementation(platform(libs.androidx.compose.bom))

    implementation(libs.androidx.activity.compose)

    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.material3)

    implementation("androidx.compose.runtime:runtime")
    implementation("androidx.compose.material:material-icons-extended")

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)

    implementation(
        "androidx.lifecycle:lifecycle-runtime-compose:2.11.0"
    )

    // ---------------------------------------------------------
    // DataStore
    // ---------------------------------------------------------

    implementation(
        "androidx.datastore:datastore-preferences:1.1.1"
    )

    // ---------------------------------------------------------
    // SUPABASE
    //
    // We use Supabase for:
    // - Authentication
    // - PostgreSQL database
    // - Realtime
    //
    // We are NOT using Supabase Storage.
    // ---------------------------------------------------------

    implementation(
        platform(
            "io.github.jan-tennert.supabase:bom:3.2.6"
        )
    )

    implementation(
        "io.github.jan-tennert.supabase:auth-kt"
    )

    implementation(
        "io.github.jan-tennert.supabase:postgrest-kt"
    )

    implementation(
        "io.github.jan-tennert.supabase:realtime-kt"
    )

    // Required networking engine.
    // Supports WebSockets for Supabase Realtime.
    implementation(
        "io.ktor:ktor-client-okhttp:3.3.0"
    )

    coreLibraryDesugaring(
        "com.android.tools:desugar_jdk_libs:2.1.5"
    )

    // ---------------------------------------------------------
    // FIREBASE
    //
    // KEEP TEMPORARILY.
    // We will remove Auth/Firestore/Storage gradually.
    // ---------------------------------------------------------

    implementation(
        platform(
            "com.google.firebase:firebase-bom:34.11.0"
        )
    )

    implementation(
        "com.google.firebase:firebase-analytics"
    )

    implementation(
        "com.google.firebase:firebase-auth"
    )

    implementation(
        "com.google.firebase:firebase-firestore"
    )

    implementation(
        "com.google.firebase:firebase-storage"
    )

    implementation(
        "com.google.firebase:firebase-functions"
    )

    // ---------------------------------------------------------
    // Google Sign-In
    // ---------------------------------------------------------

    implementation(
        "androidx.credentials:credentials:1.6.0"
    )

    implementation(
        "androidx.credentials:credentials-play-services-auth:1.6.0"
    )

    implementation(
        "com.google.android.libraries.identity.googleid:googleid:1.2.0"
    )

    // ---------------------------------------------------------
    // Splash Screen
    // ---------------------------------------------------------

    implementation(
        "androidx.core:core-splashscreen:1.2.0"
    )

    // ---------------------------------------------------------
    // Coil - displaying images
    // ---------------------------------------------------------

    implementation(
        "io.coil-kt.coil3:coil-compose:3.4.0"
    )

    implementation(
        "io.coil-kt.coil3:coil-network-okhttp:3.4.0"
    )

    // ---------------------------------------------------------
    // Media3 - videos / reels
    // ---------------------------------------------------------

    implementation(
        "androidx.media3:media3-exoplayer:1.4.1"
    )

    implementation(
        "androidx.media3:media3-ui:1.4.1"
    )

    implementation("com.squareup.retrofit2:retrofit:2.11.0")
    implementation("com.squareup.retrofit2:converter-gson:2.11.0")

    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.11.0")

    // ---------------------------------------------------------
    // CLOUDINARY
    //
    // KEEP THIS.
    // Images + videos + reels stay on Cloudinary.
    // ---------------------------------------------------------

    implementation(
        "com.cloudinary:cloudinary-android:3.1.2"
    )

    // ---------------------------------------------------------
    // Testing
    // ---------------------------------------------------------

    testImplementation(libs.junit)

    androidTestImplementation(
        platform(libs.androidx.compose.bom)
    )

    androidTestImplementation(
        libs.androidx.compose.ui.test.junit4
    )

    androidTestImplementation(
        libs.androidx.espresso.core
    )

    androidTestImplementation(
        libs.androidx.junit
    )

    debugImplementation(
        libs.androidx.compose.ui.test.manifest
    )

    debugImplementation(
        libs.androidx.compose.ui.tooling
    )
}