package com.example.spotapp.ui.theme.screens.post

import com.example.spotapp.ui.theme.components.LifecycleDisposableEffect

import android.app.Activity
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.Saver
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.spotapp.data.*
import com.example.spotapp.ui.theme.models.SpotUiPost
import com.example.spotapp.ui.theme.models.SpotUiProfile
import kotlinx.coroutines.*
import java.util.UUID

/** The existing navigation entry point; all creation steps share one restorable draft. */
@Composable
fun NewPostScreen(profile: SpotUiProfile, onCancel: () -> Unit, onPostCreated: (SpotUiPost) -> Unit) {
    val context = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    val store = remember(profile.uid) { PostDraftStore(context, profile.uid) }
    val saver = remember { Saver<PostDraft, String>(save = { PostDraftCodec.encode(it) }, restore = { PostDraftCodec.decode(it) }) }
    var draft by rememberSaveable(profile.uid, stateSaver = saver) {
        mutableStateOf(store.load() ?: PostDraft("post-${UUID.randomUUID()}", "", emptyList(), emptyList(), emptyList(), "followers"))
    }
    var defaultsApplied by rememberSaveable(profile.uid) { mutableStateOf(store.load() != null) }
    LifecycleDisposableEffect(profile.uid) {
        val listener = PrivacyRepository.shared.listenPreferences({ preferences ->
            if (!defaultsApplied) {
                val audience = if ((profile.isPrivate || profile.privacyUpdating) && preferences.postAudience == "public") "followers" else preferences.postAudience
                draft = draft.copy(audience = audience); defaultsApplied = true
            }
        })
        onDispose { listener.remove() }
    }
    var step by rememberSaveable(profile.uid) { mutableStateOf(PostStep.PICKER) }
    val view = LocalView.current
    val activity = remember(view) { generateSequence(view.context) { (it as? ContextWrapper)?.baseContext }.filterIsInstance<Activity>().firstOrNull() }
    DisposableEffect(activity, step) {
        val controller = activity?.window?.let { WindowCompat.getInsetsController(it, it.decorView) }
        val previous = controller?.isAppearanceLightStatusBars
        controller?.isAppearanceLightStatusBars = step != PostStep.EDITOR
        onDispose { if (previous != null) controller?.isAppearanceLightStatusBars = previous }
    }
    var editingUri by rememberSaveable(profile.uid) { mutableStateOf(draft.mediaUris.firstOrNull().orEmpty()) }
    var publishing by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var progress by remember { mutableFloatStateOf(0f) }
    var error by rememberSaveable { mutableStateOf("") }
    var leave by remember { mutableStateOf(false) }
    val busy = publishing || saving
    fun changed(value: PostDraft) { if (!busy) { defaultsApplied = true; draft = if ((profile.isPrivate || profile.privacyUpdating) && value.audience == "public") value.copy(audience = "followers") else value; error = "" } }
    fun back() {
        if (busy) return
        focus.clearFocus()
        when (step) {
            PostStep.DETAILS -> step = if (draft.mediaUris.isEmpty()) PostStep.PICKER else PostStep.EDITOR
            PostStep.EDITOR -> step = PostStep.PICKER
            PostStep.PICKER -> if (draft.caption.isNotBlank() || draft.mediaUris.isNotEmpty() || draft.categories.isNotEmpty() || draft.tags.isNotEmpty() || draft.location.isNotBlank() || draft.taggedPeople.isNotEmpty()) leave = true else onCancel()
        }
    }
    fun saveAndClose(discard: Boolean = false) {
        if (busy) return
        focus.clearFocus(); saving = true
        val value = draft
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    if (discard) { store.clear(); PostMediaExporter.clear(context, profile.uid, value.id) }
                    else store.save(value)
                }
                onCancel()
            } catch (e: CancellationException) { throw e }
            catch (_: Exception) { error = "Couldn't save your draft. Please try again."; leave = false }
            finally { saving = false }
        }
    }
    fun publish() {
        if (busy) return
        val value = draft.copy(mediaEdits = draft.mediaEdits.filterKeys { it in draft.mediaUris })
        value.error()?.let { error = it; return }
        if (value.categories.isEmpty()) { error = "Select a talent category before posting."; return }
        focus.clearFocus(); publishing = true; error = ""; progress = 0f
        scope.launch {
            try {
                // Stable ID survives upload failures, process recreation, and lost acknowledgements.
                withContext(Dispatchers.IO) { store.save(value) }
                val post = withTimeout(300_000) { SpotPostsRepository.publish(context, value) { progress = it } }
                store.clear()
                withContext(Dispatchers.IO) { runCatching { PostMediaExporter.clear(context, profile.uid, value.id) } }
                onPostCreated(post.asUiPost())
            } catch (_: TimeoutCancellationException) { error = "Uploading took too long. Your draft is saved; please retry." }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { error = SpotPostsRepository.publishError(e) }
            finally { publishing = false }
        }
    }
    BackHandler { back() }
    AnimatedContent(step, modifier = Modifier.fillMaxSize(), transitionSpec = {
        val forward = targetState.ordinal > initialState.ordinal
        (slideInHorizontally(tween(230)) { if (forward) it / 5 else -it / 5 } + fadeIn(tween(180))) togetherWith
            (slideOutHorizontally(tween(230)) { if (forward) -it / 5 else it / 5 } + fadeOut(tween(150))) using SizeTransform(clip = false)
    }, label = "post creation step") { current ->
        when (current) {
            PostStep.PICKER -> PostMediaPicker(draft, ::changed, ::back, { step = PostStep.EDITOR }, { step = PostStep.DETAILS })
            PostStep.EDITOR -> PostMediaEditor(draft, ::changed, active = step == PostStep.EDITOR && !busy && !leave,
                back = ::back, add = { step = PostStep.PICKER }, next = { step = PostStep.DETAILS }, selection = editingUri, onSelection = { editingUri = it })
            PostStep.DETAILS -> PostDetailsScreen(profile, draft, ::changed, error, busy, ::back,
                edit = { focus.clearFocus(); step = PostStep.EDITOR }, save = { saveAndClose() }, publish = ::publish)
        }
    }
    if (leave) AlertDialog(onDismissRequest = { if (!busy) leave = false }, containerColor = PostIvory,
        title = { Text("Save this post for later?") }, text = { Text("Your media, edits and details will be kept on this device.") },
        confirmButton = { TextButton(onClick = { saveAndClose() }, enabled = !busy) { Text("Save draft", color = PostGold) } },
        dismissButton = { TextButton(onClick = { saveAndClose(discard = true) }, enabled = !busy) { Text("Discard", color = PostInk) } })
    if (publishing) Dialog(onDismissRequest = {}, properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)) {
        Surface(shape = RoundedCornerShape(24.dp), color = Color.White) {
            Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(when { progress < .05f -> "Preparing your media"; progress < .95f -> "Uploading your post"; else -> "Publishing your post" }, style = MaterialTheme.typography.titleMedium)
                LinearProgressIndicator(progress = { progress }, color = PostGold, trackColor = PostLine, modifier = Modifier.fillMaxWidth())
                Text("${(progress * 100).toInt()}% · Keep SPOT open", style = MaterialTheme.typography.bodySmall, color = PostMuted)
            }
        }
    }
}
