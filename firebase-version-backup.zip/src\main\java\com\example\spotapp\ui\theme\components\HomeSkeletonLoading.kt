package com.example.spotapp.ui.theme.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp


@Composable
fun HomeSkeletonLoading() {

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                horizontal = 16.dp,
                vertical = 14.dp
            )
    ) {

        repeat(3) {

            HomePostSkeleton()

            Spacer(
                modifier =
                    Modifier.height(
                        20.dp
                    )
            )
        }
    }
}


@Composable
private fun HomePostSkeleton() {

    Column(
        modifier =
            Modifier.fillMaxWidth()
    ) {

        Row(
            verticalAlignment =
                Alignment.CenterVertically
        ) {

            SkeletonBox(
                modifier =
                    Modifier.size(
                        42.dp
                    ),
                shape =
                    CircleShape
            )


            Spacer(
                modifier =
                    Modifier.width(
                        10.dp
                    )
            )


            Column {

                SkeletonBox(
                    modifier = Modifier
                        .width(
                            135.dp
                        )
                        .height(
                            13.dp
                        )
                )


                Spacer(
                    modifier =
                        Modifier.height(
                            6.dp
                        )
                )


                SkeletonBox(
                    modifier = Modifier
                        .width(
                            80.dp
                        )
                        .height(
                            9.dp
                        )
                )
            }
        }


        Spacer(
            modifier =
                Modifier.height(
                    12.dp
                )
        )


        SkeletonBox(
            modifier = Modifier
                .fillMaxWidth()
                .height(
                    280.dp
                ),
            shape =
                RoundedCornerShape(
                    10.dp
                )
        )


        Spacer(
            modifier =
                Modifier.height(
                    12.dp
                )
        )


        Row(
            horizontalArrangement =
                Arrangement.spacedBy(
                    12.dp
                )
        ) {

            repeat(3) {

                SkeletonBox(
                    modifier = Modifier
                        .width(
                            44.dp
                        )
                        .height(
                            18.dp
                        )
                )
            }
        }
    }
}


@Composable
private fun SkeletonBox(
    modifier: Modifier = Modifier,
    shape: Shape =
        RoundedCornerShape(
            10.dp
        )
) {

    val transition =
        rememberInfiniteTransition(
            label =
                "Skeleton"
        )


    val alpha by
    transition.animateFloat(

        initialValue =
            0.20f,

        targetValue =
            0.50f,

        animationSpec =
            infiniteRepeatable(

                animation =
                    tween(
                        durationMillis =
                            800
                    ),

                repeatMode =
                    RepeatMode.Reverse
            ),

        label =
            "SkeletonAlpha"
    )


    Box(
        modifier =
            modifier.background(
                color =
                    Color.Gray.copy(
                        alpha =
                            alpha
                    ),
                shape =
                    shape
            )
    )
}