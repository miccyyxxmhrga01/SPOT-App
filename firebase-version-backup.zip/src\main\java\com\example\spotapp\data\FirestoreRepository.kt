package com.example.spotapp.data

import com.google.firebase.firestore.FirebaseFirestore

object FirestoreRepository {
    private val db = FirebaseFirestore.getInstance()

    fun saveUserProfile(userId: String, name: String, email: String) {
        val userMap = hashMapOf(
            "name" to name,
            "email" to email
        )

        db.collection("users")
            .document(userId)
            .set(userMap)
            .addOnSuccessListener {
                // saved successfully
            }
            .addOnFailureListener { e ->
                // handle error
            }
    }
}