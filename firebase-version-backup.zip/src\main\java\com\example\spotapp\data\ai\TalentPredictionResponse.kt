package com.example.spotapp.data.ai

import com.google.gson.annotations.SerializedName

data class TalentPredictionResponse(
    @SerializedName("success")
    val success: Boolean = false,

    @SerializedName("prediction")
    val prediction: String = "",

    @SerializedName("raw_class")
    val rawClass: String = "",

    @SerializedName("spot_category")
    val spotCategory: String = "",

    @SerializedName("confidence")
    val confidence: Double = 0.0,

    @SerializedName("confidence_percent")
    val confidencePercent: Double = 0.0,

    @SerializedName("recognized_talent")
    val recognizedTalent: Boolean = false,

    @SerializedName("needs_user_confirmation")
    val needsUserConfirmation: Boolean = true,

    @SerializedName("message")
    val message: String = "",

    @SerializedName("suggestions")
    val suggestions: List<TalentSuggestion> = emptyList()
)

data class TalentSuggestion(
    @SerializedName("tag")
    val tag: String = "",

    @SerializedName("raw_class")
    val rawClass: String = "",

    @SerializedName("spot_category")
    val spotCategory: String = "",

    @SerializedName("confidence")
    val confidence: Double = 0.0,

    @SerializedName("confidence_percent")
    val confidencePercent: Double = 0.0
)