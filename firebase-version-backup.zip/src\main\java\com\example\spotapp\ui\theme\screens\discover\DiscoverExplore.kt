package com.example.spotapp.ui.theme.screens.discover

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.example.spotapp.data.HomeRepository
import com.example.spotapp.data.PublishedPost
import com.example.spotapp.ui.theme.components.*
import com.example.spotapp.ui.theme.models.*
import com.example.spotapp.ui.theme.screens.home.*

@Composable
internal fun DiscoverExplore(profile: SpotUiProfile, onProfile: (SpotUiProfile) -> Unit, onReel: (SpotUiPost) -> Unit) {
    var posts by remember { mutableStateOf(HomeRepository.cachedRecent()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }
    var retry by remember { mutableIntStateOf(0) }
    var category by rememberSaveable { mutableStateOf("All") }
    var opened by remember { mutableStateOf<PublishedPost?>(null) }
    val hidden = remember { mutableStateListOf<String>() }
    LifecycleDisposableEffect(profile.uid, retry) {
        loading = true; error = ""
        val listener = HomeRepository.listenRecent({ posts = it; loading = false }, { error = it; loading = false })
        onDispose { listener.remove() }
    }
    val categories = listOf("All") + posts.flatMap { it.categories }.filter { it.isNotBlank() }.distinct().sorted()
    val filtered = posts.filter { it.id !in hidden && (category == "All" || category in it.categories) }
    val bottomInset = LocalSpotBottomContentPadding.current
    LazyVerticalGrid(GridCells.Adaptive(150.dp), Modifier.fillMaxSize().testTag("discover-feed"),
        contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 16.dp + bottomInset),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            LazyRow(contentPadding = PaddingValues(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                items(categories, key = { it }) { label ->
                    FilterChip(category == label, { category = label }, label = { Text(label) }, shape = RoundedCornerShape(14.dp),
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFFFF1CB), selectedLabelColor = Color(0xFF785B13)))
                }
            }
        }
        if (loading && posts.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { SpotLoading(true, SkeletonKind.GRID) }
        if (error.isNotBlank()) item(span = { GridItemSpan(maxLineSpan) }) {
            TextButton({ retry++ }, Modifier.padding(12.dp)) { Text("$error Tap to retry.", color = Color(0xFFAD8420)) }
        }
        if (!loading && error.isBlank() && filtered.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) {
            Text(if (category == "All") "No posts yet." else "No posts in $category yet.", style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF74746C), modifier = Modifier.padding(24.dp))
        }
        items(filtered, key = { it.id }) { post ->
            DiscoverMediaTile(post, onOpen = {
                val video = post.media.firstOrNull { it.isVideo }
                if (video != null) onReel(post.asUiPost().copy(mediaUri = video.url)) else opened = post
            }, onProfile = { onProfile(post.author) }, onHide = { hidden.add(post.id) }, modifier = Modifier.animateItem())
        }
    }
    opened?.let { ProfilePublishedPostViewer(it, onProfile, onReel, profile) { opened = null } }
}

@Composable
internal fun DiscoverMediaTile(post: PublishedPost, onOpen: () -> Unit, onProfile: () -> Unit,
    onHide: () -> Unit, modifier: Modifier = Modifier) {
    var menu by remember { mutableStateOf(false) }
    val media = post.media.firstOrNull { it.isVideo } ?: post.media.firstOrNull()
    Box(modifier.fillMaxWidth().aspectRatio(.78f).clip(RoundedCornerShape(16.dp))
        .background(Color(0xFFEEE7D8)).clickable(onClickLabel = if (media?.isVideo == true) "Open reel" else "Open post", onClick = onOpen)
        .testTag("discover-post-${post.id}")) {
        if (media != null) AsyncImage(media.previewUrl, post.caption.ifBlank { "${post.author.displayName}'s post" },
            Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(post.caption, Modifier.align(Alignment.Center).padding(18.dp), style = MaterialTheme.typography.titleSmall,
            color = Color(0xFF26251F), maxLines = 6, overflow = TextOverflow.Ellipsis)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = .2f), Color.Transparent, Color.Transparent, Color.Black.copy(alpha = .7f)))))
        if (media?.isVideo == true || post.media.size > 1) Icon(if (media?.isVideo == true) Icons.Filled.PlayArrow else Icons.Filled.Collections,
            if (media?.isVideo == true) "Video" else "Album", Modifier.align(Alignment.TopStart).padding(12.dp).size(19.dp), tint = Color.White)
        Box(Modifier.align(Alignment.TopEnd)) {
            SpotAnimatedIconButton(Icons.Filled.MoreVert, "Post options", { menu = true }, tint = Color.White)
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Not interested") }, onClick = { menu = false; onHide() })
            }
        }
        Row(Modifier.align(Alignment.BottomStart).fillMaxWidth().heightIn(min = 48.dp).clickable(onClick = onProfile).padding(horizontal = 10.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically) {
            SpotAvatar(post.author.profileImageUrl, "${post.author.displayName} profile", Modifier.size(24.dp), post.author.uid)
            Text("@${post.author.username.removePrefix("@")}", Modifier.padding(start = 6.dp), color = Color.White,
                style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
