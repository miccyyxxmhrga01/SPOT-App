package com.example.spotapp.data

import kotlinx.coroutines.*

import android.util.Log
import android.util.Patterns
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.SetOptions

object AuthRepository {

    private const val TAG = "SpotAuth"

    private val auth = FirebaseAuth.getInstance()

    private val firestore = FirebaseFirestore.getInstance()

    // Firebase Storage has been removed.
    //
    // Profile pictures are now uploaded to Cloudinary first.
    // Firestore only stores the returned Cloudinary URL.


    // =========================================================
    // LOGIN
    // =========================================================

    fun logIn(
        email: String,
        password: String,
        callback: (Boolean, String?) -> Unit
    ) {

        val cleanEmail = email.trim()

        if (!validEmail(cleanEmail)) {
            callback(
                false,
                "Enter a valid email address."
            )
            return
        }

        if (password.isEmpty()) {
            callback(
                false,
                "Enter your password."
            )
            return
        }

        auth.signInWithEmailAndPassword(
            cleanEmail,
            password
        )
            .addOnSuccessListener {
                callback(
                    true,
                    null
                )
            }
            .addOnFailureListener { error ->

                callback(
                    false,
                    errorText(
                        error,
                        "Could not sign in."
                    )
                )
            }
    }


    // =========================================================
    // PASSWORD RESET
    // =========================================================

    fun sendPasswordResetEmail(
        email: String,
        callback: (Boolean, String?) -> Unit
    ) {

        val cleanEmail = email.trim()

        if (!validEmail(cleanEmail)) {
            callback(
                false,
                "Enter a valid email address first."
            )
            return
        }

        auth.sendPasswordResetEmail(cleanEmail)
            .addOnSuccessListener {

                callback(
                    true,
                    "If this email has an account, a reset link will arrive shortly."
                )
            }
            .addOnFailureListener { error ->

                callback(
                    false,
                    errorText(
                        error,
                        "Could not send the reset link."
                    )
                )
            }
    }


    // =========================================================
    // CREATE ACCOUNT + EMAIL VERIFICATION
    // =========================================================

    fun createAccountAndSendVerification(
        fullName: String,
        email: String,
        password: String,
        callback: (Boolean, String?) -> Unit
    ) {

        createAccountOnly(
            fullName,
            email,
            password
        ) { success, error ->

            if (!success) {

                callback(
                    false,
                    error
                )

            } else {

                resendVerificationEmail(
                    callback
                )
            }
        }
    }


    // =========================================================
    // CREATE ACCOUNT
    // =========================================================

    fun createAccountOnly(
        fullName: String,
        email: String,
        password: String,
        callback: (Boolean, String?) -> Unit
    ) {

        val cleanName =
            fullName.trim()

        val cleanEmail =
            email.trim()

        when {

            !validEmail(cleanEmail) -> {

                callback(
                    false,
                    "Enter a valid email address."
                )

                return
            }

            password.length < 6 -> {

                callback(
                    false,
                    "Use at least 6 characters for your password."
                )

                return
            }
        }

        auth.createUserWithEmailAndPassword(
            cleanEmail,
            password
        )
            .addOnSuccessListener { result ->

                val user =
                    result.user

                if (user == null) {

                    callback(
                        false,
                        "The account could not be loaded."
                    )

                } else {

                    finishAccountCreation(
                        user,
                        cleanName,
                        callback
                    )
                }
            }
            .addOnFailureListener { error ->

                if (
                    error is
                            FirebaseAuthUserCollisionException
                ) {

                    /*
                     * A previous interrupted signup
                     * may already have created the account.
                     *
                     * Try signing into it.
                     */
                    auth.signInWithEmailAndPassword(
                        cleanEmail,
                        password
                    )
                        .addOnSuccessListener { result ->

                            val user =
                                result.user

                            if (user == null) {

                                callback(
                                    false,
                                    "The account could not be loaded."
                                )

                            } else {

                                finishAccountCreation(
                                    user,
                                    cleanName,
                                    callback
                                )
                            }
                        }
                        .addOnFailureListener {

                            callback(
                                false,
                                "This email already has an account. Sign in or reset your password."
                            )
                        }

                } else {

                    callback(
                        false,
                        errorText(
                            error,
                            "Could not create your account."
                        )
                    )
                }
            }
    }


    // =========================================================
    // FINISH ACCOUNT CREATION
    // =========================================================

    private fun finishAccountCreation(
        user: FirebaseUser,
        fullName: String,
        callback: (Boolean, String?) -> Unit
    ) {

        if (!sameUser(user.uid)) {

            callback(
                false,
                "The signed-in account changed. Please try again."
            )

            return
        }


        fun accountReady() {

            if (
                sameUser(user.uid)
            ) {

                callback(
                    true,
                    null
                )

            } else {

                callback(
                    false,
                    "The signed-in account changed. Please try again."
                )
            }
        }


        /*
         * Signup can temporarily store the name
         * in Firebase Authentication.
         */
        if (
            fullName.isNotBlank() &&
            user.displayName.isNullOrBlank()
        ) {

            val updates =
                UserProfileChangeRequest
                    .Builder()
                    .setDisplayName(fullName)
                    .build()

            user.updateProfile(updates)
                .addOnSuccessListener {

                    accountReady()
                }
                .addOnFailureListener { error ->

                    callback(
                        false,
                        errorText(
                            error,
                            "Could not save your name. Please retry."
                        )
                    )
                }

        } else {

            accountReady()
        }
    }


    // =========================================================
    // RESEND EMAIL VERIFICATION
    // =========================================================

    fun resendVerificationEmail(
        callback: (Boolean, String?) -> Unit
    ) {

        val user =
            auth.currentUser

        if (user == null) {

            callback(
                false,
                "Sign in before verifying your email."
            )

            return
        }

        if (!needsEmailVerification(user)) {

            callback(
                true,
                null
            )

            return
        }

        user.sendEmailVerification()
            .addOnSuccessListener {

                if (
                    sameUser(user.uid)
                ) {

                    callback(
                        true,
                        null
                    )

                } else {

                    callback(
                        false,
                        "The signed-in account changed. Please try again."
                    )
                }
            }
            .addOnFailureListener { error ->

                callback(
                    false,
                    errorText(
                        error,
                        "Could not send the verification link."
                    )
                )
            }
    }


    // =========================================================
    // CHECK EMAIL VERIFICATION
    // =========================================================

    fun checkEmailVerified(
        callback: (Boolean, String?) -> Unit
    ) {

        val user =
            auth.currentUser

        if (user == null) {

            callback(
                false,
                "Sign in before checking verification."
            )

            return
        }

        user.reload()
            .addOnSuccessListener accountRefreshed@{

                val refreshed =
                    auth.currentUser

                if (
                    refreshed == null ||
                    refreshed.uid != user.uid
                ) {

                    callback(
                        false,
                        "The signed-in account changed. Please sign in again."
                    )

                    return@accountRefreshed
                }


                if (
                    needsEmailVerification(refreshed)
                ) {

                    callback(
                        false,
                        "Open the verification link in your email, then tap the button again."
                    )

                    return@accountRefreshed
                }


                /*
                 * Refresh token so Firestore
                 * receives the newest auth claims.
                 */
                refreshed
                    .getIdToken(true)
                    .addOnSuccessListener tokenRefreshed@{

                        if (
                            !sameUser(refreshed.uid)
                        ) {

                            callback(
                                false,
                                "The signed-in account changed. Please try again."
                            )

                            return@tokenRefreshed
                        }

                        callback(
                            true,
                            null
                        )
                    }
                    .addOnFailureListener { error ->

                        callback(
                            false,
                            errorText(
                                error,
                                "Could not refresh your session. Please retry."
                            )
                        )
                    }
            }
            .addOnFailureListener { error ->

                callback(
                    false,
                    errorText(
                        error,
                        "Could not check verification. Check your connection."
                    )
                )
            }
    }


    // =========================================================
    // SIGN UP
    // =========================================================

    fun signUp(
        fullName: String,
        email: String,
        password: String,
        callback: (Boolean, String?) -> Unit
    ) = createAccountAndSendVerification(
        fullName,
        email,
        password,
        callback
    )


    // =========================================================
    // COMPLETE PROFILE
    // =========================================================
    //
    // IMPORTANT:
    //
    // profileImageUrl is now a Cloudinary URL.
    //
    // Example:
    //
    // https://res.cloudinary.com/jcuzzxsz/image/upload/...
    //
    // The actual image is already uploaded before
    // this function is called.
    // =========================================================

    fun completeProfile(
        profile: ProfileDetails,
        profileImageUrl: String?,
        callback: (Boolean, String?) -> Unit
    ) {
        val user = auth.currentUser
        if (user == null || needsEmailVerification(user)) { callback(false, "Sign in and verify your email first."); return }
        profile.validationError()?.let { callback(false, it); return }
        CoroutineScope(Dispatchers.Main.immediate).launch {
            try {
                withTimeout(30_000) { ProfileRepository.shared.save(profile, profileImageUrl, "", "", "", completing = true) }
                if (sameUser(user.uid)) callback(true, null) else callback(false, "Your account changed. Sign in again.")
            } catch (_: TimeoutCancellationException) { callback(false, "Profile save timed out. Retry.") }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { callback(false, if (e is IllegalArgumentException || e is IllegalStateException) e.message else errorText(e, "Couldn't save your profile. Retry.")) }
        }
    }


    // =========================================================
    // DETERMINE WHERE USER SHOULD GO
    // =========================================================

    fun checkUserDestination(
        callback: (String, String?) -> Unit
    ) {

        val user =
            auth.currentUser


        if (user == null) {

            callback(
                "LOGIN",
                null
            )

            return
        }


        if (
            needsEmailVerification(user)
        ) {

            callback(
                "EMAIL_VERIFICATION",
                null
            )

            return
        }


        firestore
            .collection("users")
            .document(user.uid)
            .get()
            .addOnSuccessListener profileLoaded@{ document ->

                if (
                    !sameUser(user.uid)
                ) {

                    callback(
                        "ERROR",
                        "The signed-in account changed. Please try again."
                    )

                    return@profileLoaded
                }


                if (
                    document.exists()
                ) {

                    val destination =
                        if (
                            document.getBoolean(
                                "profileCompleted"
                            ) == true
                        ) {

                            "HOME"

                        } else {

                            "PROFILE_SETUP"
                        }


                    if (
                        document.getBoolean(
                            "emailVerified"
                        ) != user.isEmailVerified
                    ) {

                        document.reference
                            .set(
                                mapOf(
                                    "emailVerified" to
                                            user.isEmailVerified,

                                    "verifiedAt" to
                                            FieldValue
                                                .serverTimestamp()
                                ),

                                SetOptions.merge()
                            )
                            .addOnSuccessListener {

                                if (
                                    sameUser(user.uid)
                                ) {

                                    callback(
                                        destination,
                                        null
                                    )

                                } else {

                                    callback(
                                        "ERROR",
                                        "The signed-in account changed. Please try again."
                                    )
                                }
                            }
                            .addOnFailureListener { error ->

                                callback(
                                    "ERROR",
                                    errorText(
                                        error,
                                        "Could not update your profile. Please retry."
                                    )
                                )
                            }

                    } else {

                        callback(
                            destination,
                            null
                        )
                    }

                } else if (
                    document.metadata.isFromCache
                ) {

                    callback(
                        "ERROR",
                        "Connect to the internet to load your profile for the first time."
                    )

                } else {

                    ensureUserDocument(
                        user,
                        user.displayName.orEmpty()
                    ) { complete, error ->

                        if (error != null) {

                            callback(
                                "ERROR",
                                error
                            )

                        } else {

                            callback(
                                if (complete) {
                                    "HOME"
                                } else {
                                    "PROFILE_SETUP"
                                },
                                null
                            )
                        }
                    }
                }
            }
            .addOnFailureListener { error ->

                callback(
                    "ERROR",
                    errorText(
                        error,
                        "Could not load your profile. Please retry."
                    )
                )
            }
    }


    // =========================================================
    // CREATE USER FIRESTORE DOCUMENT
    // =========================================================

    private fun ensureUserDocument(
        user: FirebaseUser,
        fullName: String,
        onResult: (
            profileComplete: Boolean,
            error: String?
        ) -> Unit
    ) {

        if (
            !sameUser(user.uid)
        ) {

            onResult(
                false,
                "The signed-in account changed. Please try again."
            )

            return
        }


        val reference =
            firestore
                .collection("users")
                .document(user.uid)


        /*
         * Transaction prevents a retry from
         * overwriting an already-completed profile.
         */
        firestore
            .runTransaction { transaction ->

                val existing =
                    transaction.get(reference)


                if (
                    existing.exists()
                ) {

                    existing.getBoolean(
                        "profileCompleted"
                    ) == true

                } else {

                    val name =
                        fullName
                            .trim()
                            .ifBlank {

                                user.displayName
                                    .orEmpty()
                            }


                    transaction.set(
                        reference,

                        hashMapOf<String, Any>(
                            "uid" to user.uid,

                            "fullName" to name,

                            "displayName" to name,

                            "email" to
                                    user.email.orEmpty(),

                            "username" to "",

                            "course" to "",

                            "talentCategories" to
                                    emptyList<String>(),

                            "bio" to "",

                            "profileImageUrl" to
                                    (
                                            user.photoUrl
                                                ?.toString()
                                                ?: ""
                                            ),

                            "emailVerified" to
                                    user.isEmailVerified,

                            "profileCompleted" to
                                    false,

                            "createdAt" to
                                    FieldValue
                                        .serverTimestamp()
                        )
                    )


                    false
                }
            }
            .addOnSuccessListener { complete ->

                if (
                    sameUser(user.uid)
                ) {

                    onResult(
                        complete,
                        null
                    )

                } else {

                    onResult(
                        false,
                        "The signed-in account changed. Please try again."
                    )
                }
            }
            .addOnFailureListener { error ->

                onResult(
                    false,
                    errorText(
                        error,
                        "Could not prepare your profile. Check your connection and retry."
                    )
                )
            }
    }


    // =========================================================
    // CURRENT USER HELPERS
    // =========================================================

    fun currentUserEmail(): String =
        auth.currentUser
            ?.email
            .orEmpty()


    fun currentUserDisplayName(): String =
        auth.currentUser
            ?.displayName
            .orEmpty()


    fun currentUserNeedsEmailVerification(): Boolean =
        auth.currentUser
            ?.let {
                needsEmailVerification(it)
            }
            ?: false


    fun isUserLoggedIn(): Boolean =
        auth.currentUser != null


    // =========================================================
    // LOG OUT
    // =========================================================

    fun logOut() {

        auth.signOut()
    }


    // =========================================================
    // HELPERS
    // =========================================================

    private fun sameUser(
        uid: String
    ): Boolean {

        return auth.currentUser
            ?.uid == uid
    }


    private fun needsEmailVerification(
        user: FirebaseUser
    ): Boolean {

        return user.providerData.any {
            it.providerId == "password"
        } &&
                !user.isEmailVerified
    }


    private fun validEmail(
        email: String
    ): Boolean {

        return Patterns
            .EMAIL_ADDRESS
            .matcher(email)
            .matches()
    }


    // =========================================================
    // ERROR HANDLING
    // =========================================================

    private fun errorText(
        error: Exception,
        fallback: String
    ): String {

        Log.w(
            TAG,
            fallback,
            error
        )


        return when (error) {

            is FirebaseNetworkException -> {

                "Check your internet connection and try again."
            }


            is FirebaseTooManyRequestsException -> {

                "Too many attempts. Wait a moment and try again."
            }


            is FirebaseAuthWeakPasswordException -> {

                "Choose a stronger password and try again."
            }


            is FirebaseFirestoreException -> {

                when (error.code) {

                    FirebaseFirestoreException
                        .Code
                        .PERMISSION_DENIED -> {

                        "SPOT could not access your profile. Please contact support if retrying does not help."
                    }


                    FirebaseFirestoreException
                        .Code
                        .NOT_FOUND -> {

                        "SPOT's profile service is not ready. Please try again later."
                    }


                    FirebaseFirestoreException
                        .Code
                        .UNAVAILABLE -> {

                        "We couldn't reach your profile. Check your connection and retry."
                    }


                    else -> fallback
                }
            }


            else -> fallback
        }
    }
}
