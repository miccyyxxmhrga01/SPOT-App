package com.example.spotapp.ui.theme.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

internal data class SpotSectionTab(val id: String, val label: String, val icon: ImageVector)

/** Compact categories retain accessible names and a visible label on long press. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun SpotSectionTabs(tabs: List<SpotSectionTab>, selected: String,
    onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().selectableGroup().padding(horizontal = 16.dp, vertical = 6.dp)) {
        tabs.forEach { tab ->
            val active = tab.id == selected
            val fill by animateColorAsState(if (active) Color(0xFFFFF1CB) else Color.Transparent, label = "section color")
            val tint by animateColorAsState(if (active) Color(0xFFAD8420) else Color(0xFF74746C), label = "section icon")
            val border by animateColorAsState(if (active) Color(0xFFE7D6A3) else Color.Transparent, label = "section border")
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                TooltipBox(
                    positionProvider = TooltipDefaults.rememberTooltipPositionProvider(TooltipAnchorPosition.Above),
                    tooltip = { PlainTooltip { Text(tab.label) } },
                    state = rememberTooltipState()
                ) {
                    Surface(color = fill, shape = RoundedCornerShape(16.dp), border = BorderStroke(1.dp, border)) {
                        Box(Modifier.size(48.dp).testTag("section-${tab.id}")
                            .selectable(active, role = Role.Tab, onClick = { onSelect(tab.id) })
                            .semantics { contentDescription = tab.label }, contentAlignment = Alignment.Center) {
                            Icon(tab.icon, contentDescription = null, modifier = Modifier.size(22.dp), tint = tint)
                        }
                    }
                }
            }
        }
    }
}
