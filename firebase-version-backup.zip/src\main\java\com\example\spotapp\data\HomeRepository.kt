package com.example.spotapp.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query

object HomeRepository {
    private val auth get() = FirebaseAuth.getInstance()
    private val firestore get() = FirebaseFirestore.getInstance()
    private val posts get() = firestore.collection("posts")
    fun currentUserId(): String? = auth.currentUser?.uid
    private var cacheUid: String? = null
    private var recentCache = emptyList<PublishedPost>()
    private var popularCache = emptyList<PublishedPost>()
    private val profileCache = linkedMapOf<String, List<PublishedPost>>()
    private fun checkCacheAccount() {
        if (cacheUid != currentUserId()) {
            cacheUid = currentUserId(); recentCache = emptyList(); popularCache = emptyList(); profileCache.clear()
        }
    }
    fun cachePublished(post: PublishedPost) {
        checkCacheAccount()
        if (post.author.uid != currentUserId()) return
        profileCache[post.author.uid] = (listOf(post) + profileCache[post.author.uid].orEmpty()).distinctBy { it.id }.take(30)
        if (post.audience == "public") recentCache = (listOf(post) + recentCache).distinctBy { it.id }.take(30)
    }
    fun cachedRecent(): List<PublishedPost> { checkCacheAccount(); return recentCache }
    fun cachedPopular(): List<PublishedPost> { checkCacheAccount(); return popularCache }
    fun cachedProfile(uid: String): List<PublishedPost> { checkCacheAccount(); return profileCache[uid].orEmpty() }

    fun listenVideos(after: com.google.firebase.firestore.DocumentSnapshot? = null,
        onResult: (SocialPage<PublishedPost>) -> Unit, onError: (String) -> Unit): ListenerRegistration {
        var query: Query = posts.whereEqualTo("audience", "public").whereEqualTo("mediaType", "video")
            .orderBy("createdAt", Query.Direction.DESCENDING)
        if (after != null) query = query.startAfter(after)
        return query.limit(30).addSnapshotListener { s, e ->
            if (e != null) onError("Reels couldn't load. Please retry.")
            else onResult(SocialPage(s?.documents.orEmpty().mapNotNull { PostDocumentMapper.published(it.id, it.data.orEmpty()) },
                s?.documents?.lastOrNull(), s?.size() == 30))
        }
    }

    fun listenPost(id: String, onResult: (PublishedPost?) -> Unit, onError: (String) -> Unit): ListenerRegistration =
        posts.document(id).addSnapshotListener { s, e ->
            if (e != null) onError("This post is unavailable or you no longer have access.")
            else onResult(s?.let { PostDocumentMapper.published(it.id, it.data.orEmpty()) })
        }

    fun listenRecent(onResult: (List<PublishedPost>) -> Unit, onError: (String) -> Unit): ListenerRegistration =
        listenPublished(posts.whereEqualTo("audience", "public")
            .orderBy("createdAt", Query.Direction.DESCENDING).limit(30), { checkCacheAccount(); recentCache = it; onResult(it) }, onError)

    fun listenPopular(onResult: (List<PublishedPost>) -> Unit, onError: (String) -> Unit): ListenerRegistration =
        listenPublished(posts.whereEqualTo("audience", "public").whereEqualTo("hasMedia", true)
            .orderBy("popularityScore", Query.Direction.DESCENDING)
            .orderBy("createdAt", Query.Direction.DESCENDING).limit(12), { checkCacheAccount(); popularCache = it; onResult(it) }, onError)

    fun listenProfilePosts(uid: String, onResult: (List<PublishedPost>) -> Unit,
        onError: (String) -> Unit = {}): ListenerRegistration {
        val account = currentUserId()
        var postsListener: ListenerRegistration? = null
        fun load(following: Boolean) {
            postsListener?.remove()
            val source = posts.whereEqualTo("userId", uid)
            val query = if (uid == account) source else if (following) source.whereIn("audience", listOf("public", "followers")) else source.whereEqualTo("audience", "public")
            postsListener = listenPublished(query.orderBy("createdAt", Query.Direction.DESCENDING).limit(30), {
                checkCacheAccount(); profileCache[uid] = it
                while (profileCache.size > 5) profileCache.remove(profileCache.keys.first())
                onResult(it)
            }, { profileCache.remove(uid); onResult(emptyList()); onError(it) })
        }
        load(false)
        val following = if (uid != account && account != null) firestore.collection("users").document(uid).collection("followers").document(account)
            .addSnapshotListener { s, e -> if (e == null) load(s?.exists() == true) } else null
        return ListenerRegistration { following?.remove(); postsListener?.remove() }
    }

    fun listenFollowingFeed(onResult: (List<PublishedPost>) -> Unit, onError: (String) -> Unit): ListenerRegistration? {
        val me = currentUserId() ?: return null
        val listeners = mutableListOf<ListenerRegistration>()
        val feeds = mutableMapOf<String, List<PublishedPost>>()
        val follows = firestore.collection("users").document(me).collection("following").orderBy("createdAt", Query.Direction.DESCENDING).limit(30)
            .addSnapshotListener { snapshot, error ->
                listeners.forEach { it.remove() }; listeners.clear(); feeds.clear(); onResult(emptyList())
                if (error != null) { onError("Following posts couldn't load."); return@addSnapshotListener }
                snapshot?.documents.orEmpty().forEach { document ->
                    listeners += listenPublished(posts.whereEqualTo("userId", document.id).whereEqualTo("audience", "followers")
                        .orderBy("createdAt", Query.Direction.DESCENDING).limit(10), { feeds[document.id] = it; onResult(feeds.values.flatten().sortedByDescending { p -> p.createdAt }.take(30)) }, onError)
                }
            }
        return ListenerRegistration { follows.remove(); listeners.forEach { it.remove() } }
    }

    private fun listenPublished(query: Query, onResult: (List<PublishedPost>) -> Unit,
        onError: (String) -> Unit): ListenerRegistration {
        val account = currentUserId()
        return query.addSnapshotListener { snapshot, error ->
            if (account != currentUserId()) return@addSnapshotListener
            if (error != null) onError("Posts couldn't load. Check your connection and retry.")
            else onResult(snapshot?.documents.orEmpty().mapNotNull { document ->
                PostDocumentMapper.published(document.id, document.data.orEmpty())
            })
        }
    }

    fun listenToUserPosts(uid: String, onResult: (List<SpotPost>) -> Unit): ListenerRegistration {
        val query = posts.whereEqualTo("userId", uid)
        val visible = if (uid == currentUserId()) query else query.whereEqualTo("audience", "public")
        return visible.orderBy("createdAt", Query.Direction.DESCENDING).limit(30).addSnapshotListener { snapshot, _ ->
            onResult(snapshot?.documents.orEmpty().mapNotNull { PostDocumentMapper.spotPost(it.id, it.data.orEmpty()) })
        }
    }

    fun listenToPosts(onResult: (List<SpotPost>) -> Unit, onError: (String) -> Unit): ListenerRegistration =
        posts.whereEqualTo("audience", "public").orderBy("createdAt", Query.Direction.DESCENDING).limit(30)
            .addSnapshotListener { snapshot, error ->
                if (error != null) onError("Posts couldn't load. Check your connection and retry.")
                else onResult(snapshot?.documents.orEmpty().mapNotNull { PostDocumentMapper.spotPost(it.id, it.data.orEmpty()) })
            }

    fun listenToCurrentUser(onResult: (SpotUser?) -> Unit): ListenerRegistration? =
        currentUserId()?.let { listenToUser(it, onResult) }

    fun listenToUser(uid: String, onResult: (SpotUser?) -> Unit): ListenerRegistration =
        firestore.collection(if (uid == currentUserId()) "users" else "publicProfiles").document(uid)
            .addSnapshotListener { document, error ->
                onResult(if (error == null && document?.exists() == true) documentToUser(uid, document.data.orEmpty()) else null)
            }

    fun listenToUsers(onResult: (List<SpotUser>) -> Unit): ListenerRegistration =
        firestore.collection("publicProfiles").limit(30).addSnapshotListener { snapshot, _ ->
            onResult(snapshot?.documents.orEmpty().map { documentToUser(it.id, it.data.orEmpty()) })
        }

    fun getUserStats(
        uid: String,
        callback: (
            followers: Int,
            likes: Long,
            posts: Int
        ) -> Unit
    ) {

        firestore
            .collection("users")
            .document(uid)
            .collection("followers")
            .get()
            .addOnSuccessListener {
                    followersSnapshot ->

                val followerCount =
                    followersSnapshot.size()


                firestore
                    .collection("posts")
                    .whereEqualTo(
                        "userId",
                        uid
                    )
                    .get()
                    .addOnSuccessListener {
                            postsSnapshot ->

                        val documents =
                            postsSnapshot.documents


                        val likes =
                            documents.sumOf {
                                    document ->

                                document.getLong(
                                    "likesCount"
                                ) ?: 0
                            }


                        callback(
                            followerCount,
                            likes,
                            documents.size
                        )
                    }
                    .addOnFailureListener {

                        callback(
                            followerCount,
                            0,
                            0
                        )
                    }
            }
            .addOnFailureListener {

                callback(
                    0,
                    0,
                    0
                )
            }
    }


    fun checkFollowing(
        targetUid: String,
        callback: (Boolean) -> Unit
    ) {

        val currentUid =
            auth.currentUser?.uid


        if (currentUid == null) {

            callback(false)

            return
        }


        firestore
            .collection("users")
            .document(targetUid)
            .collection("followers")
            .document(currentUid)
            .get()
            .addOnSuccessListener {

                callback(
                    it.exists()
                )
            }
            .addOnFailureListener {

                callback(false)
            }
    }


    fun toggleFollow(
        targetUid: String,
        currentlyFollowing: Boolean,
        callback: (
            Boolean,
            String?
        ) -> Unit
    ) {

        val currentUid =
            auth.currentUser?.uid


        if (currentUid == null) {

            callback(
                false,
                "You are not logged in."
            )

            return
        }


        if (
            currentUid ==
            targetUid
        ) {

            callback(
                false,
                "You cannot follow yourself."
            )

            return
        }


        val followerReference =
            firestore
                .collection("users")
                .document(targetUid)
                .collection("followers")
                .document(currentUid)


        val followingReference =
            firestore
                .collection("users")
                .document(currentUid)
                .collection("following")
                .document(targetUid)


        val batch =
            firestore.batch()


        if (currentlyFollowing) {

            batch.delete(
                followerReference
            )

            batch.delete(
                followingReference
            )

        } else {

            batch.set(
                followerReference,
                hashMapOf(
                    "uid" to currentUid,
                    "createdAt" to
                            FieldValue.serverTimestamp()
                )
            )


            batch.set(
                followingReference,
                hashMapOf(
                    "uid" to targetUid,
                    "createdAt" to
                            FieldValue.serverTimestamp()
                )
            )
        }


        batch.commit()
            .addOnSuccessListener {

                callback(
                    true,
                    null
                )
            }
            .addOnFailureListener {
                    error ->

                callback(
                    false,
                    error.localizedMessage
                        ?: "Follow action failed."
                )
            }
    }


    private fun documentToUser(
        uid: String,
        data: Map<String, Any?>
    ): SpotUser { return profileFrom(uid, data) }


    private fun stringList(
        value: Any?
    ): List<String> {

        return (value as? List<*>)
            ?.mapNotNull {
                it as? String
            }
            ?: emptyList()
    }
}
