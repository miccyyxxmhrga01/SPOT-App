package com.example.spotapp.data

import com.cloudinary.android.MediaManager
import com.example.spotapp.data.cloudinary.CloudinaryUploader
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.spotapp.ui.theme.models.SpotUiProfile
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object SpotPostsRepository {
    private val db get() = FirebaseFirestore.getInstance()
    private val auth get() = FirebaseAuth.getInstance()
    private val posts get() = db.collection("posts")

    fun listenPopular(onResult: (List<PublishedPost>) -> Unit, onError: (String) -> Unit): ListenerRegistration =
        HomeRepository.listenPopular(onResult, onError)

    fun listenRecent(onResult: (List<PublishedPost>) -> Unit, onError: (String) -> Unit): ListenerRegistration =
        HomeRepository.listenRecent(onResult, onError)

    fun listenOwn(onResult: (List<PublishedPost>) -> Unit, onError: (String) -> Unit = {}): ListenerRegistration? =
        auth.currentUser?.uid?.let { HomeRepository.listenProfilePosts(it, onResult, onError) }

    fun listenInteraction(id: String, onLiked: (Boolean) -> Unit): ListenerRegistration? {
        val uid = auth.currentUser?.uid ?: return null
        return posts.document(id).collection("interactions").document(uid)
            .addSnapshotListener { snapshot, error -> if (error == null) onLiked(snapshot?.getBoolean("liked") == true) }
    }

    suspend fun publish(context: Context, draft: PostDraft, progress: (Float) -> Unit): PublishedPost {
        draft.error()?.let { throw IllegalArgumentException(it) }
        val account = auth.currentUser ?: throw IllegalStateException("Sign in before posting.")
        val uid = account.uid
        val reference = posts.document(draft.id)
        // A retry after a lost acknowledgement returns the existing post, not a duplicate.
        val existing = reference.get(Source.SERVER).awaitPostTask()
        if (existing.exists()) return (parse(existing) ?: throw IllegalStateException("Could not restore your post.")).also { HomeRepository.cachePublished(it) }
        val user = db.collection("users").document(uid).get(Source.SERVER).awaitPostTask()
        check(user.getBoolean("profileCompleted") == true) { "Finish your profile before posting." }
        val author = mapOf(
            "displayName" to user.getString("displayName").orEmpty(),
            "username" to user.getString("username").orEmpty(),
            "talent" to (user.get("talentCategories") as? List<*>)?.filterIsInstance<String>()?.firstOrNull().orEmpty(),
            "course" to user.getString("course").orEmpty(),
            "profileImageUrl" to user.getString("profileImageUrl").orEmpty()
        )
        val uploads = withContext(Dispatchers.IO) {
            draft.mediaUris.mapIndexed { index, value ->
                val uri = Uri.parse(value)
                val type = context.contentResolver.getType(uri).orEmpty()
                require(type.startsWith("image/") || type.startsWith("video/")) { "Choose a supported photo or video." }
                val size = context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                    if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else -1L
                } ?: -1L
                require(size in 1..50L * 1024 * 1024) { "Each photo or video must be under 50 MB." }
                val exported = PostMediaExporter.export(context, uid, draft.id, value, draft.mediaEdits[value] ?: PostMediaEdit())
                val editedUri = Uri.parse(exported)
                val editedType = context.contentResolver.getType(editedUri).orEmpty()
                val editedSize = if (exported == value) size else context.contentResolver.query(editedUri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use {
                    if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else -1L
                } ?: -1L
                require(editedSize in 1..50L * 1024 * 1024) { "The edited file must be under 50 MB. Try a smaller file." }
                progress(.05f * (index + 1) / draft.mediaUris.size.coerceAtLeast(1))
                Triple(editedUri, editedType, editedSize)
            }
        }
        val totalBytes = uploads.sumOf { it.third }.coerceAtLeast(1)
        var uploadedBytes = 0L
        val media = mutableListOf<Map<String, String>>()
        for (upload in uploads) {
            check(auth.currentUser?.uid == uid) { "Your account changed. Sign in again before posting." }
            val (uri, type, size) = upload
            val url = suspendCancellableCoroutine<String> { continuation ->
                val requestId = CloudinaryUploader.uploadMedia(uri, "spot/posts/$uid/${draft.id}",
                    onSuccess = { if (continuation.isActive) continuation.resume(it) },
                    onError = { if (continuation.isActive) continuation.resumeWithException(IllegalStateException("Media upload failed. Please retry.")) },
                    onProgress = { bytes, total ->
                        val fraction = if (total > 0) bytes.toFloat() / total else 0f
                        progress((.05f + (uploadedBytes + size * fraction) / totalBytes * .9f).coerceIn(.05f, .95f))
                    })
                continuation.invokeOnCancellation { MediaManager.get().cancelRequest(requestId) }
            }
            uploadedBytes += size
            media.add(mapOf("url" to url, "contentType" to type, "storagePath" to "",
                "thumbnailUrl" to if (type.startsWith("video/")) cloudinaryVideoThumbnail(url) else ""))
        }
        check(auth.currentUser?.uid == uid) { "Your account changed. Sign in again before posting." }
        val data = mapOf(
            "userId" to uid, "author" to author, "caption" to draft.caption.trim(),
            "username" to author.getValue("username"), "displayName" to author.getValue("displayName"),
            "userProfileImageUrl" to author.getValue("profileImageUrl"),
            "talentCategory" to draft.categories.firstOrNull().orEmpty(),
            "mediaUrl" to media.firstOrNull()?.get("url").orEmpty(),
            "mediaType" to if (media.firstOrNull()?.get("contentType")?.startsWith("video/") == true) "video" else "image",
            "commentsCount" to 0L,
            "aiCaption" to draft.aiCaption, "aiTagged" to draft.aiTagged,
            "aiCategorySuggested" to draft.aiCategorySuggested,
            "categories" to draft.categories, "tags" to draft.tags.map { it.removePrefix("#") }.distinct(),
            "media" to media, "hasMedia" to media.isNotEmpty(), "audience" to if (draft.audience == "public" && (user.getBoolean("isPrivate") == true || user.getBoolean("privacyUpdating") == true)) "followers" else draft.audience,
            "location" to draft.location, "taggedPeople" to draft.taggedPeople,
            "likesCount" to 0L, "viewsCount" to 0L, "popularityScore" to 0L,
            "createdAt" to FieldValue.serverTimestamp()
        )
        // Do not remove uploaded files on an ambiguous commit failure: the post may already exist.
        reference.set(data).awaitPostTask()
        progress(1f)
        val published = parse(reference.get(Source.SERVER).awaitPostTask()) ?: throw IllegalStateException("Could not load your published post.")
        HomeRepository.cachePublished(published)
        return published
    }

    suspend fun setLiked(id: String, liked: Boolean) = updateInteraction(id, liked, false)
    suspend fun recordView(id: String) = updateInteraction(id, null, true)

    private suspend fun updateInteraction(id: String, liked: Boolean?, viewed: Boolean) {
        val uid = auth.currentUser?.uid ?: return
        val reference = posts.document(id)
        val interaction = reference.collection("interactions").document(uid)
        socialTransaction(db) { transaction ->
            val post = transaction.get(reference)
            val previous = transaction.get(interaction)
            check(post.exists()) { "This post is no longer available." }
            val oldLiked = previous.getBoolean("liked") == true
            val oldViewed = previous.getBoolean("viewed") == true
            val newLiked = liked ?: oldLiked
            val newViewed = oldViewed || (viewed && post.getString("userId") != uid)
            if (oldLiked == newLiked && oldViewed == newViewed) return@socialTransaction
            val recipient = post.getString("userId").orEmpty()
            val notification = db.collection("users").document(recipient).collection("notifications").document("like_${id}_$uid")
            val notify = !oldLiked && newLiked && recipient != uid
            // All reads precede writes, including a retry-safe, single notification per liker/post.
            val oldNotification = if (notify) transaction.get(notification) else null
            val account = if (notify && oldNotification?.exists() != true) transaction.get(db.collection("users").document(uid)) else null
            val likes = post.getLong("likesCount").orZero() + newLiked.asCount() - oldLiked.asCount()
            val views = post.getLong("viewsCount").orZero() + newViewed.asCount() - oldViewed.asCount()
            transaction.set(interaction, mapOf("liked" to newLiked, "viewed" to newViewed))
            transaction.update(reference, mapOf("likesCount" to likes, "viewsCount" to views,
                "popularityScore" to popularityScore(likes, views)))
            if (account != null) transaction.set(notification,
                notificationData("like", uid, account, id, "liked your post"))
        }
    }

    fun publishError(error: Exception): String = when (error) {
        is IllegalArgumentException, is IllegalStateException -> error.message ?: "Check your post and retry."
        else -> "Couldn't publish your post. Check your connection and retry."
    }

    private fun parse(document: DocumentSnapshot): PublishedPost? =
        PostDocumentMapper.published(document.id, document.data.orEmpty())

    private fun Long?.orZero() = this ?: 0L
    private fun Boolean.asCount() = if (this) 1L else 0L
}

private suspend fun <T> Task<T>.awaitPostTask(): T = suspendCancellableCoroutine { continuation ->
    addOnSuccessListener { if (continuation.isActive) continuation.resume(it) }
    addOnFailureListener { if (continuation.isActive) continuation.resumeWithException(it) }
    addOnCanceledListener { continuation.cancel(CancellationException("Request cancelled")) }
}
