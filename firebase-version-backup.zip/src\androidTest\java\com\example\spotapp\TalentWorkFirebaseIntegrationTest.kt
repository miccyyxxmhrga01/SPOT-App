package com.example.spotapp

import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.platform.app.InstrumentationRegistry
import com.example.spotapp.data.*
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test
import java.util.UUID

/** Named clients keep the phone's signed-in account and all production data untouched. */
class TalentWorkFirebaseIntegrationTest {
    @get:Rule val activity = ActivityScenarioRule(ComponentActivity::class.java)
    private data class Client(val app: FirebaseApp, val db: FirebaseFirestore, val auth: FirebaseAuth) {
        val work = WorkRepository(db, auth)
        val profiles = ProfileRepository(db, auth)
    }
    private suspend fun connect(uid: String): Client {
        val app = FirebaseApp.initializeApp(InstrumentationRegistry.getInstrumentation().targetContext,
            FirebaseOptions.Builder().setProjectId("demo-spot-work").setApplicationId("1:123456789:android:talentwork")
                .setApiKey("fake-emulator-key").build(), "work-${UUID.randomUUID()}")
        val auth = FirebaseAuth.getInstance(app).apply { useEmulator("127.0.0.1", 9095) }
        val db = FirebaseFirestore.getInstance(app).apply {
            firestoreSettings = FirebaseFirestoreSettings.Builder().setLocalCacheSettings(MemoryCacheSettings.newBuilder().build()).build()
            useEmulator("127.0.0.1", 8185)
        }
        auth.signInWithEmailAndPassword("$uid@example.test", "emulator-password-123").awaitSocial()
        return Client(app, db, auth)
    }
    @Test fun eventInvitationAndJobApplicationPersistAndReachTheOtherAccount() = runBlocking<Unit> {
        activity.scenario.onActivity { it.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) }
        withTimeout(150_000) {
            val seeker = connect("sdk_seeker"); val creator = connect("sdk_creator")
            val clients = mutableListOf(seeker, creator)
            val updates = Channel<List<TalentRequest>>(Channel.CONFLATED)
            val l = creator.work.listenRequests(false, result = { updates.trySend(it.items) }, error = { updates.close(IllegalStateException(it)) })
            try {
                val people = seeker.profiles.creators(category = "Dancing").items
                assertTrue(people.any { it.uid == "sdk_creator" }); assertTrue(people.all { it.accountType == AccountType.STUDENT })
                assertEquals("sdk_creator", seeker.profiles.creators("@sdk_creator").items.single().uid)
                val event = seeker.work.myEvents().items.first { it.eventId == "sdk_event_0" }
                seeker.work.invite(event, "sdk_creator", "Perform a five-minute dance at the campus festival.")
                var invitation: TalentRequest?
                do { invitation = withTimeout(20_000) { updates.receive() }.firstOrNull { it.sourceId == event.eventId } } while (invitation == null)
                assertEquals("pending", invitation.status)
                creator.work.respond(invitation, "accepted")
                val restored = connect("sdk_seeker"); clients.add(restored)
                assertEquals("accepted", restored.db.document("talentRequests/${invitation.id}").get(Source.SERVER).awaitSocial().getString("status"))
                assertNotNull(runCatching { seeker.work.invite(event, "sdk_creator", "A duplicate invitation should fail.") }.exceptionOrNull())
                val id = seeker.work.newOpportunityId()
                seeker.work.publish(id, OpportunityDraft("Campus dance audition", "audition", "Perform at our campus arts festival and share your availability.", "Dancing", "Campus stage", System.currentTimeMillis() + 86400000))
                val job = creator.work.opportunities(false).items.first { it.id == id }
                creator.work.apply(job, "I would love to perform. I'm available next week.")
                val applications = Channel<List<TalentRequest>>(Channel.CONFLATED)
                val a = seeker.work.listenRequests(true, opportunityId = id, result = { applications.trySend(it.items) }, error = { applications.close(IllegalStateException(it)) })
                try {
                    var rows = withTimeout(20_000) { applications.receive() }
                    while (rows.isEmpty()) rows = withTimeout(20_000) { applications.receive() }
                    assertEquals("sdk_creator", rows.single().creatorId)
                    seeker.work.respond(rows.single(), "declined")
                    assertEquals("declined", creator.db.document("talentRequests/${rows.single().id}").get(Source.SERVER).awaitSocial().getString("status"))
                } finally { a.remove() }
                // Each notification category queries its own records before pagination.
                for (kind in listOf("invitation", "application")) {
                    val inbox = Channel<List<TalentRequest>>(Channel.CONFLATED)
                    val listener = creator.work.listenRequests(false, result = { inbox.trySend(it.items) },
                        error = { inbox.close(IllegalStateException(it)) }, kind = kind)
                    try {
                        var matching = withTimeout(20_000) { inbox.receive() }
                        while (matching.isEmpty()) matching = withTimeout(20_000) { inbox.receive() }
                        assertTrue(matching.all { it.kind == kind })
                        assertEquals(if (kind == "invitation") event.eventId else id, matching.single().sourceId)
                    } finally { listener.remove() }
                }
                val reviews = Channel<List<TalentRequest>>(Channel.CONFLATED)
                val reviewListener = seeker.work.listenRequests(true, result = { reviews.trySend(it.items) },
                    error = { reviews.close(IllegalStateException(it)) }, kind = "application")
                try {
                    var matching = withTimeout(20_000) { reviews.receive() }
                    while (matching.isEmpty()) matching = withTimeout(20_000) { reviews.receive() }
                    assertTrue(matching.all { it.kind == "application" })
                } finally { reviewListener.remove() }
                seeker.work.close(id)
                assertFalse(creator.work.opportunities(false).items.any { it.id == id })
            } finally { l.remove(); clients.forEach { it.db.terminate().awaitSocial(); it.app.delete() } }
        }
    }
}
