package com.example.spotapp.ui.theme.screens.settings

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.spotapp.SignupPolicy
import com.example.spotapp.SignupPolicyDialog
import com.example.spotapp.data.*
import com.example.spotapp.ui.theme.components.*
import com.example.spotapp.ui.theme.models.SpotUiProfile
import com.example.spotapp.ui.theme.screens.home.ProfilePublishedPostViewer
import com.example.spotapp.ui.theme.screens.profile.ConnectedEditProfile
import com.example.spotapp.ui.theme.screens.profile.ConnectionsPage
import kotlinx.coroutines.*

private data class SettingsEntry(val section: String, val title: String, val icon: ImageVector, val page: String)
private val SettingsEntries = listOf(
    SettingsEntry("Account", "Edit profile", Icons.Default.Person, "edit"),
    SettingsEntry("Account", "Saved posts", Icons.Default.BookmarkBorder, "saved"),
    SettingsEntry("Privacy", "Account privacy", Icons.Default.Lock, "privacy"),
    SettingsEntry("Privacy", "Follow requests", Icons.Default.PersonAdd, "requests"),
    SettingsEntry("Privacy", "Blocked accounts", Icons.Default.Block, "blocked"),
    SettingsEntry("Preferences", "Notifications", Icons.Default.NotificationsNone, "notifications"),
    SettingsEntry("Security", "Sign-in & password", Icons.Default.Key, "security"),
    SettingsEntry("SPOT", "Help & about", Icons.Default.Info, "about"))

@Composable
fun SettingsScreen(onBack: () -> Unit, onLogout: () -> Unit, onAddProfile: () -> Unit = {},
    profile: SpotUiProfile? = null, onProfile: (SpotUiProfile) -> Unit = {}) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var current by remember(profile) { mutableStateOf(profile) }
    var page by rememberSaveable { mutableStateOf("settings") }
    var query by rememberSaveable { mutableStateOf("") }
    var prefs by remember { mutableStateOf(SpotPreferences()) }
    var loaded by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var notice by remember { mutableStateOf("") }
    var privateConfirmation by remember { mutableStateOf<Boolean?>(null) }
    var logout by remember { mutableStateOf(false) }
    var policy by remember { mutableStateOf<SignupPolicy?>(null) }
    var retry by remember { mutableIntStateOf(0) }
    val id = profile?.uid ?: HomeRepository.currentUserId().orEmpty()
    LifecycleDisposableEffect(id, retry) {
        error = ""
        val a = if (id.isNotBlank()) ProfileRepository.shared.listen(id, { current = it?.asProfileUi() ?: current }, { error = it }) else null
        val b = if (id.isNotBlank()) PrivacyRepository.shared.listenPreferences({ prefs = it; loaded = true }, { error = it }) else null
        onDispose { a?.remove(); b?.remove() }
    }
    fun back() { if (!busy) { if (page == "settings") onBack() else { page = "settings"; error = ""; notice = "" } } }
    BackHandler { back() }
    fun action(block: suspend () -> Unit) {
        if (busy) return
        busy = true; error = ""
        scope.launch {
            try { withTimeout(180_000) { block() } }
            catch (_: TimeoutCancellationException) { error = "Update timed out. Retry." }
            catch (e: CancellationException) { throw e }
            catch (_: Exception) { error = "Couldn't save changes. Retry." }
            finally { busy = false }
        }
    }
    fun save(next: SpotPreferences) = action { PrivacyRepository.shared.savePreferences(next) }
    AnimatedContent(page, transitionSpec = {
        (fadeIn(tween(170)) + slideInHorizontally(tween(220)) { if (targetState == "settings") -it / 8 else it / 8 }) togetherWith fadeOut(tween(120))
    }, label = "settings page") { shown ->
        val account = current
        when {
            shown == "edit" && account != null -> ConnectedEditProfile(account, { page = "settings" }, { page = "settings" })
            shown in listOf("requests", "blocked") && account != null -> ConnectionsPage(account, shown, { page = "settings" }, onProfile)
            else -> Surface(Modifier.fillMaxSize().spotAmbientBackground(Color(0xFFFFFCF6)), color = Color.Transparent) {
                Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                    Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(::back, enabled = !busy) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", Modifier.size(22.dp)) }
                        Text(if (shown == "settings") "Settings" else SettingsEntries.firstOrNull { it.page == shown }?.title.orEmpty(), style = MaterialTheme.typography.titleLarge)
                    }
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Color(0xFFAD8420))
                    if (error.isNotBlank()) Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(error, Modifier.weight(1f), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                        TextButton({ retry++ }) { Text("Retry") }
                    }
                    if (shown == "saved" && account != null) SavedPostsPage(account, onProfile)
                    else LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        when (shown) {
                            "settings" -> {
                                item {
                                    Surface(color = Color(0xFFFFF6DA), shape = RoundedCornerShape(18.dp)) {
                                        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                            SpotAvatar(account?.profileImageUrl, "Your profile", Modifier.size(44.dp), id)
                                            Column(Modifier.padding(start = 12.dp)) {
                                                Text(account?.displayName.orEmpty(), style = MaterialTheme.typography.titleSmall)
                                                Text(account?.username?.let { "@$it" }.orEmpty(), style = MaterialTheme.typography.bodySmall, color = Color(0xFF8A5C10))
                                            }
                                        }
                                    }
                                }
                                item { SpotSearchField(query, { query = it }, placeholder = "Search settings") }
                                val entries = SettingsEntries.filter { query.isBlank() || it.title.contains(query, true) || it.section.contains(query, true) }
                                if (entries.isEmpty()) item { Text("No results", Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium) }
                                entries.groupBy { it.section }.forEach { (section, rows) ->
                                    item { Text(section, Modifier.padding(start = 6.dp, top = 12.dp), style = MaterialTheme.typography.labelMedium, color = Color(0xFF707070)) }
                                    item { Surface(color = Color.White, shape = RoundedCornerShape(18.dp)) { Column { rows.forEachIndexed { index, entry ->
                                        SettingsRow(entry.title, entry.icon) { page = entry.page }
                                        if (index < rows.lastIndex) HorizontalDivider(Modifier.padding(start = 50.dp), color = Color(0xFFE5E5E5))
                                    } } } }
                                }
                                item { SettingsRow("Log out", Icons.AutoMirrored.Filled.Logout, danger = true) { logout = true } }
                            }
                            "privacy" -> {
                                item { SettingsSwitch("Private account", account?.isPrivate == true, !busy && account != null) { privateConfirmation = it } }
                                if (account?.privacyUpdating == true) item {
                                    Text("Privacy setup is unfinished.", style = MaterialTheme.typography.bodySmall)
                                    Button({ action { PrivacyRepository.shared.setPrivate(true) } }, enabled = !busy) { Text("Finish privacy setup") }
                                }
                                item { Text("Default audience", style = MaterialTheme.typography.titleSmall) }
                                item { AudiencePreference("Posts", prefs.postAudience, account?.isPrivate == true, loaded && !busy) { save(prefs.copy(postAudience = it)) } }
                                item { AudiencePreference("Stories", prefs.storyAudience, account?.isPrivate == true, loaded && !busy) { save(prefs.copy(storyAudience = it)) } }
                            }
                            "notifications" -> {
                                item { Text("Show in activity", style = MaterialTheme.typography.labelMedium, color = Color(0xFF707070)) }
                                item { SettingsSwitch("Likes", prefs.likes, loaded && !busy) { save(prefs.copy(likes = it)) } }
                                item { SettingsSwitch("Comments", prefs.comments, loaded && !busy) { save(prefs.copy(comments = it)) } }
                                item { SettingsSwitch("New followers", prefs.follows, loaded && !busy) { save(prefs.copy(follows = it)) } }
                            }
                            "security" -> {
                                item { Text(AuthRepository.currentUserEmail(), style = MaterialTheme.typography.bodyMedium) }
                                item { SettingsRow("Send password reset email", Icons.Default.Key) {
                                    if (!busy) { busy = true; AuthRepository.sendPasswordResetEmail(AuthRepository.currentUserEmail()) { ok, message -> busy = false; if (ok) notice = message.orEmpty() else error = message.orEmpty() } }
                                } }
                                if (notice.isNotBlank()) item { Text(notice, style = MaterialTheme.typography.bodySmall) }
                            }
                            "about" -> {
                                item { Text("SPOT", style = MaterialTheme.typography.titleLarge); Text("Campus talent & connections", style = MaterialTheme.typography.bodyMedium) }
                                item { SettingsRow("Terms of Service", Icons.Default.Description) { policy = SignupPolicy.TERMS } }
                                item { SettingsRow("Privacy Policy", Icons.Default.PrivacyTip) { policy = SignupPolicy.PRIVACY } }
                                item { SettingsRow("Share a problem report", Icons.Default.BugReport) {
                                    val report = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "SPOT problem report\n\nWhat happened:\n\nSteps to reproduce:\n\nAndroid ${android.os.Build.VERSION.RELEASE}") }
                                    runCatching { context.startActivity(Intent.createChooser(report, "Share report")) }.onFailure { error = "No sharing app is available." }
                                } }
                            }
                        }
                    }
                }
            }
        }
    }
    privateConfirmation?.let { private -> AlertDialog(onDismissRequest = { privateConfirmation = null }, title = { Text(if (private) "Make account private?" else "Make account public?") },
        text = { Text(if (private) "Existing public posts, stories and highlights will become follower-only. Current followers keep access; new followers need your approval." else "New followers won't need approval. Existing follower-only posts and highlights keep their audience.") },
        confirmButton = { TextButton({ privateConfirmation = null; action { PrivacyRepository.shared.setPrivate(private) } }) { Text("Confirm") } },
        dismissButton = { TextButton({ privateConfirmation = null }) { Text("Cancel") } }) }
    if (logout) AlertDialog(onDismissRequest = { logout = false }, title = { Text("Log out of SPOT?") },
        confirmButton = { TextButton(onLogout) { Text("Log out") } }, dismissButton = { TextButton({ logout = false }) { Text("Cancel") } })
    policy?.let { SignupPolicyDialog(it) { policy = null } }
}

@Composable
private fun SettingsRow(title: String, icon: ImageVector, danger: Boolean = false, action: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = action).padding(horizontal = 14.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, Modifier.size(20.dp), tint = if (danger) Color(0xFFD84A4A) else Color(0xFF8A5C10))
        Text(title, Modifier.weight(1f).padding(start = 12.dp), style = MaterialTheme.typography.bodyMedium, color = if (danger) Color(0xFFD84A4A) else Color(0xFF111111))
        if (!danger) Icon(Icons.Default.ChevronRight, null, Modifier.size(18.dp), tint = Color(0xFF707070))
    }
}
@Composable
private fun SettingsSwitch(title: String, value: Boolean, enabled: Boolean, change: (Boolean) -> Unit) {
    Surface(color = Color.White, shape = RoundedCornerShape(18.dp)) { Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium); Switch(value, change, enabled = enabled)
    } }
}
@Composable
private fun AudiencePreference(title: String, value: String, private: Boolean, enabled: Boolean, change: (String) -> Unit) {
    Column { Text(title, style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { (if (private) listOf("followers", "private") else listOf("public", "followers", "private")).forEach { option ->
            FilterChip(value == option || private && value == "public" && option == "followers", { change(option) }, label = { Text(audienceLabel(option)) }, enabled = enabled,
                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFFFFF6DA)))
        } }
    }
}

@Composable
internal fun SavedPostsPage(profile: SpotUiProfile, onProfile: (SpotUiProfile) -> Unit) {
    var ids by remember { mutableStateOf(emptyList<String>()) }
    val posts = remember { mutableStateMapOf<String, PublishedPost?>() }
    var loaded by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var retry by remember { mutableIntStateOf(0) }
    var opened by remember { mutableStateOf<PublishedPost?>(null) }
    LifecycleDisposableEffect(profile.uid, retry) {
        val l = PrivacyRepository.shared.listenSaved({ ids = it; loaded = true }, { error = it })
        onDispose { l.remove() }
    }
    LifecycleDisposableEffect(ids, retry) {
        posts.keys.toList().filterNot { it in ids }.forEach { posts.remove(it) }
        val listeners = ids.map { id -> HomeRepository.listenPost(id, { posts[id] = it }, { posts[id] = null }) }
        onDispose { listeners.forEach { it.remove() } }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        if (!loaded && error.isBlank()) item { SpotLoading(true) }
        if (error.isNotBlank()) item { TextButton({ error = ""; retry++ }) { Text("$error Retry") } }
        if (loaded && ids.isEmpty()) item { Text("No saved posts", style = MaterialTheme.typography.bodyMedium) }
        items(ids, key = { it }) { id ->
            val post = posts[id]
            if (post != null) Surface(onClick = { opened = post }, color = Color.White, shape = RoundedCornerShape(18.dp), modifier = Modifier.padding(vertical = 5.dp)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    SpotAvatar(post.author.profileImageUrl, post.author.displayName, Modifier.size(40.dp), post.author.uid)
                    Column(Modifier.padding(start = 12.dp)) { Text(post.author.displayName, style = MaterialTheme.typography.titleSmall); Text(post.caption.ifBlank { "View post" }, style = MaterialTheme.typography.bodyMedium, maxLines = 2) }
                }
            } else if (posts.containsKey(id)) Text("Post unavailable", Modifier.padding(14.dp), style = MaterialTheme.typography.bodySmall)
            else SpotLoading(true)
        }
    }
    opened?.let { ProfilePublishedPostViewer(it, onProfile, profile = profile) { opened = null } }
}
