package com.example.spotapp.ui.theme.screens.home

import com.example.spotapp.ui.theme.components.*
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.interaction.collectIsDraggedAsState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.boundsInWindow
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalAccessibilityManager
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.toSize
import androidx.lifecycle.compose.currentStateAsState
import androidx.compose.material.icons.outlined.PauseCircleOutline
import androidx.compose.material.icons.outlined.PlayCircleOutline

import android.content.Intent
import android.net.Uri
import android.widget.VideoView
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.items
import com.example.spotapp.data.HomeRepository
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import coil3.compose.AsyncImage
import com.example.spotapp.data.PublishedMedia
import com.example.spotapp.data.PublishedPost
import com.example.spotapp.data.SpotPostsRepository
import com.example.spotapp.ui.theme.models.SpotRoute
import com.example.spotapp.ui.theme.models.SpotUiPost
import com.example.spotapp.ui.theme.models.SpotUiProfile
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.absoluteValue

private val FeedGold = Color(0xFFAD8420)
private val FeedInk = Color(0xFF26251F)
private val FeedMuted = Color(0xFF74746C)

@Suppress("UNUSED_PARAMETER")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpotConnectedHomePage(
    profile: SpotUiProfile, post: SpotUiPost, storyImageUri: String?,
    onPostChanged: (SpotUiPost) -> Unit, onStoryChanged: (String) -> Unit,
    onNavigate: (SpotRoute) -> Unit, onProfileClick: (SpotUiProfile) -> Unit,
    onOpenReels: (SpotUiPost) -> Unit, showBottomNavigation: Boolean = true, onWorkOpen: (String) -> Unit = {}
) {
    var popular by remember { mutableStateOf(HomeRepository.cachedPopular()) }
    var recent by remember { mutableStateOf(HomeRepository.cachedRecent()) }
    var followingPosts by remember { mutableStateOf(emptyList<PublishedPost>()) }
    var own by remember { mutableStateOf(HomeRepository.cachedProfile(profile.uid)) }
    var loadingPopular by remember { mutableStateOf(true) }
    var loadingFeed by remember { mutableStateOf(true) }
    var popularError by remember { mutableStateOf("") }
    var feedError by remember { mutableStateOf("") }
    var retry by remember { mutableIntStateOf(0) }
    var opened by remember { mutableStateOf<PublishedPost?>(null) }
    var commentsFor by remember { mutableStateOf<PublishedPost?>(null) }
    var storyOverlay by remember { mutableStateOf(false) }
    var connectedStoryOverlay by remember { mutableStateOf(false) }
    val hidden = remember { mutableStateListOf<String>() }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val playback = remember { FeedPlayback() }
    val feed = (recent + own + followingPosts).distinctBy { it.id }.sortedByDescending { it.createdAt }.filterNot { it.id in hidden }

    LifecycleDisposableEffect(profile.uid, retry) {
        loadingPopular = true
        loadingFeed = true
        popularError = ""
        feedError = ""
        val popularListener = HomeRepository.listenPopular(
            { popular = it; loadingPopular = false; popularError = "" },
            { popularError = it; loadingPopular = false })
        val recentListener = HomeRepository.listenRecent(
            { recent = it; loadingFeed = false; feedError = "" },
            { feedError = it; loadingFeed = false })
        val followingListener = HomeRepository.listenFollowingFeed({ followingPosts = it }, { feedError = it })
        val ownListener = SpotPostsRepository.listenOwn(onResult = { own = it }, onError = { feedError = it })
        onDispose { popularListener.remove(); recentListener.remove(); ownListener?.remove(); followingListener?.remove() }
    }
    fun open(item: PublishedPost) {
        if (item.media.firstOrNull()?.isVideo == true) onOpenReels(item.asUiPost()) else opened = item
    }
    Box(Modifier.fillMaxSize().feedViewport(playback)) {
        SpotHomePage(profile, post, storyImageUri, onPostChanged, onStoryChanged, onNavigate, onProfileClick, onOpenReels,
            showBottomNavigation = showBottomNavigation, showPost = false,
            storiesContent = {
                com.example.spotapp.ui.theme.screens.seeker.TalentHomePanel(profile, onWorkOpen)
                ConnectedStories(profile, { connectedStoryOverlay = it }, onProfileClick)
            },
            contentAfterStories = {
                PopularPostsCarousel(popular, loadingPopular, popularError, { retry++ },
                    ::open, playback, opened == null && commentsFor == null && !storyOverlay && !connectedStoryOverlay)
                Spacer(Modifier.height(16.dp))
                Text("Your community", style = MaterialTheme.typography.titleMedium, color = FeedInk,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                when {
                    feedError.isNotBlank() -> TextButton(onClick = { retry++ }, modifier = Modifier.padding(horizontal = 10.dp)) {
                        Text(feedError, color = FeedGold)
                    }
                    loadingFeed && feed.isEmpty() -> SpotLoading(true, SkeletonKind.POST)
                    feed.isEmpty() -> Text("No posts yet.",
                        style = MaterialTheme.typography.bodyMedium, color = FeedMuted, modifier = Modifier.padding(16.dp))
                }
            }, feedContent = {
                items(feed, key = { it.id }) { item ->
                    ConnectedPostCard(item, playback, opened == null && commentsFor == null && !storyOverlay && !connectedStoryOverlay,
                        onProfileClick, { commentsFor = it }, { opened = it }, onOpenReels,
                        onHide = { hidden.add(item.id) }, modifier = Modifier.animateItem())
                    Spacer(Modifier.height(16.dp))
                }
            }, onOverlayVisible = { storyOverlay = it })
        SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter).padding(16.dp))
    }
    opened?.let { item ->
        ProfilePublishedPostViewer(item, onProfileClick = onProfileClick, onOpenReels = onOpenReels,
            profile = profile, onClose = { opened = null })
    }
    commentsFor?.let { item -> ConnectedCommentsSheet(item.id, profile, { commentsFor = null }, onProfileClick) }
}

@Composable
internal fun ProfilePublishedPostViewer(post: PublishedPost,
    onProfileClick: ((SpotUiProfile) -> Unit)? = null, onOpenReels: ((SpotUiPost) -> Unit)? = null,
    profile: SpotUiProfile? = null, onClose: () -> Unit) {
    var current by remember(post.id) { mutableStateOf(post) }
    var showComments by remember(post.id) { mutableStateOf(false) }
    var unavailable by remember(post.id) { mutableStateOf("") }
    LifecycleDisposableEffect(post.id) {
        val listener = HomeRepository.listenPost(post.id, {
            if (it != null) { current = it; unavailable = "" } else unavailable = "This post is no longer available."
        }, { unavailable = it })
        onDispose { listener.remove() }
    }
    if (unavailable.isNotBlank()) {
        AlertDialog(onDismissRequest = onClose, title = { Text("Post unavailable") }, text = { Text(unavailable) },
            confirmButton = { TextButton(onClose) { Text("Close") } })
        return
    }
    var liked by remember(post.id) { mutableStateOf<Boolean?>(null) }
    var pending by remember(post.id) { mutableStateOf(false) }
    var error by remember(post.id) { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    LifecycleDisposableEffect(post.id) {
        val listener = SpotPostsRepository.listenInteraction(post.id) { liked = it }
        onDispose { listener?.remove() }
    }
    PublishedPostViewer(current, liked == true, onLike = {
        if (!pending && liked != null) {
            pending = true
            scope.launch {
                try { SpotPostsRepository.setLiked(post.id, liked != true); error = "" }
                catch (cancelled: CancellationException) { throw cancelled }
                catch (_: Exception) { error = "Couldn't update your like. Please retry." }
                finally { pending = false }
            }
        }
    }, onClose = onClose, onProfileClick = { onClose(); onProfileClick?.invoke(current.author) }, error = error,
        onComment = { showComments = true }, playbackEnabled = !showComments, onOpenReels = onOpenReels,
        onQualifiedView = {
        try { SpotPostsRepository.recordView(post.id) }
        catch (cancelled: CancellationException) { throw cancelled }
        catch (_: Exception) { /* Reading a post does not depend on recording a view. */ }
    })
    if (showComments && profile != null) ConnectedCommentsSheet(post.id, profile, { showComments = false }, { author ->
        showComments = false; onClose(); onProfileClick?.invoke(author)
    })
}

@Composable
internal fun PopularPostsCarousel(posts: List<PublishedPost>, loading: Boolean, error: String,
    onRetry: () -> Unit, onOpen: (PublishedPost) -> Unit,
    playback: FeedPlayback? = null, playbackEnabled: Boolean = true, autoAdvanceMillis: Long = 6_000) {
    // The section is an auto-sliding carousel; with nothing popular yet it is hidden rather than showing a prompt.
    if (posts.isEmpty() && !loading && error.isBlank()) return
    var rotationPaused by rememberSaveable { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().testTag("popular-section")) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Popular on SPOT", style = MaterialTheme.typography.titleMedium, color = FeedInk)
            }
            if (posts.size > 1) SpotAnimatedIconButton(
                if (rotationPaused) Icons.Outlined.PlayCircleOutline else Icons.Outlined.PauseCircleOutline,
                if (rotationPaused) "Resume popular slideshow" else "Pause popular slideshow",
                { rotationPaused = !rotationPaused }, tint = FeedGold)
        }
        when {
            loading && posts.isEmpty() -> SpotLoading(true, SkeletonKind.CARDS)
            error.isNotBlank() && posts.isEmpty() -> FeedPlaceholder("Popular posts couldn't load", "Tap to try again.", "Retry", onRetry)
            else -> {
                val pager = rememberPagerState(pageCount = { posts.size })
                val dragged by pager.interactionSource.collectIsDraggedAsState()
                var held by remember { mutableStateOf(false) }
                var bounds by remember { mutableStateOf(Rect.Zero) }
                var clipped by remember { mutableStateOf(Rect.Zero) }
                val view = LocalView.current
                val lifecycle by LocalLifecycleOwner.current.lifecycle.currentStateAsState()
                val inset = with(LocalDensity.current) { LocalSpotBottomContentPadding.current.toPx() }
                val viewport = playback?.viewport ?: Rect(0f, 0f, view.width.toFloat(), view.height.toFloat())
                val usable = Rect(viewport.left, viewport.top, viewport.right, (viewport.bottom - inset).coerceAtLeast(viewport.top))
                val onScreen = carouselVisible(bounds, clipped, usable)
                val enabled = playbackEnabled && LocalSpotVideoEnabled.current && lifecycle.isAtLeast(Lifecycle.State.RESUMED)
                val canAdvance = enabled && onScreen && posts.size > 1 && !held && !dragged && !rotationPaused
                val timeout = LocalAccessibilityManager.current?.calculateRecommendedTimeoutMillis(autoAdvanceMillis,
                    containsIcons = true, containsText = true, containsControls = true) ?: autoAdvanceMillis
                LaunchedEffect(canAdvance, pager.settledPage, posts.map { it.id }, timeout) {
                    if (canAdvance) {
                        delay(timeout)
                        if (!pager.isScrollInProgress && pager.pageCount > 1) {
                            pager.animateScrollToPage((pager.settledPage + 1) % pager.pageCount,
                                animationSpec = tween(650, easing = FastOutSlowInEasing))
                        }
                    }
                }
                HorizontalPager(pager, contentPadding = PaddingValues(horizontal = 16.dp), pageSpacing = 12.dp,
                    key = { posts[it].id }, modifier = Modifier.fillMaxWidth().testTag("popular-carousel")
                        .semantics { stateDescription = "Popular ${pager.settledPage + 1} of ${posts.size}" }
                        .onGloballyPositioned { bounds = Rect(it.positionInWindow(), it.size.toSize()); clipped = it.boundsInWindow() }
                        .pointerInput(Unit) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false); held = true
                                try { waitForUpOrCancellation() } finally { held = false }
                            }
                        }) { index ->
                    val item = posts[index]
                    Box(Modifier.fillMaxWidth().height(200.dp)
                        .graphicsLayer {
                            val distance = ((pager.currentPage - index) + pager.currentPageOffsetFraction).absoluteValue.coerceIn(0f, 1f)
                            scaleY = 1f - distance * 0.045f
                            alpha = 1f - distance * 0.12f
                        }.clip(RoundedCornerShape(22.dp)).background(Color(0xFFE9E1CB))
                        .clickable(role = Role.Button, onClickLabel = "Open post by ${item.author.displayName}") { onOpen(item) }) {
                        val media = item.media.first()
                        val videoId = "popular:${item.id}"
                        if (media.isVideo && playback != null) SpotVideo(media.url,
                            playbackEnabled && pager.settledPage == index && playback.activeId == videoId,
                            Modifier.fillMaxSize().then(if (pager.settledPage == index) Modifier.feedVideo(playback, videoId) else Modifier),
                            onTap = { onOpen(item) })
                        else MediaThumbnail(media, Modifier.fillMaxSize())
                        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.82f)))))
                        Surface(Modifier.align(Alignment.TopStart).padding(14.dp), color = Color.Black.copy(alpha = 0.32f), shape = CircleShape) {
                            Icon(if (media.isVideo) Icons.Filled.PlayArrow else Icons.Outlined.PhotoLibrary, if (media.isVideo) "Video" else "Photo",
                                Modifier.padding(7.dp).size(17.dp), tint = Color.White)
                        }
                        if (media.isVideo) Icon(Icons.Filled.PlayArrow, "Play video", Modifier.align(Alignment.Center).size(44.dp), tint = Color.White)
                        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(16.dp)) {
                            Text(item.author.displayName, color = Color.White, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(item.caption.ifBlank { item.categories.joinToString(" · ") }, color = Color.White.copy(alpha = 0.9f),
                                style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(6.dp))
                            Text("${compactCount(item.likes)} ${if (item.likes == 1L) "like" else "likes"}  ·  ${compactCount(item.views)} ${if (item.views == 1L) "view" else "views"}", color = Color.White,
                                style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                if (posts.size > 1) Box(Modifier.fillMaxWidth().padding(top = 12.dp), contentAlignment = Alignment.Center) {
                    SpotPageIndicator(posts.size, pager.currentPage)
                }
            }
        }
    }
}

@Composable
private fun FeedPlaceholder(title: String, message: String, action: String, onClick: () -> Unit) {
    Surface(Modifier.padding(horizontal = 16.dp).fillMaxWidth(), color = Color(0xFFF9F6EC),
        shape = RoundedCornerShape(22.dp), border = BorderStroke(1.dp, Color(0xFFEAE1C8))) {
        Column(Modifier.padding(20.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = FeedInk)
            Spacer(Modifier.height(5.dp))
            Text(message, style = MaterialTheme.typography.bodyMedium, color = FeedMuted)
            TextButton(onClick = onClick, contentPadding = PaddingValues(0.dp)) { Text(action, color = FeedGold) }
        }
    }
}

@Composable
private fun MediaThumbnail(media: PublishedMedia, modifier: Modifier = Modifier) {
    val source = media.previewUrl
    Box(modifier.background(Brush.linearGradient(listOf(Color(0xFF938363), Color(0xFF39362F)))), contentAlignment = Alignment.Center) {
        Icon(if (media.isVideo) Icons.Filled.PlayArrow else Icons.Outlined.PhotoLibrary, null, Modifier.size(36.dp), tint = Color.White.copy(alpha = 0.5f))
        if (source.isNotBlank()) AsyncImage(source, if (media.isVideo) "Video preview" else "Post photo", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    }
}

@Composable
private fun PublishedPostMedia(post: PublishedPost, onOpen: () -> Unit) {
    val pager = rememberPagerState(pageCount = { post.media.size })
    Box(Modifier.fillMaxWidth().aspectRatio(1f)) {
        HorizontalPager(pager, modifier = Modifier.fillMaxSize()) { index ->
            Box(Modifier.fillMaxSize().clickable(role = Role.Button, onClickLabel = "Open post") { onOpen() }) {
                MediaThumbnail(post.media[index], Modifier.fillMaxSize())
                if (post.media[index].isVideo) Icon(Icons.Filled.PlayArrow, "Play video", Modifier.align(Alignment.Center).size(48.dp), tint = Color.White)
            }
        }
        if (post.media.size > 1) Surface(Modifier.align(Alignment.TopEnd).padding(12.dp), shape = CircleShape, color = Color.Black.copy(alpha = 0.5f)) {
            Text("${pager.currentPage + 1}/${post.media.size}", Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                color = Color.White, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun PublishedPostViewer(post: PublishedPost, liked: Boolean, onLike: () -> Unit, onClose: () -> Unit,
    onProfileClick: () -> Unit, error: String = "", onComment: () -> Unit = {}, playbackEnabled: Boolean = true,
    onOpenReels: ((SpotUiPost) -> Unit)? = null, onQualifiedView: suspend () -> Unit) {
    val owner = LocalLifecycleOwner.current
    var resumed by remember { mutableStateOf(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    val latestView by rememberUpdatedState(onQualifiedView)
    DisposableEffect(owner) {
        val observer = LifecycleEventObserver { _, _ -> resumed = owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) }
        owner.lifecycle.addObserver(observer)
        onDispose { owner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(post.id, resumed) { if (resumed) { delay(2000); latestView() } }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        SpotScreenEntrance(Modifier.fillMaxSize(), fullscreen = true) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF151511)) {
            Column(Modifier.fillMaxSize().safeDrawingPadding()) {
                Row(Modifier.fillMaxWidth().padding(end = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Close post", tint = Color.White) }
                    Column(Modifier.weight(1f).clickable(role = Role.Button, onClick = onProfileClick)) {
                        Text(post.author.displayName, color = Color.White, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("@${post.author.username}", color = Color.White.copy(alpha = 0.65f), style = MaterialTheme.typography.bodySmall)
                    }
                }
                val pager = rememberPagerState(pageCount = { post.media.size })
                if (error.isNotBlank()) Text(error, color = Color.White, style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
                if (post.media.isEmpty()) Box(Modifier.fillMaxWidth().weight(1f).padding(24.dp), contentAlignment = Alignment.Center) {
                    Text(post.caption, color = Color.White, style = MaterialTheme.typography.bodyLarge)
                } else HorizontalPager(pager, Modifier.fillMaxWidth().weight(1f)) { index ->
                    val media = post.media[index]
                    if (media.isVideo) key(media.url) { SpotVideo(media.url, playbackEnabled && resumed && pager.settledPage == index,
                        Modifier.fillMaxSize(), muted = false,
                        onTap = onOpenReels?.let { open -> { onClose(); open(post.asUiPost().copy(mediaUri = media.url)) } }) }
                    else AsyncImage(media.url, "Photo ${index + 1}", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    SpotAnimatedIconButton(if (liked) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        if (liked) "Unlike post" else "Like post", onLike, tint = if (liked) Color(0xFFEF7070) else Color.White, selected = liked)
                    Text(compactCount(post.likes), color = Color.White, style = MaterialTheme.typography.labelSmall)
                    SpotAnimatedIconButton(androidx.compose.material.icons.Icons.Outlined.ChatBubbleOutline, "Comments", onComment, tint = Color.White)
                    Text(compactCount(post.comments), color = Color.White, style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.weight(1f))
                    SpotPageIndicator(post.media.size, pager.currentPage, Modifier.padding(horizontal = 8.dp), dark = true)
                }
                if (post.media.isNotEmpty()) Text(post.caption, color = Color.White.copy(alpha = 0.85f), style = MaterialTheme.typography.bodyMedium,
                    maxLines = 3, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 20.dp, end = 20.dp, bottom = 18.dp))
            }
        }
    }
}
}

@Composable
internal fun PublishedVideo(url: String, active: Boolean) {
    SpotVideo(url, active, Modifier.fillMaxSize(), muted = false)
}

private fun compactCount(value: Long): String = when {
    value >= 1_000_000 -> String.format("%.1fM", value / 1_000_000f)
    value >= 1_000 -> String.format("%.1fK", value / 1_000f)
    else -> value.toString()
}

/** Advance only when the media card is mostly visible above the floating navigation. */
internal fun carouselVisible(bounds: Rect, clipped: Rect, viewport: Rect): Boolean {
    if (bounds.width <= 0 || bounds.height <= 0 || !clipped.overlaps(viewport)) return false
    val visible = clipped.intersect(viewport)
    return visible.width >= bounds.width * .8f && visible.height >= bounds.height * .75f
}
