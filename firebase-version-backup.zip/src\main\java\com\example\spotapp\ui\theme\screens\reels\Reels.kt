package com.example.spotapp.ui.theme.screens.reels

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.spotapp.data.*
import com.example.spotapp.ui.theme.components.*
import com.example.spotapp.ui.theme.models.*
import com.example.spotapp.ui.theme.screens.home.ConnectedCommentsSheet
import com.example.spotapp.ui.theme.screens.home.SocialAvatar
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Suppress("UNUSED_PARAMETER")
@Composable
fun ReelsScreen(posts: List<SpotUiPost>, initialPostId: String? = null, onBack: () -> Unit,
    onPostChanged: (SpotUiPost) -> Unit = {}, onComment: (SpotUiPost) -> Unit = {},
    profile: SpotUiProfile? = null, onProfileClick: (SpotUiProfile) -> Unit = {}) {
    BackHandler(onBack = onBack)
    val pages = remember(initialPostId) { mutableStateMapOf<Int, SocialPage<PublishedPost>>() }
    val cursors = remember(initialPostId) { mutableStateListOf<DocumentSnapshot?>(null) }
    var first by remember(initialPostId) { mutableStateOf<PublishedPost?>(null) }
    var firstResolved by remember(initialPostId) { mutableStateOf(initialPostId == null) }
    var error by remember(initialPostId) { mutableStateOf("") }
    var retry by remember { mutableIntStateOf(0) }
    var commentPost by remember { mutableStateOf<PublishedPost?>(null) }
    var muted by rememberSaveable { mutableStateOf(false) }
    var savedPage by rememberSaveable(initialPostId) { mutableIntStateOf(0) }
    var restored by remember(initialPostId) { mutableStateOf(false) }
    LifecycleDisposableEffect(initialPostId, retry) {
        val listener = initialPostId?.let { id -> HomeRepository.listenPost(id, {
            first = it?.takeIf { p -> p.media.any { m -> m.isVideo } }; firstResolved = true
            if (it == null) error = "This reel is no longer available."
        }, { error = it; firstResolved = true }) }
        onDispose { listener?.remove() }
    }
    cursors.forEachIndexed { index, cursor ->
        LifecycleDisposableEffect(initialPostId, cursor, retry) {
            val listener = HomeRepository.listenVideos(cursor, { page ->
                pages[index] = page
                if (index + 1 < cursors.size && page.cursor != null && cursors[index + 1]?.id != page.cursor.id) cursors[index + 1] = page.cursor
            }, { error = it })
            onDispose { listener.remove() }
        }
    }
    val feed = (listOfNotNull(first) + pages.toSortedMap().values.flatMap { it.items })
        .distinctBy { it.id }.filter { it.media.any { m -> m.isVideo } }
    val readyFeed = if (firstResolved) feed else emptyList()
    val pager = rememberPagerState(pageCount = { readyFeed.size })
    val last = pages[cursors.lastIndex]
    fun loadMore() { last?.cursor?.let { if (cursors.none { c -> c?.id == it.id }) cursors.add(it) } }
    LaunchedEffect(readyFeed.size, last, restored) {
        if (!restored && readyFeed.isNotEmpty()) {
            if (savedPage >= readyFeed.size && last?.hasMore == true) loadMore()
            else { pager.scrollToPage(savedPage.coerceAtMost(readyFeed.lastIndex)); restored = true }
        }
    }
    LaunchedEffect(pager.settledPage, restored) { if (restored) savedPage = pager.settledPage }
    LaunchedEffect(pager.settledPage, readyFeed.size, last?.cursor?.id) {
        if (pager.settledPage >= readyFeed.size - 3 && last?.hasMore == true) loadMore()
    }
    Box(Modifier.fillMaxSize().background(Color.Black).testTag("reels-screen")) {
        if (readyFeed.isNotEmpty()) VerticalPager(pager, Modifier.fillMaxSize(), key = { readyFeed[it].id }, beyondViewportPageCount = 1) { index ->
            val post = readyFeed[index]
            val selectedUrl = posts.firstOrNull { it.id == initialPostId }?.mediaUri
            val media = post.media.firstOrNull { post.id == initialPostId && it.url == selectedUrl && it.isVideo }
                ?: post.media.first { it.isVideo }
            ReelPage(post, media.url, restored && pager.settledPage == index && !pager.isScrollInProgress && commentPost == null,
                muted, { muted = !muted }, { commentPost = post }, onProfileClick)
        } else Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (!firstResolved || (pages.isEmpty() && error.isBlank())) SpotLoading(true, SkeletonKind.POST)
            else Text(if (error.isBlank()) "No public videos yet" else error, color = Color.White, style = MaterialTheme.typography.bodyMedium)
        }
        Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
            Text("Reels", style = MaterialTheme.typography.titleMedium, color = Color.White)
        }
        if (error.isNotBlank()) Surface(Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 54.dp), color = Color.Black.copy(alpha = 0.65f)) {
            TextButton({ error = ""; retry++ }) { Text("$error Retry", style = MaterialTheme.typography.bodySmall, color = Color.White) }
        }
    }
    commentPost?.let { item ->
        if (profile != null) ConnectedCommentsSheet(item.id, profile, { commentPost = null }, onProfileClick)
        else LaunchedEffect(item.id) { onComment(item.asUiPost()); commentPost = null }
    }
}

@Composable
private fun ReelPage(post: PublishedPost, url: String, active: Boolean, muted: Boolean, toggleMuted: () -> Unit,
    onComment: () -> Unit, onProfile: (SpotUiProfile) -> Unit) {
    var liked by remember(post.id) { mutableStateOf<Boolean?>(null) }
    var saved by remember(post.id) { mutableStateOf(false) }
    var pending by remember(post.id) { mutableStateOf(false) }
    var error by remember(post.id) { mutableStateOf("") }
    var expandedCaption by remember(post.id) { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    LifecycleDisposableEffect(post.id) {
        val like = SpotPostsRepository.listenInteraction(post.id) { liked = it }
        val save = SocialRepository.shared.listenSaved(post.id) { saved = it }
        onDispose { like?.remove(); save.remove() }
    }
    fun action(block: suspend () -> Unit) {
        if (pending) return
        pending = true
        scope.launch {
            try { block(); error = "" }
            catch (c: CancellationException) { throw c }
            catch (_: Exception) { error = "Couldn't save this action. Please retry." }
            finally { pending = false }
        }
    }
    Box(Modifier.fillMaxSize()) {
        SpotVideo(url, active, Modifier.fillMaxSize(), muted, onQualifiedView = {
            scope.launch { try { SpotPostsRepository.recordView(post.id) } catch (c: CancellationException) { throw c } catch (_: Exception) { } }
        })
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent, Color.Black.copy(alpha = 0.8f)))))
        IconButton(toggleMuted, Modifier.align(Alignment.TopEnd).statusBarsPadding().padding(end = 8.dp)) {
            Icon(if (muted) Icons.Filled.VolumeOff else Icons.Filled.VolumeUp, if (muted) "Unmute" else "Mute", tint = Color.White)
        }
        Column(Modifier.align(Alignment.BottomStart).navigationBarsPadding().padding(start = 16.dp, end = 76.dp, bottom = 24.dp)) {
            Row(Modifier.clickable { onProfile(post.author) }, verticalAlignment = Alignment.CenterVertically) {
                SocialAvatar(post.author.profileImageUrl, "${post.author.displayName} profile", Modifier.size(36.dp), post.author.uid)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(post.author.displayName, color = Color.White, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("@${post.author.username}", color = Color.White.copy(alpha = 0.75f), style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(post.categories.joinToString(" · "), color = Color(0xFFFDD87A), style = MaterialTheme.typography.labelMedium)
            if (post.caption.isNotBlank()) Text(post.caption, color = Color.White, style = MaterialTheme.typography.bodyMedium, maxLines = if (expandedCaption) 12 else 3, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 6.dp).animateContentSize().clickable { expandedCaption = !expandedCaption })
            if (post.tags.isNotEmpty()) Text(post.tags.joinToString(" ") { "#$it" }, color = Color(0xFFFDD87A), style = MaterialTheme.typography.bodySmall, maxLines = 1)
            if (error.isNotBlank()) Text(error, color = Color(0xFFFDD87A), style = MaterialTheme.typography.bodySmall)
        }
        Column(Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 8.dp, bottom = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            SpotAnimatedIconButton(if (liked == true) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder, "Like",
                { if (liked != null) action { SpotPostsRepository.setLiked(post.id, liked != true) } },
                tint = if (liked == true) Color(0xFFE5484D) else Color.White, selected = liked == true, enabled = !pending)
            Text(spotCompactCount(post.likes), color = Color.White, style = MaterialTheme.typography.labelSmall)
            SpotAnimatedIconButton(Icons.Outlined.ChatBubbleOutline, "Comments", onComment, tint = Color.White)
            Text(spotCompactCount(post.comments), color = Color.White, style = MaterialTheme.typography.labelSmall)
            SpotAnimatedIconButton(Icons.AutoMirrored.Outlined.Send, "Share", {
                runCatching { context.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "${post.author.displayName} on SPOT: ${post.caption}\n$url")
                }, "Share SPOT reel")) }.onFailure { error = "No sharing app is available." }
            }, tint = Color.White)
            SpotAnimatedIconButton(if (saved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                if (saved) "Unsave" else "Save", { action { SocialRepository.shared.setSaved(post.id, !saved) } },
                tint = if (saved) Color(0xFFFDD87A) else Color.White, selected = saved, enabled = !pending)
        }
    }
}
