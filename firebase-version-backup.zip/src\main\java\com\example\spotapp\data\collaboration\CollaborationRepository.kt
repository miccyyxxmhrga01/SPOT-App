package com.example.spot.data.collaboration

import com.google.firebase.auth.FirebaseAuth
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.postgrest

class CollaborationRepository(
    private val supabase: SupabaseClient
) {

    suspend fun saveDetectedTalent(
        prediction: String,
        confidence: Double
    ): Result<Unit> {

        return try {

            val firebaseUser =
                FirebaseAuth.getInstance().currentUser
                    ?: return Result.failure(
                        Exception("User is not logged in.")
                    )

            val talent =
                TalentMapper.fromPrediction(prediction)
                    ?: return Result.failure(
                        Exception("Unsupported talent: $prediction")
                    )

            val userTalent = UserTalent(
                userId = firebaseUser.uid,
                talent = talent,
                confidence = confidence,
                source = "ai",
                confirmed = true
            )

            supabase
                .from("user_talents")
                .upsert(userTalent) {
                    onConflict = "user_id,talent"
                }

            Result.success(Unit)

        } catch (e: Exception) {

            Result.failure(e)
        }
    }


    suspend fun getSuggestions():
            Result<List<CollaborationSuggestion>> {

        return try {

            val result =
                supabase
                    .postgrest
                    .rpc(
                        function = "get_collaboration_suggestions"
                    )
                    .decodeList<CollaborationSuggestion>()

            Result.success(result)

        } catch (e: Exception) {

            Result.failure(e)
        }
    }
}