package com.example.spotapp.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.spotapp.R

val InterFontFamily = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold)
)

private fun spotText(size: Number, line: Int, weight: FontWeight = FontWeight.Normal) = TextStyle(
    fontFamily = InterFontFamily, fontWeight = weight, fontSize = size.toFloat().sp, lineHeight = line.sp
)

val Typography = Typography(
    displayLarge = spotText(44, 52, FontWeight.Bold),
    displayMedium = spotText(36, 44, FontWeight.Bold),
    displaySmall = spotText(30, 38, FontWeight.Bold),
    headlineLarge = spotText(26, 34, FontWeight.Bold),
    headlineMedium = spotText(23, 31, FontWeight.Bold),
    headlineSmall = spotText(20, 28, FontWeight.SemiBold),
    titleLarge = spotText(18, 26, FontWeight.SemiBold),
    titleMedium = spotText(14, 21, FontWeight.SemiBold),
    titleSmall = spotText(13, 19, FontWeight.SemiBold),
    bodyLarge = spotText(14, 21),
    bodyMedium = spotText(12, 19),
    bodySmall = spotText(11.5, 17),
    labelLarge = spotText(12, 19, FontWeight.SemiBold),
    labelMedium = spotText(11.5, 16, FontWeight.Medium),
    labelSmall = spotText(11, 16, FontWeight.Medium)
)
