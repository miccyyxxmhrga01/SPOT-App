package com.example.spotapp.data

import com.google.android.gms.tasks.Task
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.delay
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Client transactions and security rules validate the same event and counter together. */
class SocialRepository(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    companion object { val shared by lazy { SocialRepository() } }
    private fun uid() = checkNotNull(auth.currentUser?.uid) { "Sign in to continue." }
    private fun post(id: String) = db.collection("posts").document(id)
    private fun notifications(uid: String) = db.collection("users").document(uid).collection("notifications")

    fun listenComments(postId: String, after: DocumentSnapshot? = null,
        result: (SocialPage<SocialComment>) -> Unit, error: (String) -> Unit): ListenerRegistration {
        var q: Query = post(postId).collection("comments").orderBy("createdAt", Query.Direction.DESCENDING)
        if (after != null) q = q.startAfter(after)
        return q.limit(50).addSnapshotListener { s, e ->
            if (e != null) error("Comments couldn't load. Please retry.")
            else result(SocialPage(s?.documents.orEmpty().mapNotNull(SocialComment::from), s?.documents?.lastOrNull(), s?.size() == 50))
        }
    }

    fun listenCommentLike(postId: String, commentId: String, result: (Boolean) -> Unit,
        error: (String) -> Unit): ListenerRegistration = post(postId).collection("comments").document(commentId)
        .collection("likes").document(uid()).addSnapshotListener { s, e ->
            if (e != null) error("Comment likes couldn't load. Please retry.") else result(s?.getBoolean("liked") == true)
        }

    suspend fun sendComment(postId: String, commentId: String, text: String) {
        val body = text.trim()
        require(body.isNotEmpty() && body.length <= 2000) { "Write a comment of 1–2,000 characters." }
        val me = uid()
        val p = post(postId)
        val c = p.collection("comments").document(commentId)
        socialTransaction(db) { t ->
            val existing = t.get(c)
            if (existing.exists()) {
                check(existing.getString("userId") == me && existing.getString("text") == body) { "Comment retry doesn't match." }
                return@socialTransaction
            }
            val parent = t.get(p)
            check(parent.exists()) { "This post is no longer available." }
            val account = t.get(db.collection("users").document(me))
            t.set(c, mapOf("id" to commentId, "postId" to postId, "userId" to me,
                "username" to account.getString("username").orEmpty(), "displayName" to account.getString("displayName").orEmpty(),
                "profileImageUrl" to account.getString("profileImageUrl").orEmpty(), "text" to body,
                "createdAt" to FieldValue.serverTimestamp(), "likesCount" to 0L))
            t.update(p, mapOf("commentsCount" to ((parent.getLong("commentsCount") ?: 0) + 1), "lastCommentId" to commentId))
            val recipient = parent.getString("userId").orEmpty()
            if (recipient != me) t.set(notifications(recipient).document("comment_$commentId"),
                notificationData("comment", me, account, postId, "commented on your post", commentId))
        }
    }

    suspend fun removeComment(postId: String, commentId: String) {
        val me = uid(); val p = post(postId); val c = p.collection("comments").document(commentId)
        socialTransaction(db) { tx ->
            val comment = tx.get(c); val parent = tx.get(p)
            if (!comment.exists() || comment.getBoolean("deleted") == true) return@socialTransaction
            check(comment.getString("userId") == me) { "You can only delete your own comment." }
            tx.update(c, mapOf("deleted" to true, "text" to ""))
            tx.update(p, mapOf("commentsCount" to ((parent.getLong("commentsCount") ?: 0) - 1).coerceAtLeast(0), "lastDeletedCommentId" to commentId))
        }
    }

    suspend fun setCommentLiked(postId: String, commentId: String, liked: Boolean) {
        val me = uid()
        val c = post(postId).collection("comments").document(commentId)
        val l = c.collection("likes").document(me)
        socialTransaction(db) { t ->
            val comment = t.get(c)
            val previous = t.get(l).getBoolean("liked") == true
            check(comment.exists()) { "This comment is no longer available." }
            if (previous == liked) return@socialTransaction
            t.set(l, mapOf("liked" to liked))
            t.update(c, "likesCount", (comment.getLong("likesCount") ?: 0) + (if (liked) 1 else -1))
        }
    }

    fun listenNotifications(after: DocumentSnapshot? = null, result: (SocialPage<SocialNotification>) -> Unit,
        error: (String) -> Unit): ListenerRegistration {
        var q: Query = notifications(uid()).orderBy("createdAt", Query.Direction.DESCENDING)
        if (after != null) q = q.startAfter(after)
        return q.limit(50).addSnapshotListener { s, e ->
            if (e != null) error("Notifications couldn't load. Please retry.")
            else result(SocialPage(s?.documents.orEmpty().mapNotNull(SocialNotification::from), s?.documents?.lastOrNull(), s?.size() == 50))
        }
    }

    fun listenUnread(result: (Int) -> Unit): ListenerRegistration = notifications(uid())
        .whereEqualTo("isRead", false).limit(100).addSnapshotListener { s, e -> if (e == null) result(s?.size() ?: 0) }

    suspend fun markRead(id: String, read: Boolean = true) = notifications(uid()).document(id).update("isRead", read).awaitSocial()

    suspend fun markAllRead() {
        val ref = notifications(uid())
        // Bounded batches; continue until every currently unread notification is marked.
        while (true) {
            val unread = ref.whereEqualTo("isRead", false).limit(100).get(Source.SERVER).awaitSocial()
            if (unread.isEmpty) return
            val batch = db.batch()
            unread.documents.forEach { batch.update(it.reference, "isRead", true) }
            batch.commit().awaitSocial()
        }
    }

    fun listenFollowing(target: String, result: (Boolean) -> Unit, error: (String) -> Unit): ListenerRegistration =
        db.collection("users").document(target).collection("followers").document(uid())
            .addSnapshotListener { s, e -> if (e != null) error("Follow status couldn't load.") else result(s?.exists() == true) }

    suspend fun setFollowing(target: String, following: Boolean) {
        val me = uid()
        require(target != me) { "You cannot follow yourself." }
        val follower = db.collection("users").document(target).collection("followers").document(me)
        val outgoing = db.collection("users").document(me).collection("following").document(target)
        val n = notifications(target).document("follow_$me")
        socialTransaction(db) { t ->
            val previous = t.get(follower)
            if (previous.exists() == following) return@socialTransaction
            if (following) {
                val account = t.get(db.collection("users").document(me))
                val oldNotification = t.get(n)
                t.set(follower, mapOf("uid" to me, "createdAt" to FieldValue.serverTimestamp()))
                t.set(outgoing, mapOf("uid" to target, "createdAt" to FieldValue.serverTimestamp()))
                if (!oldNotification.exists()) t.set(n, notificationData("follow", me, account, "", "started following you"))
            } else { t.delete(follower); t.delete(outgoing) }
        }
    }

    suspend fun counts(target: String): Pair<Long, Long> {
        val user = db.collection("users").document(target)
        return user.collection("followers").count().get(AggregateSource.SERVER).awaitSocial().count to
            user.collection("following").count().get(AggregateSource.SERVER).awaitSocial().count
    }

    fun listenSaved(id: String, result: (Boolean) -> Unit): ListenerRegistration =
        db.collection("users").document(uid()).collection("savedPosts").document(id)
            .addSnapshotListener { s, e -> if (e == null) result(s?.exists() == true) }

    suspend fun setSaved(id: String, saved: Boolean) {
        val ref = db.collection("users").document(uid()).collection("savedPosts").document(id)
        if (saved) ref.set(mapOf("postId" to id, "createdAt" to FieldValue.serverTimestamp())).awaitSocial()
        else ref.delete().awaitSocial()
    }
}

internal fun notificationData(type: String, uid: String, account: DocumentSnapshot, postId: String,
    message: String, commentId: String = ""): Map<String, Any> = mapOf(
    "type" to type, "senderId" to uid, "senderName" to account.getString("displayName").orEmpty(),
    "senderProfileImageUrl" to account.getString("profileImageUrl").orEmpty(), "postId" to postId,
    "commentId" to commentId, "message" to message, "createdAt" to FieldValue.serverTimestamp(), "isRead" to false)

internal suspend fun <T> Task<T>.awaitSocial(): T = suspendCancellableCoroutine { c ->
    addOnSuccessListener { if (c.isActive) c.resume(it) }
    addOnFailureListener { if (c.isActive) c.resumeWithException(it) }
    addOnCanceledListener { c.cancel() }
}

/** A competing commit can invalidate getAfter counter rules before the SDK reports ABORTED.
 * Re-read all documents in a new transaction, with the same id, at most three times.
 * Permanent permission failures still reach the UI; rules are never bypassed. */
internal suspend fun socialTransaction(db: FirebaseFirestore, block: (Transaction) -> Unit) {
    repeat(3) { attempt ->
        try { db.runTransaction { block(it) }.awaitSocial(); return }
        catch (e: FirebaseFirestoreException) {
            if (attempt == 2 || e.code !in setOf(FirebaseFirestoreException.Code.ABORTED, FirebaseFirestoreException.Code.PERMISSION_DENIED)) throw e
            delay(100L * (attempt + 1))
        }
    }
}
