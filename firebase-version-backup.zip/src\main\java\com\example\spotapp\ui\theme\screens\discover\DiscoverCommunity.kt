package com.example.spotapp.ui.theme.screens.discover

import com.example.spotapp.ui.theme.components.*

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.spotapp.data.*
import com.example.spotapp.ui.theme.models.SpotUiProfile
import com.google.firebase.firestore.DocumentSnapshot
import kotlinx.coroutines.*

private data class CommunityCardData(val id: String, val title: String, val description: String, val image: String,
    val category: String, val subtitle: String, val footer: String, val date: Long = 0)

@Composable
internal fun DiscoverCommunity(isEvent: Boolean, profile: SpotUiProfile, onProfile: (SpotUiProfile) -> Unit) {
    val repository = remember { DiscoverRepository.shared }
    var search by rememberSaveable(isEvent) { mutableStateOf("") }
    var category by rememberSaveable(isEvent) { mutableStateOf("") }
    var filters by rememberSaveable(isEvent) { mutableStateOf(false) }
    var create by rememberSaveable(isEvent) { mutableStateOf(false) }
    var selected by rememberSaveable(isEvent) { mutableStateOf<String?>(null) }
    var items by remember(isEvent) { mutableStateOf(emptyList<CommunityCardData>()) }
    var cursor by remember(isEvent) { mutableStateOf<DocumentSnapshot?>(null) }
    var hasMore by remember(isEvent) { mutableStateOf(false) }
    var loading by remember(isEvent) { mutableStateOf(true) }
    var error by remember(isEvent) { mutableStateOf("") }
    var revision by remember { mutableIntStateOf(0) }
    var pageRequest by remember { mutableIntStateOf(0) }
    var canCreate by remember(isEvent) { mutableStateOf(!isEvent) }
    var roleError by remember { mutableStateOf("") }
    suspend fun load(after: DocumentSnapshot?) {
        loading = true; error = ""
        try {
            val page = if (isEvent) repository.events(search, category, after).let { p ->
                SocialPage(p.items.map { e -> CommunityCardData(e.eventId, e.title, e.description, e.imageUrl, e.category,
                    e.location, "${e.participantCount}${e.participantLimit?.let { "/$it" }.orEmpty()} joined · ${e.organizer}", e.startsAt) }, p.cursor, p.hasMore)
            } else repository.groups(search, category, after).let { p ->
                SocialPage(p.items.map { g -> CommunityCardData(g.groupId, g.name, g.description, g.imageUrl, g.category,
                    if (g.privacy == "private") "Private · request to join" else "Public group", "${g.memberCount} members · ${g.ownerName}") }, p.cursor, p.hasMore)
            }
            items = (if (after == null) page.items else items + page.items).distinctBy { it.id }
            cursor = page.cursor; hasMore = page.hasMore
        } catch (e: CancellationException) { throw e }
        catch (_: Exception) { error = "${if (isEvent) "Events" else "Groups"} couldn't load. Check your connection and retry." }
        finally { loading = false }
    }
    LaunchedEffect(isEvent, search, category, revision, pageRequest) {
        // Query changes reset pageRequest below, cancelling any stale in-flight page.
        if (pageRequest == 0) { items = emptyList(); cursor = null; hasMore = false; loading = true; delay(250) }
        load(if (pageRequest == 0) null else cursor)
    }
    LaunchedEffect(isEvent, profile.uid, revision) {
        roleError = ""
        if (isEvent) try { canCreate = repository.canCreateEvents() }
        catch (e: CancellationException) { throw e } catch (_: Exception) { canCreate = false; roleError = "Your event permissions couldn't be checked. Tap Retry to reconnect." }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 110.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (isEvent) "Make your next move" else "Find your people", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        
                    }
                    IconButton(onClick = { pageRequest = 0; revision++ }) { Icon(Icons.Default.Refresh, "Refresh") }
                }
                if (canCreate) Button(onClick = { create = true }, colors = ButtonDefaults.buttonColors(containerColor = CommunityGold), modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, null, Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)); Text(if (isEvent) "Create event" else "Create group")
                }
                SpotSearchField(search, { search = it.take(100); pageRequest = 0 }, placeholder = if (isEvent) "Search events" else "Search groups", loading = loading,
                    extra = { IconButton({ filters = !filters }) { Icon(Icons.Default.Tune, "Filter categories", Modifier.size(20.dp)) } })
                Column(Modifier.animateContentSize()) {
                    if (filters) CommunityCategories(category, { category = it; pageRequest = 0 }, all = true)
                    else if (category.isNotBlank()) InputChip(true, { category = ""; pageRequest = 0 }, label = { Text(category) }, trailingIcon = { Icon(Icons.Default.Close, "Clear category", Modifier.size(14.dp)) },
                        colors = InputChipDefaults.inputChipColors(selectedContainerColor = Color(0xFFFAF2DF), selectedLabelColor = CommunityGold))
                }
                CommunityError(roleError) { revision++ }
            }
        }
        items(items, key = { it.id }) { item ->
            Card(onClick = { selected = item.id }, colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, CommunityLine),
                shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().animateItem()) {
                CommunityCover(item.image, isEvent, Modifier.fillMaxWidth().height(if (isEvent) 160.dp else 130.dp))
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { CommunityBadge(item.category); if (isEvent) CommunityBadge(eventDate(item.date, "MMM d")) }
                    Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(if (isEvent) eventDate(item.date) else item.description, style = MaterialTheme.typography.bodySmall, color = Color.Gray, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(item.subtitle, style = MaterialTheme.typography.bodySmall)
                    HorizontalDivider(color = CommunityLine)
                    Text(item.footer, style = MaterialTheme.typography.labelSmall, color = CommunityGold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
        }
        item {
            if (loading) SpotLoading(true, SkeletonKind.CARDS)
            CommunityError(error) { if (items.isEmpty()) pageRequest = 0; revision++ }
            if (!loading && error.isBlank() && items.isEmpty()) Column(Modifier.fillMaxWidth().padding(vertical = 36.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(if (isEvent) Icons.Default.Event else Icons.Default.Groups, null, Modifier.size(40.dp), tint = CommunityGold)
                Spacer(Modifier.height(12.dp)); Text(if (search.isNotBlank() || category.isNotBlank()) "No matches yet" else if (isEvent) "No events yet" else "Be the first to start a group", style = MaterialTheme.typography.titleSmall)
                
            }
            if (hasMore && !loading) TextButton(onClick = { pageRequest++ }, modifier = Modifier.fillMaxWidth()) { Text("Load more") }
        }
    }
    if (create) CommunityEditor(isEvent, profile, close = { create = false }, created = { id -> create = false; selected = id; pageRequest = 0; revision++ })
    selected?.let { id -> CommunityDetails(id, isEvent, profile, close = { selected = null; pageRequest = 0; revision++ }, onProfile = { selected = null; onProfile(it) }) }
}
