package com.example.spotapp.ui.theme.components

import com.example.spotapp.ui.theme.spotSp

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.spotapp.SignupFrame
import com.example.spotapp.SignupGold
import com.example.spotapp.SignupGoldDark
import com.example.spotapp.SignupInk
import com.example.spotapp.SignupMuted
import com.example.spotapp.data.AuthRepository
import com.example.spotapp.ui.theme.SPOTAppTheme
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import kotlin.coroutines.resume
import kotlin.time.Duration.Companion.seconds

@Composable
fun SpotEmailVerificationScreen(onVerified: () -> Unit, onUseAnotherAccount: () -> Unit) {
    SpotEmailVerificationContent(onVerified, onUseAnotherAccount)
}

@Composable
internal fun SpotEmailVerificationContent(
    onVerified: () -> Unit,
    onUseAnotherAccount: () -> Unit,
    initialLinkSent: Boolean = false,
    initialMessage: String = ""
) {
    val email = AuthRepository.currentUserEmail()
    val scope = rememberCoroutineScope()
    val latestOnVerified by rememberUpdatedState(onVerified)
    var busyAction by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf(initialMessage) }
    var messageIsError by remember { mutableStateOf(initialMessage.isNotBlank() && !initialLinkSent) }
    var continueSent by remember { mutableStateOf(false) }
    var nextSendAt by rememberSaveable(email) {
        mutableLongStateOf(if (initialLinkSent) System.currentTimeMillis() + 60000L else 0L)
    }
    var secondsRemaining by remember { mutableIntStateOf(0) }

    LaunchedEffect(nextSendAt) {
        do {
            secondsRemaining = ((nextSendAt - System.currentTimeMillis() + 999L) / 1000L)
                .coerceIn(0L, 60L).toInt()
            if (secondsRemaining > 0) delay(1.seconds)
        } while (secondsRemaining > 0)
    }

    fun request(sendEmail: Boolean) {
        if (busyAction != null || continueSent) return
        if (sendEmail && System.currentTimeMillis() < nextSendAt) return
        busyAction = if (sendEmail) "send" else "check"
        message = ""
        scope.launch {
            try {
                val result = awaitSpotAuthResult { callback ->
                    if (sendEmail) AuthRepository.resendVerificationEmail(callback)
                    else AuthRepository.checkEmailVerified(callback)
                }
                messageIsError = !result.first
                when {
                    !result.first -> message = result.second ?: "Could not complete this request. Please retry."
                    sendEmail -> {
                        nextSendAt = System.currentTimeMillis() + 60000L
                        message = "Link sent. Check your inbox or spam folder."
                    }
                    else -> { continueSent = true; latestOnVerified() }
                }
            } catch (timeout: TimeoutCancellationException) {
                messageIsError = true
                message = "This took too long. Check your connection and retry."
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                messageIsError = true
                message = "Could not check your account. Please retry."
            } finally { busyAction = null }
        }
    }

    val enabled = busyAction == null && !continueSent
    BackHandler { if (enabled) onUseAnotherAccount() }
    SignupVerificationScreen(
        email = email, message = message, messageIsError = messageIsError,
        checking = busyAction == "check", sending = busyAction == "send",
        enabled = enabled, secondsRemaining = secondsRemaining,
        onCheck = { request(false) }, onResend = { request(true) }, onBack = onUseAnotherAccount
    )
}

@Composable
internal fun SignupVerificationScreen(
    email: String,
    message: String = "",
    messageIsError: Boolean = false,
    checking: Boolean = false,
    sending: Boolean = false,
    enabled: Boolean = true,
    secondsRemaining: Int = 0,
    onCheck: () -> Unit,
    onResend: () -> Unit,
    onBack: () -> Unit
) {
    SignupFrame(step = 1, onBack = onBack, enabled = enabled) {
        val height = maxHeight / LocalDensity.current.fontScale
        val compact = height < 470.dp
        val tiny = height < 320.dp
        Surface(
            Modifier.fillMaxWidth(), color = Color.White, shape = RoundedCornerShape(28.dp),
            border = BorderStroke(1.dp, Color(0xFFE9E5D8)), shadowElevation = if (compact) 0.dp else 3.dp
        ) {
            Column(Modifier.padding(if (compact) 16.dp else 26.dp)) {
                if (!compact) {
                    Box(Modifier.size(64.dp).background(Color(0xFFFFF5D6), CircleShape), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.MarkEmailRead, null, Modifier.size(30.dp), tint = SignupGoldDark)
                    }
                    Spacer(Modifier.height(22.dp))
                }
                Text("Check your inbox", color = SignupInk, fontSize = if (tiny) 21.spotSp else 28.spotSp,
                    fontWeight = FontWeight.Bold, letterSpacing = (-0.6).sp)
                Spacer(Modifier.height(if (tiny) 4.dp else 10.dp))
                if (!tiny) {
                    Text("Open the verification link sent to", color = SignupMuted, fontSize = 13.spotSp)
                    Spacer(Modifier.height(5.dp))
                }
                Text(email.ifBlank { "your account email" }, color = SignupGoldDark, fontSize = 14.spotSp,
                    fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (!compact) {
                    Spacer(Modifier.height(22.dp))
                    Surface(color = Color(0xFFF8F7F1), shape = RoundedCornerShape(16.dp)) {
                        Text("Tap the link in your email, then come back here. Your profile is next.",
                            color = SignupMuted, fontSize = 13.spotSp, lineHeight = 20.sp, modifier = Modifier.padding(16.dp))
                    }
                }
                Spacer(Modifier.height(if (tiny) 10.dp else 20.dp))
                if (message.isNotBlank()) {
                    Text(message, color = if (messageIsError) Color(0xFFB3261E) else Color(0xFF365A27),
                        fontSize = 12.spotSp, lineHeight = 16.sp, maxLines = 3, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(bottom = 12.dp).semantics { liveRegion = LiveRegionMode.Polite })
                }
                Box(Modifier.testTag("verify-submit")) {
                    SpotAuthButton(text = "I've verified my email", loading = checking, enabled = enabled, onClick = onCheck)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = onResend, enabled = enabled && secondsRemaining == 0) {
                        if (sending) CircularProgressIndicator(Modifier.size(14.dp), color = SignupGoldDark, strokeWidth = 2.dp)
                        Text(when {
                            sending -> "Sending..."
                            secondsRemaining > 0 -> "Resend in ${secondsRemaining}s"
                            else -> "Resend link"
                        }, color = if (secondsRemaining > 0) SignupMuted else SignupGoldDark, fontSize = 12.spotSp)
                    }
                    TextButton(onClick = onBack, enabled = enabled) {
                        Text("Change account", color = SignupMuted, fontSize = 12.spotSp)
                    }
                }
                if (!compact) {
                    Text("No email? Check your spam folder.", color = SignupMuted, fontSize = 12.spotSp,
                        modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
    }
}

@Composable
internal fun SpotAuthButton(text: String, loading: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled && !loading,
        modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp), shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = SignupGold, contentColor = SignupInk,
            disabledContainerColor = Color(0xFFE9DDAF), disabledContentColor = SignupMuted)
    ) {
        if (loading) {
            CircularProgressIndicator(Modifier.size(18.dp), color = SignupInk, strokeWidth = 2.dp)
            Spacer(Modifier.width(10.dp))
        }
        Text(text, fontSize = 14.spotSp, fontWeight = FontWeight.Bold)
    }
}

internal suspend fun awaitSpotAuthResult(start: ((Boolean, String?) -> Unit) -> Unit): Pair<Boolean, String?> =
    withTimeout(30.seconds) {
        suspendCancellableCoroutine { continuation ->
            start { success, error -> if (continuation.isActive) continuation.resume(success to error) }
        }
    }

@Preview(name = "Verify - phone", widthDp = 393, heightDp = 780, showBackground = true)
@Preview(name = "Verify - short screen", widthDp = 360, heightDp = 360, showBackground = true)
@Composable
private fun SignupVerificationPreview() {
    SPOTAppTheme {
        SignupVerificationScreen("you@example.com", onCheck = {}, onResend = {}, onBack = {})
    }
}
