package com.example.spotapp.ui.theme.screens.post

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.spotapp.data.*
import com.example.spotapp.ui.theme.components.*
import kotlinx.coroutines.CancellationException

@Composable
internal fun PostMediaEditor(draft: PostDraft, update: (PostDraft) -> Unit, active: Boolean, back: () -> Unit, add: () -> Unit, next: () -> Unit,
    selection: String? = null, onSelection: (String) -> Unit = {}) {
    val context = LocalContext.current
    var selected by rememberSaveable { mutableStateOf(draft.mediaUris.firstOrNull().orEmpty()) }
    val uri = (selection ?: selected).takeIf { it in draft.mediaUris } ?: draft.mediaUris.firstOrNull().orEmpty()
    val edit = draft.mediaEdits[uri] ?: PostMediaEdit()
    var crop by remember { mutableStateOf(false) }
    var remove by remember { mutableStateOf(false) }
    var error by remember(uri) { mutableStateOf("") }
    val info by produceState<LibraryMedia?>(null, uri) {
        value = null
        try { value = MediaLibraryRepository(context).describe(uri) }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { error = "This media is unavailable. Remove it and choose it again." }
    }
    val bitmap by produceState<android.graphics.Bitmap?>(null, uri, edit, info?.isVideo) {
        value = null
        if (info?.isVideo == false) try { value = PostMediaExporter.imagePreview(context, uri, edit) }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { error = "This photo couldn't open. Remove it and choose another." }
    }
    fun change(value: PostMediaEdit) { update(draft.copy(mediaEdits = draft.mediaEdits + (uri to value))); error = "" }
    Column(Modifier.fillMaxSize().background(PostInk).navigationBarsPadding().testTag("post-editor")) {
        PostTopBar("Edit media", back, dark = true) {
            Text("${draft.mediaUris.indexOf(uri) + 1} / ${draft.mediaUris.size}", color = Color.White.copy(alpha = .65f), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(end = 20.dp))
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            val image = bitmap
            if (info?.isVideo == true) SpotVideo(uri, active && !crop && !remove, Modifier.fillMaxSize(), muted = edit.muted)
            else if (image != null) Image(image.asImageBitmap(), "Edited photo preview", Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            else if (error.isBlank()) Box(Modifier.align(Alignment.Center)) { SpotLoading(true, SkeletonKind.POST) }
            if (error.isNotBlank()) Text(error, Modifier.align(Alignment.Center).padding(32.dp), color = Color.White, style = MaterialTheme.typography.bodyMedium)
            Column(Modifier.align(Alignment.CenterEnd).padding(end = 10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (info?.isVideo == false) {
                    EditorTool(Icons.Default.Crop, "Crop") { crop = true }
                    EditorTool(Icons.Default.RotateRight, "Rotate") { change(edit.rotate()) }
                }
                if (info?.isVideo == true) EditorTool(if (edit.muted) Icons.Default.VolumeOff else Icons.Default.VolumeUp, if (edit.muted) "Unmute" else "Mute") { change(edit.copy(muted = !edit.muted)) }
                if (edit != PostMediaEdit()) EditorTool(Icons.Default.RestartAlt, "Reset") { change(PostMediaEdit()) }
                EditorTool(Icons.Default.DeleteOutline, "Remove") { remove = true }
            }
        }
        MediaSelectionStrip(draft.mediaUris, draft.mediaEdits, uri, { selected = it; onSelection(it) }, add = add, dark = true)
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (draft.mediaUris.size > 1) {
                IconButton(onClick = { update(draft.copy(mediaUris = movePostMedia(draft.mediaUris, draft.mediaUris.indexOf(uri), -1))) }, enabled = draft.mediaUris.indexOf(uri) > 0) { Icon(Icons.Default.KeyboardArrowLeft, "Move earlier", tint = if (draft.mediaUris.indexOf(uri) > 0) Color.White else Color.DarkGray) }
                IconButton(onClick = { update(draft.copy(mediaUris = movePostMedia(draft.mediaUris, draft.mediaUris.indexOf(uri), 1))) }, enabled = draft.mediaUris.indexOf(uri) < draft.mediaUris.lastIndex) { Icon(Icons.Default.KeyboardArrowRight, "Move later", tint = if (draft.mediaUris.indexOf(uri) < draft.mediaUris.lastIndex) Color.White else Color.DarkGray) }
            }
            Spacer(Modifier.weight(1f)); PostNextButton(enabled = error.isBlank() && info != null, onClick = next)
        }
    }
    if (crop) AlertDialog(onDismissRequest = { crop = false }, containerColor = PostIvory, title = { Text("Crop photo") }, text = {
        Column { listOf("original" to "Original", "square" to "Square · 1:1", "portrait" to "Portrait · 4:5", "landscape" to "Landscape · 16:9").forEach { (value, label) ->
            TextButton(onClick = { change(edit.copy(crop = value)); crop = false }, Modifier.fillMaxWidth()) { Text(label, color = if (edit.crop == value) PostGold else PostInk) }
        }; Text("Crops from the center. Your original stays untouched.", style = MaterialTheme.typography.bodySmall, color = PostMuted) }
    }, confirmButton = { TextButton(onClick = { crop = false }) { Text("Cancel", color = PostGold) } })
    if (remove) AlertDialog(onDismissRequest = { remove = false }, containerColor = PostIvory, title = { Text("Remove this media?") },
        confirmButton = { TextButton(onClick = { val remaining = draft.mediaUris - uri; update(draft.copy(mediaUris = remaining, mediaEdits = draft.mediaEdits - uri)); remove = false; if (remaining.isEmpty()) back() }) { Text("Remove", color = PostGold) } },
        dismissButton = { TextButton(onClick = { remove = false }) { Text("Keep", color = PostInk) } })
}

@Composable
private fun EditorTool(icon: ImageVector, label: String, click: () -> Unit) {
    SpotAnimatedIconButton(icon, label, click, Modifier.background(Color.Black.copy(alpha = .48f), CircleShape), tint = Color.White)
}
