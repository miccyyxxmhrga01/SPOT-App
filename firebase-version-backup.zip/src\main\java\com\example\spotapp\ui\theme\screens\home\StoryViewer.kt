package com.example.spotapp.ui.theme.screens.home

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.currentStateAsState
import com.example.spotapp.data.*
import com.example.spotapp.ui.theme.components.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

@Composable
internal fun StoryViewer(items: List<StoryItem>, currentUid: String, close: () -> Unit, onSeen: (String) -> Unit = {},
    onProfile: (String) -> Unit = {}, onDelete: (suspend (String) -> Unit)? = null, highlight: Boolean = false,
    repository: StoryRepository = StoryRepository.shared) {
    if (LocalSpotVideo.current == null) {
        ProvideSpotVideo { StoryViewer(items, currentUid, close, onSeen, onProfile, onDelete, highlight, repository) }
        return
    }
    var index by rememberSaveable { mutableIntStateOf(0) }
    val item = items.getOrNull(index) ?: items.lastOrNull() ?: return
    var progress by remember(item.id) { mutableFloatStateOf(0f) }
    var paused by remember(item.id) { mutableStateOf(false) }
    var ready by remember(item.id) { mutableStateOf(false) }
    var failure by remember(item.id) { mutableStateOf(false) }
    var retry by remember(item.id) { mutableIntStateOf(0) }
    var deleting by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var error by remember(item.id) { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }
    var liked by remember(item.id, currentUid) { mutableStateOf(false) }
    var likeLoaded by remember(item.id, currentUid) { mutableStateOf(false) }
    var reacting by remember(item.id) { mutableStateOf(false) }
    var reactionError by remember(item.id) { mutableStateOf("") }
    var burst by remember(item.id) { mutableStateOf(false) }
    val own = item.userId == currentUid
    val scope = rememberCoroutineScope()
    val lifecycle by LocalLifecycleOwner.current.lifecycle.currentStateAsState()
    val controller = LocalSpotVideo.current!!
    val currentId by rememberUpdatedState(item.id)
    fun dismiss() { if (!deleting) { visible = false; scope.launch { delay(180); close() } } }
    fun next() { if (index < items.lastIndex) index++ else dismiss() }
    fun previous() { if (index > 0) index-- else { progress = 0f; controller.player.seekTo(0) } }
    LaunchedEffect(Unit) { visible = true }
    LaunchedEffect(burst) { if (burst) { delay(650); burst = false } }
    LifecycleDisposableEffect(item.id, currentUid, retry, highlight) {
        val listener = if (!own && !highlight && currentUid.isNotBlank()) repository.listenLiked(item.id,
            { liked = it; likeLoaded = true; reactionError = "" }, { likeLoaded = false; reactionError = it }) else null
        onDispose { listener?.remove() }
    }
    LaunchedEffect(item.id, retry) {
        progress = 0f; ready = false; failure = false
        if (item.video) {
            snapshotFlow { controller.owner to controller.player.currentMediaItem?.localConfiguration?.uri.toString() }
                .first { it.first != null && it.second == item.mediaUrl }
            controller.player.seekTo(0)
        }
    }
    fun react(forceLike: Boolean = false) {
        if (own || highlight || reacting || !likeLoaded || (forceLike && liked)) return
        val before = liked; val desired = forceLike || !liked
        val storyId = item.id
        liked = desired; reacting = true; reactionError = ""
        if (desired) burst = true
        scope.launch {
            try { withTimeout(30_000) { repository.setLiked(storyId, desired) } }
            catch (e: CancellationException) {
                if (e is TimeoutCancellationException) { liked = before; reactionError = "Reaction wasn't confirmed. Retry." } else throw e
            }
            catch (_: Exception) { liked = before; reactionError = "Reaction wasn't saved. Retry." }
            finally { reacting = false }
        }
    }
    val latestNext by rememberUpdatedState({ next() })
    val running = visible && !paused && !confirmDelete && !reacting && reactionError.isBlank() && lifecycle.isAtLeast(Lifecycle.State.RESUMED)
    LaunchedEffect(item.id, running, ready, retry) {
        if (!running) return@LaunchedEffect
        while (isActive) {
            if (!highlight && !item.active()) { latestNext(); break }
            if (item.video) {
                if (controller.playing && controller.player.currentMediaItem?.localConfiguration?.uri.toString() == item.mediaUrl) {
                    val duration = controller.player.duration
                    if (duration > 0) {
                        progress = (controller.player.currentPosition.toFloat() / duration).coerceIn(0f, 1f)
                        if (controller.player.currentPosition >= duration - 120) { onSeen(item.id); latestNext(); break }
                    }
                }
            } else if (ready) {
                progress = (progress + 40f / item.composition.imageDurationMs).coerceAtMost(1f)
                if (progress >= 1f) { onSeen(item.id); latestNext(); break }
            }
            delay(40)
        }
    }
    Dialog(onDismissRequest = { dismiss() }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)) {
        StorySystemBars()
        AnimatedVisibility(visible, enter = fadeIn(tween(180)) + scaleIn(tween(180), initialScale = .96f), exit = fadeOut(tween(150))) {
            Box(Modifier.fillMaxSize().background(Color(0xFF111111)).safeDrawingPadding()) {
                AnimatedContent(item.id to retry, transitionSpec = { fadeIn(tween(140)) togetherWith fadeOut(tween(100)) }, label = "Story") { target ->
                    val shown = items.firstOrNull { it.id == target.first } ?: item
                    StoryCanvas(shown.mediaUrl, shown.video, shown.composition, active = target.first == item.id && running,
                        modifier = Modifier.fillMaxSize(), onReady = { if (target.first == currentId) ready = true }, onFailure = { if (target.first == currentId) failure = true })
                }
                Box(Modifier.fillMaxSize().testTag("story-tap-area").pointerInput(item.id, liked, likeLoaded) {
                    detectTapGestures(onPress = { paused = true; try { tryAwaitRelease() } finally { paused = false } },
                        onDoubleTap = { react(forceLike = true) }, onTap = { position ->
                            if (position.x < size.width * .35f) previous() else { onSeen(item.id); next() }
                        })
                })
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { items.forEachIndexed { i, _ ->
                        LinearProgressIndicator(progress = { if (i < index) 1f else if (i == index) progress else 0f }, Modifier.weight(1f).height(3.dp),
                            color = StoryGold, trackColor = Color.White.copy(alpha = .3f))
                    } }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SpotAvatar(item.profileImageUrl, "Profile", Modifier.size(32.dp).clickable { onProfile(item.userId) }, item.userId)
                        Text(item.username.ifBlank { if (own) "Your story" else "Story" }, Modifier.weight(1f).padding(10.dp).clickable { onProfile(item.userId) },
                            color = Color.White, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                        if (own && onDelete != null) StoryTool(Icons.Default.DeleteOutline, "Delete story", { confirmDelete = true }, enabled = !deleting)
                        StoryTool(Icons.Default.Close, "Close story", { dismiss() }, enabled = !deleting)
                    }
                }
                AnimatedVisibility(burst, modifier = Modifier.align(Alignment.Center), enter = scaleIn(initialScale = .4f) + fadeIn(), exit = scaleOut() + fadeOut()) {
                    Icon(Icons.Default.Favorite, null, Modifier.size(88.dp), tint = StoryGold)
                }
                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp)) {
                    if (error.isNotBlank() || reactionError.isNotBlank()) Text(error.ifBlank { reactionError }, Modifier.padding(bottom = 8.dp), color = StoryGold, style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        StoryTool(Icons.Default.ChevronLeft, "Previous story", ::previous)
                        StoryTool(Icons.Default.ChevronRight, "Next story", { onSeen(item.id); next() })
                        Spacer(Modifier.weight(1f))
                        if (failure || controller.failure || reactionError.isNotBlank()) StoryTool(Icons.Default.Refresh, "Retry story", {
                            retry++; error = ""; reactionError = ""; if (item.video) controller.retry()
                        })
                        if (!highlight && own) {
                            Icon(Icons.Default.Favorite, "Story hearts", Modifier.size(22.dp), tint = StoryGold)
                            Text(item.likesCount.toString(), Modifier.padding(horizontal = 8.dp), color = Color.White, style = MaterialTheme.typography.labelLarge)
                        } else if (!highlight) StoryTool(if (liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            if (liked) "Unlike story" else "Like story", { react() }, Modifier.testTag("story-like"), enabled = likeLoaded && !reacting, selected = liked)
                    }
                }
            }
        }
    }
    if (confirmDelete) AlertDialog(onDismissRequest = { if (!deleting) confirmDelete = false }, title = { Text("Delete story?") },
        confirmButton = { TextButton({ if (!deleting) { deleting = true; scope.launch {
            try { onDelete?.invoke(item.id); confirmDelete = false; deleting = false; if (items.size == 1) dismiss() else index = index.coerceAtMost(items.lastIndex - 1) }
            catch (e: CancellationException) { throw e }
            catch (_: Exception) { error = "Couldn't delete. Retry."; confirmDelete = false }
            finally { deleting = false }
        } } }, enabled = !deleting) { Text(if (deleting) "Deleting…" else "Delete") } },
        dismissButton = { TextButton({ confirmDelete = false }, enabled = !deleting) { Text("Cancel") } })
}
