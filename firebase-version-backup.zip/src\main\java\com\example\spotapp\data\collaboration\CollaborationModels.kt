package com.example.spot.data.collaboration

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class UserTalent(
    @SerialName("user_id")
    val userId: String,

    val talent: String,

    val confidence: Double = 1.0,

    val source: String = "profile",

    val confirmed: Boolean = true
)


@Serializable
data class CollaborationSuggestion(

    @SerialName("user_id")
    val userId: String,

    @SerialName("display_name")
    val displayName: String,

    @SerialName("avatar_url")
    val avatarUrl: String? = null,

    val talent: String,

    @SerialName("compatibility_score")
    val compatibilityScore: Double
)