package com.example.spotapp.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*

/** Firestore is authoritative for roles, ownership and request transitions. */
class WorkRepository internal constructor(private val db: FirebaseFirestore, private val auth: FirebaseAuth) {
    companion object { val shared by lazy { WorkRepository(FirebaseFirestore.getInstance(), FirebaseAuth.getInstance()) } }
    private fun uid() = requireNotNull(auth.currentUser?.uid) { "Please sign in again." }
    fun newOpportunityId() = db.collection("opportunities").document().id
    suspend fun opportunities(mine: Boolean, after: DocumentSnapshot? = null): SocialPage<Opportunity> {
        var q: Query = db.collection("opportunities").whereEqualTo(if (mine) "seekerId" else "status", if (mine) uid() else "open")
            .orderBy("createdAt", Query.Direction.DESCENDING)
        if (after != null) q = q.startAfter(after)
        val s = q.limit(30).get(Source.SERVER).awaitSocial()
        return SocialPage(s.documents.map(::opportunity), s.documents.lastOrNull(), s.size() == 30)
    }
    fun listenOpportunity(id: String, result: (Opportunity?) -> Unit, error: (String) -> Unit): ListenerRegistration =
        db.collection("opportunities").document(id).addSnapshotListener { s, e ->
            if (e != null) error("This opportunity couldn't load. Please retry.") else result(s?.takeIf { it.exists() }?.let(::opportunity))
        }
    suspend fun publish(id: String, draft: OpportunityDraft) {
        draft.problem()?.let { throw IllegalArgumentException(it) }
        val me = uid(); val ref = db.collection("opportunities").document(id)
        db.runTransaction { t ->
            if (!t.get(ref).exists()) t.set(ref, mapOf("seekerId" to me, "title" to draft.title.trim(), "kind" to draft.kind,
                "description" to draft.description.trim(), "category" to draft.category, "location" to draft.location.trim(),
                "deadline" to com.google.firebase.Timestamp(java.util.Date(draft.deadline)), "status" to "open", "createdAt" to FieldValue.serverTimestamp()))
        }.awaitSocial()
    }
    suspend fun close(id: String) { db.collection("opportunities").document(id).update("status", "closed").awaitSocial() }
    suspend fun myEvents(after: DocumentSnapshot? = null): SocialPage<CampusEvent> {
        var q: Query = db.collection("events").whereEqualTo("organizerId", uid()).orderBy("startsAt", Query.Direction.DESCENDING)
        if (after != null) q = q.startAfter(after)
        val s = q.limit(30).get(Source.SERVER).awaitSocial()
        return SocialPage(s.documents.mapNotNull { it.event() }, s.documents.lastOrNull(), s.size() == 30)
    }
    suspend fun event(id: String): CampusEvent? = db.collection("events").document(id).get(Source.SERVER).awaitSocial().takeIf { it.exists() }?.event()
    fun listenRequests(seeker: Boolean, after: DocumentSnapshot? = null, opportunityId: String? = null,
        result: (SocialPage<TalentRequest>) -> Unit, error: (String) -> Unit, kind: String? = null): ListenerRegistration {
        var q: Query = db.collection("talentRequests").whereEqualTo(if (seeker) "seekerId" else "creatorId", uid())
        if (opportunityId != null) q = q.whereEqualTo("kind", "application").whereEqualTo("sourceId", opportunityId)
        else if (kind != null) {
            require(kind in listOf("invitation", "application"))
            q = q.whereEqualTo("kind", kind)
        }
        q = q.orderBy("createdAt", Query.Direction.DESCENDING)
        if (after != null) q = q.startAfter(after)
        return q.limit(30).addSnapshotListener { s, e ->
            if (e != null) error("Requests couldn't load. Check your connection and retry.")
            else result(SocialPage(s?.documents.orEmpty().map(::request), s?.documents?.lastOrNull(), s?.size() == 30))
        }
    }
    fun listenApplication(opportunityId: String, result: (TalentRequest?) -> Unit, error: (String) -> Unit): ListenerRegistration =
        db.collection("talentRequests").document("application_${opportunityId}_${uid()}").addSnapshotListener { s, e ->
            if (e != null) error("Application status couldn't load. Please retry.") else result(s?.takeIf { it.exists() }?.let(::request))
        }
    suspend fun invite(event: CampusEvent, creatorId: String, details: String) {
        val me = uid()
        require(event.organizerId == me && creatorId != me) { "Choose your event and a creator." }
        require(event.startsAt > System.currentTimeMillis()) { "Choose an upcoming event." }
        createRequest("invitation", event.eventId, me, creatorId, event.title, details)
    }
    suspend fun apply(item: Opportunity, note: String) {
        require(item.isOpen()) { "Applications have closed." }
        createRequest("application", item.id, item.seekerId, uid(), item.title, note)
    }
    private suspend fun createRequest(kind: String, source: String, seeker: String, creator: String, title: String, details: String) {
        require(details.trim().length in 10..2000) { "Add details between 10 and 2,000 characters." }
        val ref = db.collection("talentRequests").document("${kind}_${source}_${creator}")
        db.runTransaction { t ->
            check(!t.get(ref).exists()) { "A request already exists. Open Notifications to see its status." }
            t.set(ref, mapOf("kind" to kind, "sourceId" to source, "seekerId" to seeker, "creatorId" to creator,
                "title" to title, "details" to details.trim(), "status" to "pending",
                "createdAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp()))
        }.awaitSocial()
    }
    suspend fun respond(item: TalentRequest, next: String) {
        val me = uid(); require(item.allows(me, next)) { "This action is no longer available." }
        val ref = db.collection("talentRequests").document(item.id)
        db.runTransaction { t ->
            val fresh = request(t.get(ref))
            check(fresh.allows(me, next)) { "This request has already been updated." }
            t.update(ref, mapOf("status" to next, "updatedAt" to FieldValue.serverTimestamp()))
        }.awaitSocial()
    }
    private fun opportunity(s: DocumentSnapshot) = Opportunity(s.id, s.getString("seekerId").orEmpty(), s.getString("title").orEmpty(),
        s.getString("kind").orEmpty(), s.getString("description").orEmpty(), s.getString("category").orEmpty(),
        s.getString("location").orEmpty(), s.getTimestamp("deadline")?.toDate()?.time ?: 0, s.getString("status").orEmpty(), s.getTimestamp("createdAt")?.toDate()?.time ?: 0)
    private fun request(s: DocumentSnapshot) = TalentRequest(s.id, s.getString("kind").orEmpty(), s.getString("sourceId").orEmpty(),
        s.getString("seekerId").orEmpty(), s.getString("creatorId").orEmpty(), s.getString("title").orEmpty(),
        s.getString("details").orEmpty(), s.getString("status").orEmpty(), s.getTimestamp("createdAt")?.toDate()?.time ?: 0)
}
