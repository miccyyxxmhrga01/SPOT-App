package com.example.spotapp.data

import org.junit.Assert.*
import org.junit.Test

class SpotMessagesTest {
    @Test fun draftsRejectEmptyAndOversizedMessagesButAcceptMediaOnly() {
        assertNotNull(ChatDraft(text = "  ").error())
        assertNotNull(ChatDraft(text = "a".repeat(4001)).error())
        assertNull(ChatDraft(text = "a".repeat(4000)).error())
        assertNull(ChatDraft(attachment = ChatAttachment("path", "image/jpeg", "photo", 120)).error())
        assertNotNull(ChatDraft(attachment = ChatAttachment("path", "text/html", "page", 120)).error())
        assertNotNull(ChatDraft(attachment = ChatAttachment("path", "video/mp4", "video", 26L * 1024 * 1024)).error())
    }
    private val chat = CampusConversation("chat", "", creatorId = "me", partyIds = listOf("me", "friend"), memberIds = listOf("me", "friend"),
        people = mapOf("friend" to ChatPerson("friend", "Sam")), preview = "Hello", lastSenderId = "friend", updatedAt = 200)
    @Test fun nicknamesArePersonalAndIdentityComesFromUid() {
        assertEquals("Sam", chat.nameFor("me"))
        assertEquals("Study partner", chat.nameFor("me", ChatPreferences(nickname = "Study partner")))
        assertEquals("friend", chat.otherUid("me"))
    }
    @Test fun readAndHiddenConversationsReappearOnlyForNewMessages() {
        assertTrue(chat.unread("me", ChatPreferences(readAt = 100)))
        assertFalse(chat.unread("me", ChatPreferences(readAt = 200)))
        assertFalse(chat.copy(lastSenderId = "me").unread("me", ChatPreferences()))
        assertFalse(chat.visible(ChatPreferences(hiddenAt = 200)))
        assertTrue(chat.copy(updatedAt = 201).visible(ChatPreferences(hiddenAt = 200)))
    }
}
