package com.example.spotapp

import androidx.test.platform.app.InstrumentationRegistry
import com.example.spotapp.data.*
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import java.util.UUID
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Named Firebase apps point only at local emulators; the signed-in SPOT account is untouched. */
class SocialFirebaseIntegrationTest {
    private data class Client(val app: FirebaseApp, val db: FirebaseFirestore, val social: SocialRepository, val discover: DiscoverRepository)
    private suspend fun connect(uid: String): Client {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val app = FirebaseApp.initializeApp(context, FirebaseOptions.Builder().setProjectId("demo-spot-auth")
            .setApplicationId("1:123456789:android:socialtest").setApiKey("fake-emulator-key").build(), "social-test-${UUID.randomUUID()}")
        val auth = FirebaseAuth.getInstance(app).apply { useEmulator("127.0.0.1",9095) }
        val db = FirebaseFirestore.getInstance(app).apply {
            firestoreSettings = FirebaseFirestoreSettings.Builder().setPersistenceEnabled(false).build()
            useEmulator("127.0.0.1",8185)
        }
        auth.signInWithEmailAndPassword("$uid@example.test","emulator-password-123").awaitSocial()
        return Client(app, db, SocialRepository(db,auth), DiscoverRepository(db,auth))
    }
    private suspend fun comments(store: SocialRepository, count: Int): List<SocialComment> = withTimeout(20_000) {
        suspendCancellableCoroutine { c ->
            var listener: ListenerRegistration? = null
            listener = store.listenComments("android-social-post", result={ page -> if (page.items.size >= count && c.isActive) {
                listener?.remove(); c.resume(page.items)
            } }, error={ if (c.isActive) { listener?.remove(); c.resumeWithException(IllegalStateException(it)) } })
            c.invokeOnCancellation { listener?.remove() }
        }
    }
    private suspend fun notifications(store: SocialRepository, count: Int): List<SocialNotification> = withTimeout(20_000) {
        suspendCancellableCoroutine { c ->
            var listener: ListenerRegistration? = null
            listener = store.listenNotifications(result={ page -> if (page.items.size >= count && c.isActive) {
                listener?.remove(); c.resume(page.items)
            } }, error={ if (c.isActive) { listener?.remove(); c.resumeWithException(IllegalStateException(it)) } })
            c.invokeOnCancellation { listener?.remove() }
        }
    }
    @Test fun privateGroupsAndEventReservationsPersistAcrossFreshClients() = runBlocking<Unit> {
        withTimeout(90_000) {
            val owner = connect("android-social-owner"); val viewer = connect("android-social-viewer"); val seeker = connect("android-community-seeker")
            val context = InstrumentationRegistry.getInstrumentation().targetContext
            try {
                assertFalse(viewer.discover.canCreateEvents()); assertTrue(seeker.discover.canCreateEvents())
                val group = GroupDraft(UUID.randomUUID().toString(), "Android artists", "An isolated emulator group", "", "Painting", "private")
                owner.discover.createGroup(context, group) {}
                assertEquals(1L, owner.db.document("groups/${group.id}").get(Source.SERVER).awaitSocial().getLong("memberCount"))
                viewer.discover.requestJoin(group.id)
                assertEquals(1, owner.discover.people(group.id, false, true).items.size)
                owner.discover.reviewRequest(group.id, "android-social-viewer", true)
                assertEquals(2, owner.discover.people(group.id, false, false).items.size)
                val restored = connect("android-social-viewer")
                try {
                    assertTrue(restored.db.document("groups/${group.id}/members/android-social-viewer").get(Source.SERVER).awaitSocial().exists())
                    assertEquals(group.id, restored.discover.groups("android", "Painting").items.single().groupId)
                    restored.discover.setGroupJoined(group.id, false)
                } finally { restored.db.terminate().awaitSocial(); restored.app.delete() }
                assertEquals(1L, owner.db.document("groups/${group.id}").get(Source.SERVER).awaitSocial().getLong("memberCount"))
                val event = EventDraft(UUID.randomUUID().toString(), "Android showcase", "An isolated emulator event", "", "Singing", System.currentTimeMillis() + 86_400_000, "Campus hall", "SPOT Society", 1)
                assertNotNull(runCatching { viewer.discover.createEvent(context, event) {} }.exceptionOrNull())
                seeker.discover.createEvent(context, event) {}
                val results = coroutineScope { listOf(async { runCatching { viewer.discover.setEventJoined(event.id, true) } }, async { runCatching { owner.discover.setEventJoined(event.id, true) } }).awaitAll() }
                assertEquals(1, results.count { it.isSuccess })
                assertEquals(1L, seeker.db.document("events/${event.id}").get(Source.SERVER).awaitSocial().getLong("participantCount"))
                assertEquals(1, seeker.discover.people(event.id, true, false).items.size)
                val winner = if (results.first().isSuccess) viewer else owner
                winner.discover.setEventJoined(event.id, true)
                winner.discover.setEventJoined(event.id, false)
                assertEquals(0L, seeker.discover.events("android", "Singing").items.single().participantCount)
            } finally {
                listOf(owner, viewer, seeker).forEach { it.db.terminate().awaitSocial(); it.app.delete() }
            }
        }
    }
    @Test fun commentsRestoreAfterReconnectAndLikesNotificationsAndFollowsPersist() = runBlocking<Unit> {
        withTimeout(90_000) {
            val owner=connect("android-social-owner");val viewer=connect("android-social-viewer")
            try {
                val id=UUID.randomUUID().toString()
                coroutineScope {
                    listOf(async { viewer.social.sendComment("android-social-post",id,"A real Android SDK comment") },
                        async { viewer.social.sendComment("android-social-post",id,"A real Android SDK comment") }).awaitAll()
                }
                val rows=comments(owner.social,1)
                assertEquals(1,rows.count { it.id==id });assertEquals("android-social-viewer",rows.single { it.id==id }.username)
                assertEquals(1L,owner.db.document("posts/android-social-post").get(Source.SERVER).awaitSocial().getLong("commentsCount"))
                viewer.social.setCommentLiked("android-social-post",id,true);viewer.social.setCommentLiked("android-social-post",id,true)
                assertEquals(1L,owner.db.document("posts/android-social-post/comments/$id").get(Source.SERVER).awaitSocial().getLong("likesCount"))
                viewer.social.setCommentLiked("android-social-post",id,false)
                assertEquals(0L,owner.db.document("posts/android-social-post/comments/$id").get(Source.SERVER).awaitSocial().getLong("likesCount"))
                val inbox=notifications(owner.social,1)
                val comment=inbox.single { it.postId=="android-social-post" }
                owner.social.markRead(comment.id)
                assertTrue(owner.db.document("users/android-social-owner/notifications/${comment.id}").get(Source.SERVER).awaitSocial().getBoolean("isRead")==true)
                viewer.social.setFollowing("android-social-owner",true);viewer.social.setFollowing("android-social-owner",true)
                assertEquals(1L,owner.social.counts("android-social-owner").first)
                assertEquals(2,notifications(owner.social,2).size)
                viewer.social.setFollowing("android-social-owner",false)
                assertEquals(0L,owner.social.counts("android-social-owner").first)
                viewer.social.setSaved("android-social-post",true)
                assertTrue(viewer.db.document("users/android-social-viewer/savedPosts/android-social-post").get(Source.SERVER).awaitSocial().exists())
                owner.social.markAllRead()
                assertTrue(notifications(owner.social,2).all { it.isRead })
                // A new client with persistence disabled must restore from the server.
                val restored=connect("android-social-owner")
                try { assertEquals(id,comments(restored.social,1).single().id) }
                finally { restored.db.terminate().awaitSocial();restored.app.delete() }
            } finally { owner.db.terminate().awaitSocial();viewer.db.terminate().awaitSocial();owner.app.delete();viewer.app.delete() }
        }
    }
}
