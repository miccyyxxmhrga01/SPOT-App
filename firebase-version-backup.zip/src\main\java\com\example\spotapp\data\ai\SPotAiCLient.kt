package com.example.spotapp.data.ai

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object SpotAiClient {

    // Replace this with your real Render URL.
    // Keep the "/" at the end.
    private const val BASE_URL =
        "https://spot-ai-api.onrender.com/"

    private val loggingInterceptor =
        HttpLoggingInterceptor().apply {
            // BASIC, not BODY: never write users' uploaded photos into logcat.
            level = HttpLoggingInterceptor.Level.BASIC
        }

    private val httpClient =
        OkHttpClient.Builder()
            .addInterceptor(loggingInterceptor)
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(120, TimeUnit.SECONDS)
            .writeTimeout(120, TimeUnit.SECONDS)
            .build()

    val api: SpotAiApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(httpClient)
            .addConverterFactory(
                GsonConverterFactory.create()
            )
            .build()
            .create(SpotAiApi::class.java)
    }
}