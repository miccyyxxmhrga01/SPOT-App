package com.example.spotapp

import com.example.spotapp.ui.theme.spotSp

import android.graphics.Color as AndroidColor
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.example.spotapp.data.AuthRepository
import com.example.spotapp.data.cloudinary.CloudinaryManager
import com.example.spotapp.data.preferences.OnboardingPreferences
import com.example.spotapp.ui.theme.SPOTAppTheme
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume
import com.example.spotapp.ui.theme.components.AnimatedLoginBackground
import com.example.spotapp.ui.theme.components.SpotEmailVerificationScreen
import com.example.spotapp.ui.theme.navigation.SpotNavigation
import com.example.spotapp.ui.theme.screens.onboarding.OnboardingScreen

private val MainSpotGold = Color(0xFFD4AF37)
private val MainSpotInk = Color(0xFF171717)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)

        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(
                scrim = AndroidColor.TRANSPARENT,
                darkScrim = AndroidColor.WHITE
            ),
            navigationBarStyle = SystemBarStyle.light(
                scrim = AndroidColor.TRANSPARENT,
                darkScrim = AndroidColor.WHITE
            )
        )
        CloudinaryManager.init(this)

        setContent {
            SPOTAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize().navigationBarsPadding(),
                    color = Color(0xFFF8F8F8)
                ) {
                    SpotApp()
                }
            }
        }
    }
}

@Composable
fun SpotApp() {
    val context = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    val onboardingFlow = remember(context) {
        OnboardingPreferences.isOnboardingCompleted(context)
    }
    val onboardingCompleted by onboardingFlow.collectAsState(initial = null)

    when (onboardingCompleted) {
        null -> SpotLoadingScreen()
        false -> OnboardingScreen(
            onFinished = {
                scope.launch { OnboardingPreferences.setOnboardingCompleted(context) }
            }
        )
        true -> AuthFlow()
    }
}

private enum class AuthScreen {
    LOADING, LOGIN, SIGN_UP, EMAIL_VERIFICATION, PROFILE_SETUP, HOME, ERROR
}

@Composable
private fun AuthFlow() {
    val auth = remember { FirebaseAuth.getInstance() }
    var currentScreen by rememberSaveable { mutableStateOf(AuthScreen.LOADING) }
    var authReady by remember { mutableStateOf(false) }
    var signedInUid by remember { mutableStateOf<String?>(null) }
    var accountError by remember { mutableStateOf("") }

    DisposableEffect(auth) {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            val previousUid = signedInUid
            val firstEvent = !authReady
            val restoredUid = firebaseAuth.currentUser?.uid
            signedInUid = restoredUid
            authReady = true

            if (restoredUid == null) {
                if (currentScreen != AuthScreen.SIGN_UP) {
                    currentScreen = AuthScreen.LOGIN
                }
            } else if (firstEvent) {
                // Preserve an in-progress signup during activity recreation.
                if (currentScreen != AuthScreen.SIGN_UP) {
                    currentScreen = AuthScreen.LOADING
                }
            } else if (restoredUid != previousUid) {
                // Login/Google callbacks finish authentication before routing.
                // Signup also needs to finish its verification step first.
                if (currentScreen != AuthScreen.LOGIN && currentScreen != AuthScreen.SIGN_UP) {
                    currentScreen = AuthScreen.LOADING
                }
            }
        }

        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    LaunchedEffect(authReady, signedInUid, currentScreen) {
        if (!authReady || currentScreen != AuthScreen.LOADING) return@LaunchedEffect
        val checkedUid = signedInUid
        if (checkedUid == null) {
            currentScreen = AuthScreen.LOGIN
            return@LaunchedEffect
        }

        try {
            // Cancellation discards results from a previous screen or account.
            val result = withTimeoutOrNull(20000L) {
                suspendCancellableCoroutine<Pair<String, String?>> { continuation ->
                    AuthRepository.checkUserDestination { destination, error ->
                        if (continuation.isActive) continuation.resume(destination to error)
                    }
                }
            }

            if (auth.currentUser?.uid != checkedUid) return@LaunchedEffect

            if (result == null) {
                accountError = "Your account is taking longer to load. Check your connection and try again."
                currentScreen = AuthScreen.ERROR
            } else if (!result.second.isNullOrBlank()) {
                accountError = result.second ?: "Could not load your account."
                currentScreen = AuthScreen.ERROR
            } else {
                currentScreen = when (result.first) {
                    "HOME" -> AuthScreen.HOME
                    "PROFILE_SETUP" -> AuthScreen.PROFILE_SETUP
                    "EMAIL_VERIFICATION" -> AuthScreen.EMAIL_VERIFICATION
                    "LOGIN" -> AuthScreen.LOGIN
                    else -> {
                        accountError = "Could not load your account. Please try again."
                        AuthScreen.ERROR
                    }
                }
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            accountError = error.localizedMessage ?: "Could not load your account."
            currentScreen = AuthScreen.ERROR
        }
    }

    // A restored screen name is not proof of a signed-in Firebase session.
    if (!authReady) {
        SpotLoadingScreen()
        return
    }

    when (currentScreen) {
        AuthScreen.LOADING -> SpotLoadingScreen()
        AuthScreen.LOGIN -> LoginUI(
            onLoginSuccess = { currentScreen = AuthScreen.LOADING },
            onSignUpClick = { currentScreen = AuthScreen.SIGN_UP }
        )
        AuthScreen.SIGN_UP -> SignUpUI(
            onLoginClick = { currentScreen = AuthScreen.LOGIN },
            onSignUpSuccess = { currentScreen = AuthScreen.LOADING }
        )
        AuthScreen.EMAIL_VERIFICATION -> key(signedInUid) {
            SpotEmailVerificationScreen(
                onVerified = { currentScreen = AuthScreen.LOADING },
                onUseAnotherAccount = { auth.signOut() }
            )
        }
        AuthScreen.PROFILE_SETUP -> key(signedInUid) {
            val profileUid = signedInUid
            ProfileSetupScreen(
                onSetupComplete = {
                    if (profileUid != null && auth.currentUser?.uid == profileUid) {
                        currentScreen = AuthScreen.HOME
                    }
                }
            )
        }
        AuthScreen.HOME -> key(signedInUid) { HomeScreen(onLogout = { auth.signOut() }) }
        AuthScreen.ERROR -> SpotAccountErrorScreen(
            message = accountError,
            onRetry = { currentScreen = AuthScreen.LOADING },
            onSignOut = { auth.signOut() }
        )
    }
}

@Composable
internal fun HomeScreen(onLogout: () -> Unit) {
    SpotNavigation(onLogout = onLogout)
}

@Composable
private fun SpotLoadingScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        AnimatedLoginBackground()
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(
                painter = painterResource(R.drawable.spotlogo),
                contentDescription = "SPOT logo",
                modifier = Modifier.size(90.dp)
            )
            Spacer(Modifier.height(20.dp))
            CircularProgressIndicator(
                modifier = Modifier.size(28.dp),
                color = MainSpotGold,
                strokeWidth = 2.dp
            )
            Spacer(Modifier.height(14.dp))
            Text("Opening SPOT...", color = Color(0xFF737373), fontSize = 12.spotSp)
        }
    }
}

@Composable
private fun SpotAccountErrorScreen(
    message: String,
    onRetry: () -> Unit,
    onSignOut: () -> Unit
) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        AnimatedLoginBackground()
        Column(
            modifier = Modifier.fillMaxSize().statusBarsPadding()
                .verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Surface(
                modifier = Modifier.widthIn(max = 430.dp).fillMaxWidth(),
                color = Color.White,
                shape = RoundedCornerShape(26.dp)
            ) {
                Column(
                    modifier = Modifier.padding(26.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("Couldn't open your account", color = MainSpotInk,
                        fontSize = 20.spotSp, fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Text(message.ifBlank { "Please check your connection and try again." },
                        color = Color(0xFF737373), fontSize = 13.spotSp,
                        textAlign = TextAlign.Center)
                    Spacer(Modifier.height(20.dp))
                    Button(
                        onClick = onRetry,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MainSpotGold, contentColor = MainSpotInk)
                    ) { Text("Try again") }
                    TextButton(onClick = onSignOut) {
                        Text("Sign out", color = Color(0xFF876914))
                    }
                }
            }
        }
    }
}
