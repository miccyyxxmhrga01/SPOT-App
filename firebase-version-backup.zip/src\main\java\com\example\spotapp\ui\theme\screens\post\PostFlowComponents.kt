package com.example.spotapp.ui.theme.screens.post

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import coil3.compose.AsyncImage
import com.example.spotapp.data.*
import kotlinx.coroutines.CancellationException

internal val PostGold = Color(0xFFAD8420)
internal val PostIvory = Color(0xFFFFFCF6)
internal val PostInk = Color(0xFF171717)
internal val PostLine = Color(0xFFE8E2D5)
internal val PostMuted = Color(0xFF77746C)

@Composable
internal fun PostTopBar(title: String, back: () -> Unit, close: Boolean = false, dark: Boolean = false,
    actions: @Composable RowScope.() -> Unit = {}) {
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = back) { Icon(if (close) Icons.Default.Close else Icons.AutoMirrored.Filled.ArrowBack,
            if (close) "Close create post" else "Back", tint = if (dark) Color.White else PostInk) }
        Text(title, style = MaterialTheme.typography.titleLarge, color = if (dark) Color.White else PostInk, modifier = Modifier.weight(1f))
        actions()
    }
}

@Composable
internal fun MediaThumbnail(uri: String, modifier: Modifier = Modifier, knownVideo: Boolean? = null, edit: PostMediaEdit = PostMediaEdit()) {
    val context = LocalContext.current
    val video by produceState(knownVideo, uri, knownVideo) {
        if (knownVideo == null) value = try { MediaLibraryRepository(context).describe(uri).isVideo } catch (e: CancellationException) { throw e } catch (_: Exception) { null }
    }
    val bitmap by produceState<android.graphics.Bitmap?>(null, uri, video, edit) {
        value = try {
            if (video == true) PostMediaExporter.thumbnail(context, uri)
            else if (edit.changesImage) PostMediaExporter.imagePreview(context, uri, edit, 240) else null
        } catch (e: CancellationException) { throw e } catch (_: Exception) { null }
    }
    Box(modifier.background(Color(0xFFEDE9E0)), contentAlignment = Alignment.Center) {
        val image = bitmap
        if (image != null) Image(image.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else if (video != true) AsyncImage(uri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Default.Videocam, null, tint = PostMuted)
        if (video == true) Icon(Icons.Default.PlayArrow, null, Modifier.align(Alignment.BottomStart).padding(3.dp).size(15.dp).background(Color.Black.copy(alpha = .35f), CircleShape), tint = Color.White)
    }
}

@Composable
internal fun MediaSelectionStrip(media: List<String>, edits: Map<String, PostMediaEdit>, active: String?, select: (String) -> Unit,
    remove: ((String) -> Unit)? = null, add: (() -> Unit)? = null, dark: Boolean = false) {
    LazyRow(Modifier.fillMaxWidth(), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        itemsIndexed(media, key = { _, uri -> uri }) { index, uri ->
            Box {
                Surface(onClick = { select(uri) }, shape = RoundedCornerShape(10.dp), border = BorderStroke(if (active == uri) 2.dp else 1.dp, if (active == uri) PostGold else PostLine), modifier = Modifier.size(58.dp).testTag("selected-media-$index")) {
                    MediaThumbnail(uri, edit = edits[uri] ?: PostMediaEdit())
                }
                Text("${index + 1}", Modifier.align(Alignment.BottomEnd).padding(2.dp).background(PostGold, CircleShape).padding(horizontal = 5.dp, vertical = 1.dp), color = Color.White, style = MaterialTheme.typography.labelSmall)
                if (remove != null) IconButton(onClick = { remove(uri) }, Modifier.align(Alignment.TopEnd).size(26.dp)) { Icon(Icons.Default.Close, "Remove selected media ${index + 1}", Modifier.size(20.dp).background(Color.Black.copy(alpha = .65f), CircleShape).padding(3.dp), tint = Color.White) }
            }
        }
        if (add != null && media.size < 10) item {
            OutlinedIconButton(onClick = add, modifier = Modifier.size(58.dp), shape = RoundedCornerShape(10.dp), border = BorderStroke(1.dp, if (dark) Color.White.copy(alpha = .3f) else PostLine)) {
                Icon(Icons.Default.Add, "Add media", tint = if (dark) Color.White else PostGold)
            }
        }
    }
}

@Composable
internal fun PostNextButton(label: String = "Next", enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick = onClick, enabled = enabled, colors = ButtonDefaults.buttonColors(containerColor = PostGold, contentColor = PostInk),
        shape = RoundedCornerShape(14.dp), modifier = Modifier.heightIn(min = 48.dp).testTag("post-next")) {
        Text(label, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(horizontal = 16.dp))
    }
}

@Composable
internal fun PostError(error: String, modifier: Modifier = Modifier) {
    if (error.isNotBlank()) Text(error, modifier.testTag("post-error"), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
}
